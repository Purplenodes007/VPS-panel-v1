██╗   ██╗ █████╗ ███╗   ██╗████████╗██╗██╗  ██╗███╗   ██╗ ██████╗ ██████╗ ███████╗███████╗
██║   ██║██╔══██╗████╗  ██║╚══██╔══╝██║╚██╗██╔╝████╗  ██║██╔═══██╗██╔══██╗██╔════╝██╔════╝
██║   ██║███████║██╔██╗ ██║   ██║   ██║ ╚███╔╝ ██╔██╗ ██║██║   ██║██║  ██║█████╗  ███████╗
╚██╗ ██╔╝██╔══██║██║╚██╗██║   ██║   ██║ ██╔██╗ ██║╚██╗██║██║   ██║██║  ██║██╔══╝  ╚╚══██║
 ╚████╔╝ ██║  ██║██║ ╚██╗██║   ██║   ██║██╔╝ ██╗██║ ╚██╗██║╚██████╔╝██████╔╝███████╗███████║
  ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝   ╚═╝╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚══════╝
                                    By AashirwadGamerzz

VantixNodes
A production-ready hosting company website and management platform: VPS, RDP, game, Discord bot, and web hosting, equipped with a fully database-driven public site and a secure, role-based admin panel.
Tech Stack: Node.js, Express, SQLite (better-sqlite3), EJS, Vanilla JavaScript/CSS, WebSocket (ws), Discord OAuth2.
Everything visible to visitors is dynamically editable directly from /admin—eliminating the need for source code edits for normal updates, including: site name, logo, color schemes, typography, background (color, gradient, image, or video), hero sections, categories, plans, team rosters, staff applications, blog posts, support tickets, social links, status monitors, statistics, and SEO configurations.
Table of Contents

 * System Requirements
 * Quick Start
 * Environment Setup
 * SQLite Setup
 * Discord OAuth Setup
 * Admin Setup
 * Development & Production Modes
 * PM2 Deployment
 * Nginx Reverse Proxy
 * SSL & Cloudflare Configuration
 * Backups & Recovery
 * Connecting Real Monitoring Services
 * Security Architecture
 * API Reference
 * Project Structure
 * Troubleshooting Guide
 * License

1. Requirements
 * Node.js: Version 18.17 or newer (20 or 22 LTS recommended; built-in fetch required).
 * Package Manager: npm 9+
 * Operating System: Linux VPS (Ubuntu/Debian tested) for production environments; macOS/Windows fully supported for local development.
 * Build Tools: Only required if no prebuilt better-sqlite3 binary exists for your specific platform: sudo apt install -y build-essential python3.
> Note: No external database server is required. SQLite operates seamlessly as a single standalone file.
> 
2. Quick Start
git clone <repository> vantixnodes
cd vantixnodes
npm install
cp .env.example .env      # Edit .env with your configuration
npm run setup             # Creates the database and prints a one-time admin setup link
npm start

Open the printed /setup?token=... link in your browser once to initialize the owner account, then sign in at /admin.
Available Scripts
| Command | Description |
|---|---|
| npm start | Starts the production server |
| npm run dev | Starts the server in development mode with auto-reload (node --watch) |
| npm run setup | Creates/upgrades the database, seeds defaults (first run only), and prints the admin setup link |
| npm run check | Executes a smoke-test on a running server |

3. Environment Setup
l
Copy .env.example to .env and fill out the required parameters. Never commit your .env file to version control.
NODE_ENV=production
PORT=3000
SITE_URL=https://example.com
SESSION_SECRET=<long random string>
DISCORD_CLIENT_ID=
DISCORD_CLIENT_SECRET=
DISCORD_CALLBACK_URL=https://example.com/auth/discord/callback
DATABASE_PATH=./data/database.sqlite
TRUST_PROXY=true

| Variable | Description |
|---|---|
| SITE_URL | Public base URL without a trailing slash. Used for canonical URLs, sitemaps, and secure cookie configuration (Secure flag enabled if starting with https://). |
| SESSION_SECRET | Generate via node -e "console.log(require('crypto').randomBytes(48).toString('hex'))". If left empty, a secure random secret is generated automatically inside data/.session_secret. |
| DISCORD_* | Discord application credentials. Discord login stays disabled with a friendly message until configured. |
| TRUST_PROXY | Set to true when running behind Nginx or Cloudflare so client IP addresses (rate limiting, audit logs) and secure cookies function properly. |
| DATABASE_PATH | File system path for the SQLite database. |
| INITIAL_ADMIN_DISCORD_ID | Optional: Assigns superadmin privileges to this specific Discord user upon their first login while no admin exists. |

. SQLite Setup
Executing npm run setup (or running npm start for the first time) will automatically:
 * Create data/database.sqlite if it does not already exist.
 * Apply pending database migrations from src/database/migrations.js (tables, indexes, foreign keys).
 * Seed default settings, categories, sample plans, status services, social links, application questions, ticket categories, and initial blog posts (run only once).
 * Generate a secure, one-time admin setup link if no administrator accounts exist.
This process never overwrites or drops existing user data, making it completely safe to re-run after system updates. Schema changes in future versions should always be appended as new migration files rather than modifying existing ones. Foreign keys, WAL mode, and busy timeouts are enforced on every connection.

5. Discord OAuth Setup
 * Navigate to the Discord Developer Portal and click New Application.
 * Open the OAuth2 tab in the sidebar.
 * Copy your Client ID into the DISCORD_CLIENT_ID environment variable.
 * Click Reset Secret, then copy the generated secret into DISCORD_CLIENT_SECRET (displayed only once).
 * Under Redirects, click Add Redirect and enter the exact URL matching your DISCORD_CALLBACK_URL (e.g., [https://example.com/auth/discord/callback](https://example.com/auth/discord/callback), or http://localhost:3000/auth/discord/callback for local testing). Save changes.
 * Restart your application (pm2 restart vantixnodes).
The application requests identify and email scopes, storing securely: Discord ID, username, global name, avatar hash, email (if shared), and timestamps. Access tokens are utilized instantly and never stored. A random state token protects flows against CSRF vulnerabilities.

6. Admin Setup
Administrative access is strictly governed by database roles (user, moderator, admin, superadmin) enforced on the server-side for every request. Staff sessions expire automatically after 2 hours of inactivity.
First Administrator Initialization
 * Setup Link (Recommended): npm run setup outputs a secure link in the format https://your-site/setup?token=.... Open this link to establish a username and a strong password (12+ characters combining uppercase, lowercase, and numbers). The token is stored securely as a hash, works only once, and permanently closes the endpoint once an admin is registered.
 * Discord Fallback: Set INITIAL_ADMIN_DISCORD_ID to your Discord User ID and authenticate via Discord.
Sign in using standard credentials at /auth/admin (protected by rate-limiting; accounts lock for 15 minutes after 5 consecutive failed attempts). Passwords are cryptographically hashed using bcrypt (cost factor 12).

7. Development & Production Modes
npm run dev     # Starts development mode with auto-reload
npm start       # Starts production mode

When deploying behind HTTPS, ensure SITE_URL=https://... is defined so cookies are flagged as Secure, and configure TRUST_PROXY=true.
8. 

15. Project Structure
vantixnodes/
├── server.js                 # Entry point (HTTP + WebSocket server)
├── ecosystem.config.js       # PM2 process configuration
├── src/
│   ├── app.js                # Express app initialization & middleware stack
│   ├── config/               # Environment constants
│   ├── database/             # Connection management, migrations, seeding
│   ├── middleware/           # Security, authentication, CSRF, error handling
│   ├── models/               # SQL data access layers
│   ├── services/             # Core application services & business logic
│   ├── controllers/          # Request handlers
│   ├── routes/               # Route endpoints mapping
│   └── utils/                # Helper utilities & markdown processors
├── views/                    # EJS templates (layouts, partials, pages, admin)
├── public/                   # Static assets (CSS, client JS, images, uploads)
├── data/                     # SQLite database storage directory
├── backups/                  # Secure private backup archives
└── scripts/check.js          # Automated deployment smoke tests

Proprietary — All rights reserved by the VantixNodes owner.
