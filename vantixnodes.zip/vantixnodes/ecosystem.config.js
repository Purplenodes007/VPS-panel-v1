module.exports = {
  apps: [
    {
      name: 'vantixnodes',
      script: 'server.js',
      instances: 1, // SQLite + in-memory WebSocket broadcast: keep a single instance
      exec_mode: 'fork',
      autorestart: true,
      max_memory_restart: '400M',
      env: { NODE_ENV: 'production' }
    }
  ]
};
