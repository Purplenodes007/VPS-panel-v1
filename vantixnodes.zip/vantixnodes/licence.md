██╗   ██╗ █████╗ ███╗   ██╗████████╗██╗██╗  ██╗
██║   ██║██╔══██╗████╗  ██║╚══██╔══╝██║╚██╗██╔╝
██║   ██║███████║██╔██╗ ██║   ██║   ██║ ╚███╔╝ 
╚██╗ ██╔╝██╔══██║██║╚██╗██║   ██║   ██║ ██╔██╗ 
 ╚████╔╝ ██║  ██║██║ ╚██╗██║   ██║   ██║██╔╝ ██╗
  ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝   ╚═╝╚═╝╚═╝  ╚═╝╚═╝
                By AashirwadGamerzz

PROPRIETARY SOFTWARE LICENSE AGREEMENT
Copyright © 2026 AashirwadGamerzz / VantixNodes. All Rights Reserved.

1. GRANT OF LICENSE & RESTRICTIONS
This software, source code, documentation, and all associated digital assets (collectively, the "Platform") are proprietary property owned exclusively by AashirwadGamerzz (the "Author").
Unless explicit written authorization has been granted directly by the Author:
 * No Unauthorized Use: You are strictly prohibited from using, deploying, hosting, or running this platform or any portion thereof.
 * No Re-uploading / Redistribution: You may not copy, share, mirror, or re-upload this repository, source code, or compiled binaries to any public or private server, GitHub repository, hosting platform, or file-sharing service.
 * No Code Modification: You are strictly forbidden from altering, editing, refactoring, or adapting any part of the source code, design assets, or configuration files.
 * No Rebranding: You may not remove, alter, hide, or replace any copyright notices, author credits (including references to AashirwadGamerzz), or branding markers contained within the platform.

2. PERMISSION-BASED EXCEPTIONS
Any use of this Platform—including but not limited to hosting, running, modifying, or distributing—requires prior, explicit, and verifiable written consent from the Author. Granting permission for one specific use does not constitute a waiver of rights for any other use.

3. TERMINATION
Any unauthorized use, distribution, modification, or breach of the terms outlined in this License Agreement shall result in the immediate revocation of any implied or granted access, and constitutes a direct violation of international copyright laws.

4. DISCLAIMER OF WARRANTIES
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT, OR OTHERWISE, ARISING FROM, OUT OF, OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
