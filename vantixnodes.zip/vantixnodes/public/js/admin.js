/* VantixNodes admin panel script. Vanilla JS, no dependencies. */
(function () {
  'use strict';

  var doc = document;
  function $(sel, ctx) { return (ctx || doc).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || doc).querySelectorAll(sel)); }
  var csrfMeta = $('meta[name="csrf-token"]');
  var csrf = csrfMeta ? csrfMeta.getAttribute('content') : '';

  /* ------------------------------ mobile sidebar -------------------------- */
  var sidebar = $('[data-sidebar]');
  var scrim = $('[data-sidebar-scrim]');
  var menuBtn = $('[data-sidebar-toggle]');
  function setSidebar(open) {
    if (!sidebar) return;
    sidebar.classList.toggle('is-open', open);
    if (scrim) scrim.classList.toggle('is-open', open);
    if (menuBtn) menuBtn.setAttribute('aria-expanded', String(open));
  }
  if (menuBtn) menuBtn.addEventListener('click', function () { setSidebar(!sidebar.classList.contains('is-open')); });
  if (scrim) scrim.addEventListener('click', function () { setSidebar(false); });
  doc.addEventListener('keydown', function (e) { if (e.key === 'Escape') setSidebar(false); });

  /* ------------------------------ confirm dialogs ------------------------- */
  doc.addEventListener('submit', function (e) {
    var msg = e.target.getAttribute && e.target.getAttribute('data-confirm');
    var sub = e.submitter && e.submitter.getAttribute && e.submitter.getAttribute('data-confirm');
    var text = sub || msg;
    if (text && !window.confirm(text)) e.preventDefault();
  });

  /* ------------------------ client-side form validation ------------------- */
  $$('form[data-validate]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (e.submitter && e.submitter.hasAttribute('formnovalidate')) return;
      var first = null;
      $$('input, select, textarea', form).forEach(function (f) {
        if (f.type === 'hidden' || f.disabled || f.closest('[hidden]')) return;
        f.classList.remove('is-invalid');
        if (!f.checkValidity()) {
          f.classList.add('is-invalid');
          if (!first) first = f;
        }
      });
      if (first) {
        e.preventDefault();
        first.focus();
        if (first.reportValidity) first.reportValidity();
      }
    });
    form.addEventListener('input', function (e) { e.target.classList && e.target.classList.remove('is-invalid'); });
  });

  /* -------------------------------- auto submit --------------------------- */
  $$('[data-autosubmit]').forEach(function (el) {
    el.addEventListener('change', function () { if (el.form) el.form.submit(); });
  });

  /* -------------------------------- slug helper --------------------------- */
  $$('[data-slug-source]').forEach(function (src) {
    var target = $('[data-slug-target]', src.form);
    if (!target) return;
    var touched = !!target.value;
    target.addEventListener('input', function () { touched = !!target.value; });
    src.addEventListener('input', function () {
      if (touched) return;
      target.value = src.value.toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80);
    });
  });

  /* ------------------------------ file uploads ---------------------------- */
  $$('[data-upload-field]').forEach(function (wrap) {
    var input = $('[data-upload-input]', wrap);
    var target = $('[data-upload-target]', wrap);
    var status = $('[data-upload-status]', wrap);
    var btn = input && input.closest('.upload-btn');
    var original = status ? status.textContent : '';
    if (!input || !target) return;

    input.addEventListener('change', function () {
      var file = input.files && input.files[0];
      if (!file) return;
      var fd = new FormData();
      fd.append('file', file);
      if (btn) btn.classList.add('is-loading');
      if (status) status.textContent = 'Uploading ' + file.name + '…';
      fetch('/admin/upload', {
        method: 'POST',
        headers: { 'x-csrf-token': csrf, Accept: 'application/json' },
        body: fd,
        credentials: 'same-origin'
      })
        .then(function (res) { return res.json().then(function (data) { return { ok: res.ok, data: data }; }); })
        .then(function (r) {
          if (!r.ok) throw new Error(r.data && r.data.error ? r.data.error : 'Upload failed.');
          target.value = r.data.url;
          target.dispatchEvent(new Event('input', { bubbles: true }));
          if (status) status.textContent = 'Uploaded. Remember to save the form.';
        })
        .catch(function (err) {
          if (status) status.textContent = err.message || 'Upload failed.';
        })
        .then(function () {
          if (btn) btn.classList.remove('is-loading');
          input.value = '';
          setTimeout(function () { if (status && /Remember|Upload/.test(status.textContent)) status.textContent = original; }, 6000);
        });
    });
  });

  /* --------------------- color pickers (text <-> swatch) ------------------ */
  function normalizeHex(v) { return /^#[0-9a-fA-F]{6}$/.test(v) ? v.toLowerCase() : null; }
  $$('[data-color-picker]').forEach(function (picker) {
    var key = picker.getAttribute('data-color-picker');
    var text = $('[data-color-text="' + key + '"]', picker.form || doc);
    if (!text) return;
    picker.addEventListener('input', function () {
      text.value = picker.value;
      text.dispatchEvent(new Event('input', { bubbles: true }));
    });
    text.addEventListener('input', function () {
      var hex = normalizeHex(text.value);
      if (hex) picker.value = hex;
    });
  });

  /* ------------------------------- theme preview -------------------------- */
  var themeForm = $('[data-theme-form]');
  var preview = $('[data-theme-preview]');
  if (themeForm && preview) {
    var map = {
      color_primary: '--primary', color_secondary: '--secondary', color_accent: '--accent',
      color_background: '--background', color_surface: '--surface', color_text: '--text',
      color_muted: '--muted', color_border: '--border'
    };
    var radiusOut = $('[data-radius-out]');
    var applyPreview = function () {
      Object.keys(map).forEach(function (name) {
        var f = themeForm.elements[name];
        var hex = f && normalizeHex(f.value);
        if (hex) preview.style.setProperty(map[name], hex);
      });
      var r = themeForm.elements.border_radius;
      if (r) {
        preview.style.setProperty('--radius', r.value + 'px');
        if (radiusOut) radiusOut.textContent = r.value;
      }
      var style = themeForm.elements.button_style && themeForm.elements.button_style.value;
      ['gradient', 'solid', 'outline', 'pill', 'square'].forEach(function (s) { preview.classList.remove('btn-' + s); });
      if (style) preview.classList.add('btn-' + style);
    };
    themeForm.addEventListener('input', applyPreview);
    themeForm.addEventListener('change', applyPreview);
    applyPreview();
  }

  /* ------------------------------ background form ------------------------- */
  var bgForm = $('[data-bg-form]');
  if (bgForm) {
    var typeSel = $('[data-bg-type]', bgForm);
    var sync = function () {
      var t = typeSel.value;
      $$('[data-bg-section]', bgForm).forEach(function (sec) {
        var types = sec.getAttribute('data-bg-section').split(' ');
        sec.hidden = types.indexOf(t) === -1;
      });
    };
    typeSel.addEventListener('change', sync);
    sync();
  }
  $$('[data-range-out]').forEach(function (r) {
    var out = $('[data-out="' + r.getAttribute('data-range-out') + '"]');
    r.addEventListener('input', function () { if (out) out.textContent = r.value; });
  });

  /* -------------------------- application question type ------------------- */
  var qType = $('[data-question-type]');
  var optionsField = $('[data-options-field]');
  if (qType && optionsField) {
    var syncQ = function () { optionsField.hidden = qType.value !== 'select'; };
    qType.addEventListener('change', syncQ);
    syncQ();
  }

  /* ------------------------ status: API source toggle --------------------- */
  $$('[data-source-select]').forEach(function (sel) {
    var url = sel.parentNode.querySelector('input[type="url"]');
    if (!url) return;
    var sync = function () { url.style.display = sel.value === 'api' ? '' : 'none'; };
    sel.addEventListener('change', sync);
    sync();
  });
})();
