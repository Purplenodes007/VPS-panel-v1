/* VantixNodes public site script. Vanilla JS, no dependencies. */
(function () {
  'use strict';

  var doc = document;
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var noAnim = doc.body.classList.contains('no-anim');
  var animate = !reduceMotion && !noAnim;

  doc.documentElement.classList.add('js');

  function $(sel, ctx) { return (ctx || doc).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || doc).querySelectorAll(sel)); }
  function debounce(fn, wait) {
    var t;
    return function () {
      var args = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, args); }, wait);
    };
  }

  /* ----------------------------- header + nav ----------------------------- */
  var header = $('[data-header]');
  if (header) {
    var onScroll = function () { header.classList.toggle('is-scrolled', window.scrollY > 8); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  var toggle = $('[data-nav-toggle]');
  var nav = $('[data-nav]');
  if (toggle && nav) {
    var setNav = function (open) {
      nav.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', String(open));
      doc.body.style.overflow = open && window.innerWidth <= 900 ? 'hidden' : '';
    };
    toggle.addEventListener('click', function () { setNav(toggle.getAttribute('aria-expanded') !== 'true'); });
    doc.addEventListener('keydown', function (e) { if (e.key === 'Escape') setNav(false); });
    nav.addEventListener('click', function (e) { if (e.target.closest('a')) setNav(false); });
    window.addEventListener('resize', debounce(function () { if (window.innerWidth > 900) setNav(false); }, 150));
  }

  /* ------------------------------ scroll reveal --------------------------- */
  var reveals = $$('.reveal');
  if (reveals.length) {
    if (!animate || !('IntersectionObserver' in window)) {
      reveals.forEach(function (el) { el.classList.add('is-visible'); });
    } else {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            io.unobserve(entry.target);
          }
        });
      }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
      reveals.forEach(function (el, i) {
        // Light stagger among siblings that appear together
        el.style.setProperty('--reveal-delay', (i % 6) * 60 + 'ms');
        io.observe(el);
      });
    }
  }

  /* ----------------------------- animated counters ------------------------ */
  function runCounter(el) {
    var raw = el.getAttribute('data-counter') || '';
    var m = /^([^0-9]*)([0-9][0-9,]*(?:\.[0-9]+)?)(.*)$/.exec(raw);
    if (!m) return;
    var prefix = m[1], numStr = m[2], suffix = m[3];
    var target = parseFloat(numStr.replace(/,/g, ''));
    var decimals = (numStr.split('.')[1] || '').length;
    var useCommas = numStr.indexOf(',') !== -1;
    var duration = 1400, start = null;
    function fmt(v) {
      var s = v.toFixed(decimals);
      if (useCommas) s = Number(s).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
      return prefix + s + suffix;
    }
    function step(ts) {
      if (start === null) start = ts;
      var p = Math.min((ts - start) / duration, 1);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = fmt(target * eased);
      if (p < 1) requestAnimationFrame(step); else el.textContent = raw;
    }
    requestAnimationFrame(step);
  }
  var counters = $$('[data-counter]');
  if (counters.length && animate && 'IntersectionObserver' in window) {
    var cio = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) { runCounter(entry.target); cio.unobserve(entry.target); }
      });
    }, { threshold: 0.6 });
    counters.forEach(function (c) { cio.observe(c); });
  }

  /* ---------------------------------- tabs -------------------------------- */
  $$('[data-tabs]').forEach(function (tabs) {
    var buttons = $$('[data-tab]', tabs);
    function select(btn, focus) {
      buttons.forEach(function (b) {
        var active = b === btn;
        b.classList.toggle('is-active', active);
        b.setAttribute('aria-selected', String(active));
        b.tabIndex = active ? 0 : -1;
        var panel = doc.getElementById('panel-' + b.getAttribute('data-tab'));
        if (panel) {
          panel.hidden = !active;
          panel.classList.toggle('is-active', active);
          if (active) $$('.reveal', panel).forEach(function (el) { el.classList.add('is-visible'); });
        }
      });
      if (focus) btn.focus();
    }
    buttons.forEach(function (btn, i) {
      btn.addEventListener('click', function () { select(btn); });
      btn.addEventListener('keydown', function (e) {
        var next = null;
        if (e.key === 'ArrowRight') next = buttons[(i + 1) % buttons.length];
        if (e.key === 'ArrowLeft') next = buttons[(i - 1 + buttons.length) % buttons.length];
        if (e.key === 'Home') next = buttons[0];
        if (e.key === 'End') next = buttons[buttons.length - 1];
        if (next) { e.preventDefault(); select(next, true); }
      });
    });
  });

  /* ------------------------------- plan filter ---------------------------- */
  var filter = $('[data-plan-filter]');
  if (filter) {
    var emptyMsg = $('[data-plan-empty]');
    var apply = debounce(function () {
      var q = filter.value.trim().toLowerCase();
      var anyVisible = false;
      $$('[data-plan-group]').forEach(function (group) {
        var visible = 0;
        $$('[data-plan-name]', group).forEach(function (card) {
          var show = !q || card.getAttribute('data-plan-name').indexOf(q) !== -1;
          card.hidden = !show;
          card.style.display = show ? '' : 'none';
          if (show) visible++;
        });
        group.style.display = visible ? '' : 'none';
        if (visible) anyVisible = true;
      });
      if (emptyMsg) emptyMsg.hidden = anyVisible;
    }, 150);
    filter.addEventListener('input', apply);
  }

  /* --------------------------- form validation UX ------------------------- */
  $$('form[data-validate]').forEach(function (form) {
    function clearError(field) {
      field.classList.remove('is-invalid');
      field.removeAttribute('aria-invalid');
      var err = field.parentNode.querySelector('.field-error[data-for="' + (field.id || field.name) + '"]');
      if (err) err.remove();
    }
    function showError(field, message) {
      clearError(field);
      field.classList.add('is-invalid');
      field.setAttribute('aria-invalid', 'true');
      var p = doc.createElement('p');
      p.className = 'field-error';
      p.setAttribute('role', 'alert');
      p.setAttribute('data-for', field.id || field.name);
      p.textContent = message;
      field.insertAdjacentElement('afterend', p);
    }
    function messageFor(field) {
      var v = field.validity;
      if (v.valueMissing) return 'This field is required.';
      if (v.typeMismatch) return field.type === 'email' ? 'Enter a valid email address.' : 'Enter a valid value.';
      if (v.tooShort) return 'Use at least ' + field.minLength + ' characters.';
      if (v.tooLong) return 'Use at most ' + field.maxLength + ' characters.';
      if (v.patternMismatch) return 'Use only the allowed characters.';
      if (v.rangeUnderflow || v.rangeOverflow) return 'Value is out of range.';
      return field.validationMessage || 'Invalid value.';
    }
    form.addEventListener('submit', function (e) {
      var first = null;
      $$('input, select, textarea', form).forEach(function (f) {
        if (f.type === 'hidden' || f.disabled) return;
        if (!f.checkValidity()) {
          showError(f, messageFor(f));
          if (!first) first = f;
        } else clearError(f);
      });
      var pw = form.querySelector('[name="password"]');
      var confirm = form.querySelector('[name="confirm"]');
      if (pw && confirm && pw.value !== confirm.value) {
        showError(confirm, 'Passwords do not match.');
        first = first || confirm;
      }
      if (first) { e.preventDefault(); first.focus(); return; }
      var btn = form.querySelector('button[type="submit"]');
      if (btn) setTimeout(function () { btn.disabled = true; }, 0);
    });
    form.addEventListener('input', function (e) { if (e.target.classList && e.target.classList.contains('is-invalid')) clearError(e.target); });
  });

  /* ---------------------------- confirm dialogs --------------------------- */
  doc.addEventListener('submit', function (e) {
    var msg = e.target.getAttribute && e.target.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) e.preventDefault();
  });

  /* --------------------------- page leave transition ---------------------- */
  if (animate) {
    doc.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a[href]');
      if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      if (a.target && a.target !== '_self') return;
      if (a.hasAttribute('download')) return;
      var url;
      try { url = new URL(a.href, location.href); } catch (err) { return; }
      if (url.origin !== location.origin || url.pathname === location.pathname && url.search === location.search) return;
      doc.body.classList.add('is-leaving');
    });
    window.addEventListener('pageshow', function (e) { if (e.persisted) doc.body.classList.remove('is-leaving'); });
  }

  /* ------------------------------ live status ----------------------------- */
  var statusRoot = $('[data-status-list]');
  var footerDot = $('[data-footer-status-dot]');
  if (statusRoot || footerDot) {
    var STATUS_CLASSES = ['operational', 'maintenance', 'degraded', 'partial_outage', 'major_outage'];
    var setDot = function (el, status) {
      if (!el) return;
      STATUS_CLASSES.forEach(function (s) { el.classList.remove('dot--' + s); });
      el.classList.add('dot--' + status);
    };
    var applySnapshot = function (snap) {
      if (!snap || !snap.overall) return;
      var banner = $('[data-status-overall]');
      if (banner) {
        STATUS_CLASSES.forEach(function (s) { banner.classList.remove('status-banner--' + s); });
        banner.classList.add('status-banner--' + snap.overall.status);
        setDot($('.dot', banner), snap.overall.status);
        var t = $('[data-status-overall-text]', banner);
        if (t) t.textContent = snap.overall.label;
      }
      (snap.services || []).forEach(function (s) {
        var item = $('[data-service="' + s.slug + '"]');
        if (!item) return;
        var pill = $('.status-pill', item);
        var label = $('[data-service-label]', item);
        if (label && label.textContent !== s.label) item.classList.add('is-updated');
        if (pill) {
          STATUS_CLASSES.forEach(function (c) { pill.classList.remove('status-pill--' + c); });
          pill.classList.add('status-pill--' + s.status);
          setDot($('.dot', pill), s.status);
        }
        if (label) label.textContent = s.label;
        setTimeout(function () { item.classList.remove('is-updated'); }, 1500);
      });
      setDot(footerDot, snap.overall.status);
      var ft = $('[data-footer-status-text]');
      if (ft) ft.textContent = snap.overall.label;
    };

    var retry = 0;
    var connect = function () {
      if (!('WebSocket' in window)) return;
      var proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
      var ws;
      try { ws = new WebSocket(proto + '//' + location.host + '/ws'); } catch (err) { return; }
      ws.onopen = function () { retry = 0; };
      ws.onmessage = function (ev) {
        try {
          var msg = JSON.parse(ev.data);
          if (msg.type === 'status') applySnapshot(msg.payload);
        } catch (err) { /* ignore malformed */ }
      };
      ws.onclose = function () {
        if (doc.hidden) return;
        retry = Math.min(retry + 1, 6);
        setTimeout(connect, Math.min(30000, 1000 * Math.pow(2, retry)));
      };
    };
    connect();
  }
})();
