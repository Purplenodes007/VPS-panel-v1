'use strict';
/**
 * Smoke test: node scripts/check.js
 * Env: BASE (default http://localhost:3000), SETUP_TOKEN (to create the first admin),
 *      ADMIN_USER / ADMIN_PASS (existing local admin credentials, if setup is already done).
 */
const BASE = process.env.BASE || 'http://localhost:3000';
let cookie = '';
let pass = 0, fail = 0;

function ok(name, cond, extra = '') {
  if (cond) { pass++; } else { fail++; console.log(`  FAIL ${name} ${extra}`); }
}
async function req(method, path, { body, headers = {}, raw } = {}) {
  const opts = { method, redirect: 'manual', headers: { ...headers } };
  if (cookie) opts.headers.cookie = cookie;
  if (body && !raw) { opts.headers['content-type'] = 'application/x-www-form-urlencoded'; opts.body = new URLSearchParams(body).toString(); }
  if (raw) opts.body = raw;
  const res = await fetch(BASE + path, opts);
  const sc = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
  for (const c of sc) {
    const [pair] = c.split(';');
    const name = pair.split('=')[0];
    cookie = cookie.split('; ').filter((p) => p && !p.startsWith(name + '=')).concat(pair).join('; ');
  }
  const text = await res.text();
  return { status: res.status, text, headers: res.headers, location: res.headers.get('location') };
}
const csrfOf = (html) => (/name="_csrf" value="([^"]+)"/.exec(html) || /name="csrf-token" content="([^"]+)"/.exec(html) || [])[1];

(async () => {
  // ---- public
  for (const p of ['/', '/plans', '/category/vps', '/category/game-hosting', '/posts', '/posts/welcome-to-vantixnodes', '/team', '/status', '/contact', '/auth/login', '/auth/admin', '/robots.txt', '/sitemap.xml',
    '/api/categories', '/api/categories/vps', '/api/plans', '/api/plans/1', '/api/posts', '/api/posts/welcome-to-vantixnodes', '/api/team', '/api/status', '/api/socials']) {
    const r = await req('GET', p);
    ok(`GET ${p}`, r.status === 200, `-> ${r.status}`);
  }
  ok('404 page', (await req('GET', '/nope')).status === 404);
  ok('404 post', (await req('GET', '/posts/does-not-exist')).status === 404);
  ok('/admin redirects when anonymous', (await req('GET', '/admin')).status === 302);
  ok('/account redirects when anonymous', (await req('GET', '/account')).status === 302);
  ok('/apply redirects when anonymous', (await req('GET', '/apply')).status === 302);
  ok('/api/admin/stats 401', (await req('GET', '/api/admin/stats')).status === 401);
  ok('POST without csrf -> 403', (await req('POST', '/contact', { body: { name: 'x' } })).status === 403);
  const home = await req('GET', '/');
  ok('CSP header', (home.headers.get('content-security-policy') || '').includes("default-src 'self'"));
  ok('no x-powered-by', !home.headers.get('x-powered-by'));
  ok('home has hero title', home.text.includes('Power Your Projects With VantixNodes'));

  // ---- contact form
  let r = await req('GET', '/contact');
  let t = csrfOf(r.text);
  r = await req('POST', '/contact', { body: { _csrf: t, name: 'Test User', email: 'test@example.com', subject: 'Hello there', message: 'This is a test message from the smoke test.' } });
  ok('contact submit redirects', r.status === 302, `-> ${r.status}`);
  r = await req('POST', '/contact', { body: { _csrf: t, name: 'T', email: 'bad', subject: '', message: 'x' } });
  ok('contact validation 400', r.status === 400);

  // ---- admin login / setup
  cookie = '';
  if (process.env.SETUP_TOKEN) {
    r = await req('GET', `/setup?token=${process.env.SETUP_TOKEN}`);
    ok('setup page', r.status === 200, `-> ${r.status}`);
    t = csrfOf(r.text);
    r = await req('POST', '/setup', { body: { _csrf: t, token: process.env.SETUP_TOKEN, username: 'owner', password: 'weak', confirm: 'weak' } });
    ok('setup weak password rejected', r.status === 400);
    r = await req('POST', '/setup', { body: { _csrf: t, token: process.env.SETUP_TOKEN, username: 'owner', password: 'Sup3rSecretPass!', confirm: 'Sup3rSecretPass!' } });
    ok('setup creates admin', r.status === 302 && r.location === '/admin', `-> ${r.status} ${r.location}`);
    r = await req('GET', `/setup?token=${process.env.SETUP_TOKEN}`);
    ok('setup closed afterwards', r.status === 403);
  } else {
    r = await req('GET', '/auth/admin');
    t = csrfOf(r.text);
    r = await req('POST', '/auth/admin', { body: { _csrf: t, username: process.env.ADMIN_USER || 'owner', password: process.env.ADMIN_PASS || 'Sup3rSecretPass!' } });
    ok('admin login', r.status === 302, `-> ${r.status}`);
  }

  // ---- admin GETs
  const adminPaths = ['/admin', '/admin/settings', '/admin/settings?tab=hero', '/admin/settings?tab=seo', '/admin/theme', '/admin/background', '/admin/categories', '/admin/categories/new', '/admin/categories/1/edit',
    '/admin/plans', '/admin/plans?category=1', '/admin/plans/new', '/admin/plans/1/edit', '/admin/applications', '/admin/applications/questions', '/admin/applications/questions/1', '/admin/team', '/admin/team/new',
    '/admin/posts', '/admin/posts/new', '/admin/posts/1/edit', '/admin/socials', '/admin/socials/1', '/admin/status', '/admin/tickets', '/admin/tickets/categories', '/admin/contact', '/admin/users', '/admin/users/1',
    '/admin/audit', '/admin/security', '/account', '/account/applications', '/account/tickets', '/account/tickets/new', '/apply', '/api/admin/stats', '/api/admin/audit'];
  for (const p of adminPaths) {
    r = await req('GET', p);
    ok(`GET ${p}`, r.status === 200, `-> ${r.status}`);
  }
  r = await req('GET', '/admin');
  t = csrfOf(r.text);
  ok('admin csrf token present', !!t);
  const post = async (path, body, expect = 302, label) => {
    const res = await req('POST', path, { body: { _csrf: t, ...body } });
    ok(label || `POST ${path}`, res.status === expect, `-> ${res.status} ${(res.text.match(/<li>([^<]+)<\/li>/) || [])[1] || ''}`);
    return res;
  };

  // ---- CRUD
  await post('/admin/categories', { name: 'Dedicated Servers', description: 'Bare metal', icon: 'cpu', status: '1' }, 302, 'create category');
  r = await req('GET', '/category/dedicated-servers');
  ok('new category page live', r.status === 200);
  await post('/admin/categories', { name: '', icon: 'cpu' }, 400, 'category validation');
  await post('/admin/plans', { category_id: '6', name: 'Dedi One', price: '49.99', currency: 'USD', billing_period: 'month', cpu: '8 cores', ram: '32 GB', storage: '1 TB NVMe', features: 'IPMI\nDDoS', badge: 'New', color: '#22d3ee', status: '1' }, 302, 'create plan');
  r = await req('GET', '/api/plans?category=dedicated-servers');
  ok('plan visible via API', r.text.includes('Dedi One'));
  await post('/admin/plans', { category_id: '6', name: 'Bad', price: '-5' }, 400, 'plan validation');
  await post('/admin/plans/1/toggle', {}, 302, 'toggle plan');
  await post('/admin/plans/1/toggle', {}, 302, 'toggle plan back');
  await post('/admin/plans/2/move', { dir: 'up' }, 302, 'move plan');
  await post('/admin/categories/2/move', { dir: 'down' }, 302, 'move category');
  await post('/admin/posts', { title: 'Smoke Test Post', content: '## Hello\n\nThis is **bold** and <script>alert(1)</script>.', category: 'update', published: '1', description: 'desc' }, 302, 'create post');
  r = await req('GET', '/posts/smoke-test-post');
  ok('post live + escaped', r.status === 200 && r.text.includes('&lt;script&gt;') && !r.text.includes('<script>alert(1)'));
  await post('/admin/posts/3/publish', { publish: '0' }, 302, 'unpublish post');
  r = await req('GET', '/posts/smoke-test-post');
  ok('unpublished post hidden', r.status === 404);
  await post('/admin/socials', { platform: 'Telegram', display_name: 'Telegram', url: 'https://t.me/x', icon: 'telegram', status: '1' }, 302, 'create social');
  await post('/admin/socials', { platform: 'Bad', url: 'javascript:alert(1)' }, 400, 'social rejects javascript: url');
  await post('/admin/team', { name: 'Jane Doe', username: 'jane', role: 'Support', bio: 'Hi', social_links: 'Site | https://example.com', status: '1' }, 302, 'create team member');
  r = await req('GET', '/team');
  ok('team member visible', r.text.includes('Jane Doe'));
  await post('/admin/applications/questions', { label: 'Favourite OS?', type: 'select', options: 'Linux\nWindows', required: '1', status: '1' }, 302, 'create question');
  await post('/admin/applications/settings', { applications_open: '1', applications_intro: 'Hi', applications_positions: 'Support\nMod', auto_create_team: '1' }, 302, 'application settings');
  await post('/admin/status', { status_1: 'degraded', source_1: 'manual', visible_1: '1', description_1: 'KVM' }, 302, 'update status');
  r = await req('GET', '/api/status');
  ok('status reflected in API', r.text.includes('"degraded"') && r.text.includes('Degraded Performance'));
  await post('/admin/status/stats', { stat_uptime: '99.95%', stat_locations: '7', stat_servers: '300+', stat_customers: '2,000+', stat_network: '10 Gbps' }, 302, 'save stats');
  await post('/admin/status', { status_1: 'operational', source_1: 'manual', visible_1: '1' }, 302, 'restore status');
  await post('/admin/settings/general', { site_name: 'VantixNodes', site_tagline: 'x', site_description: 'y', footer_text: 'z', contact_email: 'a@b.co' }, 302, 'save general settings');
  await post('/admin/settings/general', { site_name: '', contact_email: 'nope' }, 400, 'general validation');
  await post('/admin/settings/hero', { hero_title: 'Power Your Projects With VantixNodes', hero_subtitle: 's', hero_btn1_text: 'View Plans', hero_btn1_url: '/#plans', hero_btn2_text: 'Get Started', hero_btn2_url: '/auth/login', hero_btn3_text: 'Join Discord', hero_btn3_url: 'https://discord.gg/' }, 302, 'save hero');
  await post('/admin/settings/seo', { seo_title: 'T', seo_description: 'D', seo_keywords: 'k' }, 302, 'save seo');
  await post('/admin/theme', { color_primary: '#ff0066', color_secondary: '#22d3ee', color_accent: '#a855f7', color_background: '#07090f', color_surface: '#0e1220', color_text: '#e8ecf6', color_muted: '#8b94ad', color_border: '#1f2740', button_style: 'pill', border_radius: '12', font: 'Poppins', animations_enabled: '1' }, 302, 'save theme');
  r = await req('GET', '/');
  ok('theme applied to site', r.text.includes('--primary:#ff0066') && r.text.includes('Poppins') && r.text.includes('btn-pill'));
  await post('/admin/theme', { color_primary: 'red', color_secondary: '#22d3ee' }, 400, 'theme validation');
  await post('/admin/theme', { reset: '1' }, 302, 'reset theme');
  await post('/admin/background', { bg_type: 'video', bg_video_url: 'https://example.com/v.mp4', bg_overlay: '50', bg_video_opacity: '70', bg_gradient_angle: '160' }, 302, 'background video');
  r = await req('GET', '/');
  ok('video background rendered', r.text.includes('<video') && r.text.includes('autoplay muted loop playsinline'));
  await post('/admin/background', { bg_type: 'image', bg_image_url: '' }, 400, 'image background needs url');
  await post('/admin/background', { bg_type: 'gradient', bg_gradient_from: '#07090f', bg_gradient_to: '#141a33', bg_gradient_angle: '160', bg_overlay: '60', bg_video_opacity: '60' }, 302, 'background gradient');

  // ---- upload validation
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  const boundary = '----vx' + Date.now();
  const multipart = (name, type, buf) => Buffer.concat([
    Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${name}"\r\nContent-Type: ${type}\r\n\r\n`), buf, Buffer.from(`\r\n--${boundary}--\r\n`)]);
  const up = (name, type, buf) => req('POST', '/admin/upload', { raw: multipart(name, type, buf), headers: { 'content-type': `multipart/form-data; boundary=${boundary}`, 'x-csrf-token': t, accept: 'application/json' } });
  r = await up('a.png', 'image/png', png);
  ok('upload valid png', r.status === 200 && /"url":"\/uploads\/[a-z0-9-]+\.png"/.test(r.text), r.text);
  const url = (JSON.parse(r.text || '{}')).url;
  if (url) { const f = await req('GET', url); ok('uploaded file served with nosniff', f.status === 200 && f.headers.get('x-content-type-options') === 'nosniff'); }
  r = await up('evil.php', 'application/x-php', Buffer.from('<?php echo 1;'));
  ok('upload php rejected', r.status === 400);
  r = await up('fake.png', 'image/png', Buffer.from('<?php echo 1;'));
  ok('upload fake png rejected (magic bytes)', r.status === 400);
  r = await up('x.svg', 'image/svg+xml', Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'));
  ok('upload malicious svg rejected', r.status === 400);
  r = await up('ok.svg', 'image/svg+xml', Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"><rect width="1" height="1"/></svg>'));
  ok('upload clean svg accepted', r.status === 200);
  r = await req('POST', '/admin/upload', { raw: multipart('a.png', 'image/png', png), headers: { 'content-type': `multipart/form-data; boundary=${boundary}`, accept: 'application/json' } });
  ok('upload without csrf rejected', r.status === 403);

  // ---- backups, users, security
  await post('/admin/security/backups', {}, 302, 'create backup');
  r = await req('GET', '/admin/security');
  const bname = (/backups\/(backup-[0-9a-f-]+\.sqlite)"/.exec(r.text) || [])[1];
  ok('backup listed', !!bname);
  if (bname) {
    r = await req('GET', `/admin/security/backups/${bname}`);
    ok('backup download', r.status === 200 && r.text.startsWith('SQLite format 3'));
    r = await req('GET', '/admin/security/backups/..%2f..%2fetc%2fpasswd');
    ok('backup path traversal blocked', r.status === 404);
  }
  r = await req('GET', '/data/database.sqlite');
  ok('database not exposed', r.status === 404);
  r = await req('GET', '/.env');
  ok('.env not exposed', r.status === 404);
  r = await req('GET', '/backups/');
  ok('backups dir not exposed', r.status === 404);
  await post('/admin/security/roles/moderator', { permissions: ['tickets', 'contact'] }, 302, 'save role permissions');
  r = await req('GET', '/admin/audit');
  ok('audit log has entries', r.text.includes('Created category') && r.text.includes('Changed theme'));

  // ---- staff ticket flow via DB-less path: create ticket as admin (they are a user too)
  r = await req('GET', '/account/tickets/new');
  t = csrfOf(r.text);
  r = await req('POST', '/account/tickets', { body: { _csrf: t, subject: 'Test ticket subject', category: 'General', priority: 'normal', message: 'Please help me with this test.' } });
  ok('ticket created', r.status === 302 && /\/account\/tickets\/\d+/.test(r.location || ''), `-> ${r.status}`);
  const tid = (/\/(\d+)$/.exec(r.location || '') || [])[1];
  if (tid) {
    r = await req('POST', `/admin/tickets/${tid}/reply`, { body: { _csrf: t, message: 'Staff reply here', status: 'pending' } });
    ok('staff reply', r.status === 302);
    r = await req('GET', `/account/tickets/${tid}`);
    ok('reply visible to user', r.text.includes('Staff reply here'));
  }
  r = await req('GET', '/apply');
  ok('apply form shows dynamic question', r.text.includes('Favourite OS?'));
  t = csrfOf(r.text);
  r = await req('POST', '/apply', { body: { _csrf: t, position: 'Support', q_1: 'Owner', q_2: '25', q_3: 'owner#0001', q_4: 'Lots', q_5: 'Because', q_6: '10h', q_8: 'Linux' } });
  ok('application submitted', r.status === 302, `-> ${r.status} ${(r.text.match(/<li>([^<]+)<\/li>/) || [])[1] || ''}`);
  r = await req('GET', '/admin/applications');
  const aid = (/applications\/(\d+)"/.exec(r.text) || [])[1];
  if (aid) {
    r = await req('GET', `/admin/applications/${aid}`);
    ok('application detail', r.status === 200 && r.text.includes('Favourite OS?'));
    t = csrfOf(r.text);
    r = await req('POST', `/admin/applications/${aid}/review`, { body: { _csrf: t, status: 'approved', internal_note: 'good', add_to_team: '1' } });
    ok('approve application', r.status === 302);
    r = await req('GET', '/team');
    ok('approved applicant on team page', r.text.includes('Owner'));
  }

  // ---- logout + access control
  r = await req('GET', '/admin');
  t = csrfOf(r.text);
  r = await req('POST', '/auth/logout', { body: { _csrf: t } });
  ok('logout', r.status === 302);
  r = await req('GET', '/admin');
  ok('admin blocked after logout', r.status === 302);
  r = await req('POST', '/admin/plans/1/delete', { body: {} });
  ok('admin POST blocked when anonymous', r.status === 302 || r.status === 401 || r.status === 403);

  // ---- rate limit on admin login
  let limited = false;
  r = await req('GET', '/auth/admin');
  t = csrfOf(r.text);
  for (let i = 0; i < 14; i++) {
    r = await req('POST', '/auth/admin', { body: { _csrf: t, username: 'owner', password: 'wrong' + i } });
    if (r.status === 429) { limited = true; break; }
  }
  ok('admin login rate limited', limited);

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
