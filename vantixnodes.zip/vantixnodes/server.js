'use strict';
require('./src/utils/nodeCheck');

const http = require('http');
const config = require('./src/config');
const { initDatabase } = require('./src/database/init');
const { closeDb } = require('./src/database/connection');

// Idempotent: creates the database on first run, applies pending migrations, never overwrites data.
const init = initDatabase();
if (init.seeded) console.log('Database initialised with default content.');

const { createApp } = require('./src/app');
const wsService = require('./src/services/wsService');
const statusService = require('./src/services/statusService');
const { adminExists } = require('./src/services/setupService');

const app = createApp();
const server = http.createServer(app);
wsService.attach(server);
statusService.startPolling();

server.listen(config.port, () => {
  console.log(`VantixNodes running on ${config.siteUrl} (port ${config.port}, ${config.isProd ? 'production' : 'development'})`);
  if (!adminExists()) {
    console.log('No administrator exists yet - run `npm run setup` to get the one-time admin setup link.');
  }
});

function shutdown(signal) {
  console.log(`\n${signal} received, shutting down...`);
  server.close(() => {
    closeDb();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('unhandledRejection', (err) => console.error('Unhandled rejection:', err));
