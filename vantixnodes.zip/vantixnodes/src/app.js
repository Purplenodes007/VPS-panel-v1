'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const compression = require('compression');

const config = require('./config');
const SqliteStore = require('./services/sessionStore');
const security = require('./middleware/security');
const locals = require('./middleware/locals');
const { loadUser, csrfProtection } = require('./middleware/auth');
const { notFound, errorHandler } = require('./middleware/errorHandler');
const roleService = require('./services/roleService');

const publicRoutes = require('./routes/public');
const apiRoutes = require('./routes/api');
const authRoutes = require('./routes/auth');
const accountRoutes = require('./routes/account');
const adminRoutes = require('./routes/admin');

/** Session secret: env var wins; otherwise a random one is generated once and kept outside the web root. */
function resolveSessionSecret() {
  if (config.sessionSecret && config.sessionSecret.length >= 16) return config.sessionSecret;
  const file = path.join(path.dirname(config.databasePath), '.session_secret');
  if (fs.existsSync(file)) return fs.readFileSync(file, 'utf8').trim();
  const secret = crypto.randomBytes(48).toString('hex');
  fs.writeFileSync(file, secret, { mode: 0o600 });
  console.warn('SESSION_SECRET is not set - generated one at data/.session_secret. Set SESSION_SECRET in .env for production.');
  return secret;
}

function createApp() {
  const app = express();
  const assetVersion = Date.now().toString(36);

  app.disable('x-powered-by');
  app.set('view engine', 'ejs');
  app.set('views', path.join(config.root, 'views'));
  app.set('trust proxy', config.trustProxy ? 1 : false);
  app.locals.assetVersion = assetVersion;

  app.use(security.nonce);
  app.use(security.helmetMiddleware());
  app.use(compression());

  // Uploaded files: never executed or sniffed; SVGs are sandboxed if opened directly.
  app.use(
    '/uploads',
    express.static(config.uploadDir, {
      index: false,
      dotfiles: 'ignore',
      maxAge: config.isProd ? '30d' : 0,
      immutable: config.isProd,
      setHeaders: (res) => {
        res.setHeader('X-Content-Type-Options', 'nosniff');
        res.setHeader('Content-Security-Policy', "default-src 'none'; img-src 'self' data:; media-src 'self'; style-src 'unsafe-inline'; sandbox");
        res.setHeader('Content-Disposition', 'inline');
      }
    })
  );

  app.use(
    express.static(path.join(config.root, 'public'), {
      index: false,
      dotfiles: 'ignore',
      maxAge: config.isProd ? '7d' : 0
    })
  );

  app.use(express.json({ limit: '100kb' }));
  app.use(express.urlencoded({ extended: false, limit: '200kb', parameterLimit: 200 }));

  app.use(
    session({
      name: config.session.cookieName,
      secret: resolveSessionSecret(),
      resave: false,
      saveUninitialized: false,
      rolling: true,
      proxy: config.trustProxy,
      store: new SqliteStore({ ttlMs: config.session.maxAgeMs }),
      cookie: {
        httpOnly: true,
        sameSite: 'lax',
        secure: config.secureCookies,
        maxAge: config.session.maxAgeMs
      }
    })
  );

  app.use(locals);
  app.use(loadUser);
  app.use(security.limiters.global);

  // Maintenance mode: staff and auth routes keep working.
  app.use((req, res, next) => {
    if (res.locals.settings.maintenance_mode !== '1') return next();
    if (res.locals.isStaff) return next();
    if (/^\/(auth|admin|setup|api\/status|robots\.txt)/.test(req.path)) return next();
    return res.status(503).page('errors/maintenance', { title: 'Maintenance' });
  });

  app.use(csrfProtection);

  app.use('/api', security.limiters.api, apiRoutes);
  app.use('/auth', authRoutes);
  app.use('/account', accountRoutes);
  app.use('/admin', adminRoutes);
  app.use('/', publicRoutes);

  app.use(notFound);
  app.use(errorHandler);

  roleService.reload();
  return app;
}

module.exports = { createApp };
