'use strict';

module.exports = {
  // Admin permission keys (one per admin section). superadmin has '*'.
  PERMISSIONS: [
    { key: 'overview', label: 'Overview dashboard' },
    { key: 'settings', label: 'Website settings & SEO' },
    { key: 'theme', label: 'Theme editor' },
    { key: 'background', label: 'Background' },
    { key: 'categories', label: 'Categories' },
    { key: 'plans', label: 'Plans' },
    { key: 'applications', label: 'Staff applications' },
    { key: 'team', label: 'Team' },
    { key: 'posts', label: 'Posts & news' },
    { key: 'socials', label: 'Social links' },
    { key: 'users', label: 'Users' },
    { key: 'status', label: 'Status & statistics' },
    { key: 'tickets', label: 'Support tickets' },
    { key: 'contact', label: 'Contact messages' },
    { key: 'audit', label: 'Audit logs' }
  ],

  SERVICE_STATUSES: {
    operational: { label: 'Operational', severity: 0 },
    maintenance: { label: 'Maintenance', severity: 1 },
    degraded: { label: 'Degraded Performance', severity: 2 },
    partial_outage: { label: 'Partial Outage', severity: 3 },
    major_outage: { label: 'Major Outage', severity: 4 }
  },

  APPLICATION_STATUSES: {
    pending: 'Pending',
    under_review: 'Under Review',
    approved: 'Approved',
    rejected: 'Rejected'
  },

  TICKET_STATUSES: { open: 'Open', pending: 'Pending', closed: 'Closed' },
  TICKET_PRIORITIES: { low: 'Low', normal: 'Normal', high: 'High', urgent: 'Urgent' },

  POST_CATEGORIES: {
    news: 'News',
    announcement: 'Announcement',
    update: 'Update',
    maintenance: 'Maintenance',
    tutorial: 'Tutorial',
    promotion: 'Promotion'
  },

  QUESTION_TYPES: { text: 'Short text', textarea: 'Long text', number: 'Number', url: 'URL', select: 'Dropdown' },

  BILLING_PERIODS: { hour: 'hour', day: 'day', month: 'month', quarter: 'quarter', year: 'year', once: 'one-time' },

  FONTS: {
    Inter: 'Inter:wght@400;500;600;700;800',
    Poppins: 'Poppins:wght@400;500;600;700;800',
    'Space Grotesk': 'Space+Grotesk:wght@400;500;600;700',
    Manrope: 'Manrope:wght@400;500;600;700;800',
    Outfit: 'Outfit:wght@400;500;600;700;800',
    'DM Sans': 'DM+Sans:wght@400;500;600;700',
    'Plus Jakarta Sans': 'Plus+Jakarta+Sans:wght@400;500;600;700;800',
    System: null
  },

  BUTTON_STYLES: ['gradient', 'solid', 'outline', 'pill', 'square'],
  BG_TYPES: ['none', 'color', 'gradient', 'image', 'video'],
  ROLES_ORDER: ['user', 'moderator', 'admin', 'superadmin']
};
