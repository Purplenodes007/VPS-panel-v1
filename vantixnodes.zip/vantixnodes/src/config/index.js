'use strict';

const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '..', '.env') });

const root = path.join(__dirname, '..', '..');
const isProd = process.env.NODE_ENV === 'production';

function resolvePath(p, fallback) {
  const value = p || fallback;
  return path.isAbsolute(value) ? value : path.join(root, value);
}

const port = parseInt(process.env.PORT, 10) || 3000;
const siteUrl = (process.env.SITE_URL || `http://localhost:${port}`).replace(/\/+$/, '');

module.exports = {
  root,
  isProd,
  port,
  siteUrl,
  trustProxy: String(process.env.TRUST_PROXY || '').toLowerCase() === 'true',
  sessionSecret: process.env.SESSION_SECRET || '',
  databasePath: resolvePath(process.env.DATABASE_PATH, './data/database.sqlite'),
  backupDir: path.join(root, 'backups'),
  uploadDir: path.join(root, 'public', 'uploads'),
  secureCookies: siteUrl.startsWith('https://'),
  discord: {
    clientId: process.env.DISCORD_CLIENT_ID || '',
    clientSecret: process.env.DISCORD_CLIENT_SECRET || '',
    callbackUrl: process.env.DISCORD_CALLBACK_URL || `${siteUrl}/auth/discord/callback`,
    initialAdminId: process.env.INITIAL_ADMIN_DISCORD_ID || ''
  },
  session: {
    cookieName: 'vantix.sid',
    maxAgeMs: 1000 * 60 * 60 * 24 * 7, // 7 days
    adminIdleMs: 1000 * 60 * 60 * 2 // admin sessions expire after 2h idle
  },
  upload: {
    maxImageBytes: 5 * 1024 * 1024,
    maxVideoBytes: 60 * 1024 * 1024
  }
};
