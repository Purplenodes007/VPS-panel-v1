'use strict';

const { getDb } = require('../database/connection');
const content = require('../models/content');
const settings = require('../services/settingsService');
const audit = require('../services/auditService');
const { str, int, safeUrl, getIp, linesToArray } = require('../utils/helpers');
const { TICKET_PRIORITIES } = require('../config/constants');

/* ------------------------------ dashboard ------------------------------ */
function dashboard(req, res) {
  const db = getDb();
  const uid = req.user.id;
  const applications = content.applications.listForUser(uid);
  const tickets = content.tickets.listForUser(uid);
  const notifications = db.prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 8').all(uid);
  const activity = db.prepare('SELECT * FROM user_activity WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 10').all(uid);
  const unread = db.prepare('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND is_read = 0').get(uid).n;
  res.page('account/dashboard', {
    title: 'My account',
    noindex: true,
    applications,
    tickets,
    openTickets: tickets.filter((t) => t.status !== 'closed').length,
    notifications,
    unread,
    activity
  });
}

function markNotificationsRead(req, res) {
  getDb().prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(req.user.id);
  res.redirect('/account');
}

/* ----------------------------- applications ----------------------------- */
function applyContext() {
  return {
    open: settings.get('applications_open') === '1',
    intro: settings.get('applications_intro'),
    positions: linesToArray(settings.get('applications_positions'), 20, 80),
    questions: content.applications.questions(true)
  };
}

function applyPage(req, res) {
  const ctx = applyContext();
  res.page('account/apply', {
    title: 'Staff application',
    noindex: true,
    ...ctx,
    hasActive: content.applications.hasActive(req.user.id),
    form: {},
    errors: []
  });
}

function applySubmit(req, res) {
  const ctx = applyContext();
  const hasActive = content.applications.hasActive(req.user.id);
  if (!ctx.open || hasActive) {
    req.flash('error', !ctx.open ? 'Applications are currently closed.' : 'You already have an application under review.');
    return res.redirect('/apply');
  }

  const errors = [];
  const form = { position: str(req.body.position, 80) };
  if (ctx.positions.length && !ctx.positions.includes(form.position)) errors.push('Please choose a position.');
  if (!ctx.positions.length && !form.position) form.position = 'General';

  const answers = [];
  for (const q of ctx.questions) {
    const key = `q_${q.id}`;
    let value = str(req.body[key], q.type === 'textarea' ? 4000 : 500);
    form[key] = value;
    if (!value) {
      if (q.required) errors.push(`"${q.label}" is required.`);
      continue;
    }
    if (q.type === 'number' && !/^\d{1,4}$/.test(value)) {
      errors.push(`"${q.label}" must be a number.`);
      continue;
    }
    if (q.type === 'url') {
      value = safeUrl(value, { allowRelative: false });
      if (!value) {
        errors.push(`"${q.label}" must be a valid http(s) link.`);
        continue;
      }
    }
    if (q.type === 'select') {
      const options = linesToArray(q.options, 30, 100);
      if (!options.includes(value)) {
        errors.push(`"${q.label}" has an invalid choice.`);
        continue;
      }
    }
    answers.push({ question_id: q.id, label: q.label, answer: value });
  }

  if (errors.length) {
    return res.status(400).page('account/apply', { title: 'Staff application', noindex: true, ...ctx, hasActive, form, errors });
  }

  const id = content.applications.submit({ userId: req.user.id, position: form.position, answers });
  audit.userActivity(req.user.id, `Submitted staff application #${id}`, getIp(req));
  audit.notify(req.user.id, 'Application received', `Your application for ${form.position} is now pending review.`, '/account/applications');
  req.flash('success', 'Application submitted. We will review it soon.');
  return res.redirect('/account/applications');
}

function myApplications(req, res) {
  const apps = content.applications.listForUser(req.user.id);
  res.page('account/applications', { title: 'My applications', noindex: true, applications: apps });
}

function myApplicationDetail(req, res, next) {
  const app = content.applications.byId(int(req.params.id));
  if (!app || app.user_id !== req.user.id) return next();
  return res.page('account/application', {
    title: `Application #${app.id}`,
    noindex: true,
    application: app,
    answers: content.applications.answers(app.id)
  });
}

/* -------------------------------- tickets -------------------------------- */
function ticketsList(req, res) {
  res.page('account/tickets', { title: 'Support tickets', noindex: true, tickets: content.tickets.listForUser(req.user.id) });
}

function ticketNew(req, res) {
  const categories = content.tickets.categories();
  const form = {
    subject: str(req.query.subject, 150),
    category: categories.some((c) => c.name === req.query.category) ? req.query.category : ''
  };
  res.page('account/ticket-new', { title: 'New ticket', noindex: true, categories, form, errors: [] });
}

function ticketCreate(req, res) {
  const categories = content.tickets.categories();
  const form = {
    subject: str(req.body.subject, 150),
    category: str(req.body.category, 80),
    priority: str(req.body.priority, 20),
    message: str(req.body.message, 8000)
  };
  const errors = [];
  if (form.subject.length < 4) errors.push('Please enter a subject (at least 4 characters).');
  if (!categories.some((c) => c.name === form.category)) errors.push('Please choose a category.');
  if (!TICKET_PRIORITIES[form.priority]) errors.push('Please choose a priority.');
  if (form.message.length < 10) errors.push('Please describe your issue (at least 10 characters).');
  const openCount = getDb().prepare("SELECT COUNT(*) AS n FROM tickets WHERE user_id = ? AND status != 'closed'").get(req.user.id).n;
  if (openCount >= 10) errors.push('You have too many open tickets. Please wait for existing ones to be resolved.');
  if (errors.length) return res.status(400).page('account/ticket-new', { title: 'New ticket', noindex: true, categories, form, errors });

  const id = content.tickets.create({ userId: req.user.id, subject: form.subject, category: form.category, priority: form.priority, message: form.message });
  audit.userActivity(req.user.id, `Opened ticket #${id}`, getIp(req));
  req.flash('success', `Ticket #${id} created. Our team will respond soon.`);
  return res.redirect(`/account/tickets/${id}`);
}

function ownTicket(req) {
  const t = content.tickets.byId(int(req.params.id));
  return t && t.user_id === req.user.id ? t : null;
}

function ticketView(req, res, next) {
  const ticket = ownTicket(req);
  if (!ticket) return next();
  return res.page('account/ticket', { title: `Ticket #${ticket.id}`, noindex: true, ticket, messages: content.tickets.messages(ticket.id), errors: [] });
}

function ticketReply(req, res, next) {
  const ticket = ownTicket(req);
  if (!ticket) return next();
  const message = str(req.body.message, 8000);
  if (message.length < 2) {
    req.flash('error', 'Please write a message.');
    return res.redirect(`/account/tickets/${ticket.id}`);
  }
  content.tickets.addMessage({ ticketId: ticket.id, userId: req.user.id, isStaff: false, message, status: 'open' });
  audit.userActivity(req.user.id, `Replied to ticket #${ticket.id}`, getIp(req));
  req.flash('success', 'Reply sent.');
  return res.redirect(`/account/tickets/${ticket.id}`);
}

function ticketClose(req, res, next) {
  const ticket = ownTicket(req);
  if (!ticket) return next();
  content.tickets.setStatus(ticket.id, 'closed');
  audit.userActivity(req.user.id, `Closed ticket #${ticket.id}`, getIp(req));
  req.flash('success', 'Ticket closed.');
  return res.redirect(`/account/tickets/${ticket.id}`);
}

module.exports = {
  dashboard,
  markNotificationsRead,
  applyPage,
  applySubmit,
  myApplications,
  myApplicationDetail,
  ticketsList,
  ticketNew,
  ticketCreate,
  ticketView,
  ticketReply,
  ticketClose
};
