'use strict';

const { getDb } = require('../../database/connection');
const catalog = require('../../models/catalog');
const audit = require('../../services/auditService');
const settings = require('../../services/settingsService');
const statusService = require('../../services/statusService');
const { NAMES: ICONS } = require('../../utils/icons');
const { str, int, num, bool, safeUrl, isHexColor, uniqueSlug, slugify, linesToArray } = require('../../utils/helpers');
const { BILLING_PERIODS, SERVICE_STATUSES } = require('../../config/constants');

const SOCIAL_ICONS = ['discord', 'youtube', 'github', 'x', 'instagram', 'facebook', 'telegram', 'tiktok', 'link', 'mail', 'globe'];

function moveRoute(table, redirect, scopeColumn = null) {
  return (req, res) => {
    const dir = req.body.dir === 'up' ? 'up' : 'down';
    catalog.move(table, int(req.params.id), dir, scopeColumn);
    audit.log(req, `Reordered ${table}`, `id:${req.params.id}`, dir);
    res.redirect(typeof redirect === 'function' ? redirect(req) : redirect);
  };
}

/* ------------------------------- categories ------------------------------ */
const categories = {
  list(req, res) {
    res.page('admin/categories', { title: 'Categories', adminSection: 'categories', items: catalog.categories.listAll() }, 'admin');
  },
  newForm(req, res) {
    res.page('admin/category-form', { title: 'New category', adminSection: 'categories', item: { status: 1, icon: 'server' }, errors: [], isNew: true }, 'admin');
  },
  editForm(req, res, next) {
    const item = catalog.categories.byId(int(req.params.id));
    if (!item) return next();
    return res.page('admin/category-form', { title: `Edit ${item.name}`, adminSection: 'categories', item, errors: [], isNew: false }, 'admin');
  },
  parse(req, id = 0) {
    const b = req.body;
    const errors = [];
    const data = {
      name: str(b.name, 60),
      description: str(b.description, 400),
      icon: ICONS.includes(b.icon) ? b.icon : 'server',
      image: safeUrl(b.image),
      status: bool(b.status)
    };
    if (!data.name) errors.push('Name is required.');
    if (str(b.image) && !data.image) errors.push('Image must be an http(s) link or an uploaded file.');
    data.slug = uniqueSlug(getDb(), 'categories', 'slug', str(b.slug, 80) || data.name, id);
    return { data, errors };
  },
  create(req, res) {
    const { data, errors } = categories.parse(req);
    if (errors.length) return res.status(400).page('admin/category-form', { title: 'New category', adminSection: 'categories', item: { ...data, ...req.body }, errors, isNew: true }, 'admin');
    data.display_order = catalog.nextOrder('categories');
    const id = catalog.categories.insert(data);
    audit.log(req, 'Created category', `category:${id}`, data.name);
    req.flash('success', 'Category created.');
    return res.redirect('/admin/categories');
  },
  update(req, res, next) {
    const id = int(req.params.id);
    const existing = catalog.categories.byId(id);
    if (!existing) return next();
    const { data, errors } = categories.parse(req, id);
    if (errors.length) return res.status(400).page('admin/category-form', { title: `Edit ${existing.name}`, adminSection: 'categories', item: { ...existing, ...data, id }, errors, isNew: false }, 'admin');
    catalog.categories.update(id, data);
    audit.log(req, 'Updated category', `category:${id}`, data.name);
    req.flash('success', 'Category saved.');
    return res.redirect('/admin/categories');
  },
  remove(req, res, next) {
    const id = int(req.params.id);
    const existing = catalog.categories.byId(id);
    if (!existing) return next();
    catalog.categories.remove(id);
    audit.log(req, 'Deleted category', `category:${id}`, `${existing.name} (and its plans)`);
    req.flash('success', 'Category and its plans deleted.');
    return res.redirect('/admin/categories');
  },
  move: moveRoute('categories', '/admin/categories')
};

/* ---------------------------------- plans -------------------------------- */
const plans = {
  list(req, res) {
    const filter = int(req.query.category, 0, 0);
    res.page('admin/plans', { title: 'Plans', adminSection: 'plans', items: catalog.plans.listAll(filter || null), categories: catalog.categories.listAll(), filter }, 'admin');
  },
  newForm(req, res) {
    const categoriesList = catalog.categories.listAll();
    res.page(
      'admin/plan-form',
      { title: 'New plan', adminSection: 'plans', item: { status: 1, billing_period: 'month', currency: 'USD', category_id: int(req.query.category, categoriesList[0] ? categoriesList[0].id : 0), features: [] }, categories: categoriesList, periods: BILLING_PERIODS, errors: [], isNew: true },
      'admin'
    );
  },
  editForm(req, res, next) {
    const item = catalog.plans.byId(int(req.params.id));
    if (!item) return next();
    return res.page('admin/plan-form', { title: `Edit ${item.name}`, adminSection: 'plans', item, categories: catalog.categories.listAll(), periods: BILLING_PERIODS, errors: [], isNew: false }, 'admin');
  },
  parse(req) {
    const b = req.body;
    const errors = [];
    const category = catalog.categories.byId(int(b.category_id));
    const data = {
      category_id: category ? category.id : 0,
      name: str(b.name, 80),
      description: str(b.description, 300),
      price: num(b.price, 0, 0, 1000000),
      currency: /^[A-Z]{3}$/.test(str(b.currency, 3).toUpperCase()) ? str(b.currency, 3).toUpperCase() : 'USD',
      billing_period: Object.prototype.hasOwnProperty.call(BILLING_PERIODS, b.billing_period) ? b.billing_period : 'month',
      cpu: str(b.cpu, 60),
      ram: str(b.ram, 60),
      storage: str(b.storage, 60),
      bandwidth: str(b.bandwidth, 60),
      network_speed: str(b.network_speed, 60),
      locations: str(b.locations, 200),
      features: JSON.stringify(linesToArray(b.features, 20, 100)),
      badge: str(b.badge, 24),
      color: str(b.color, 7),
      order_url: safeUrl(b.order_url),
      status: bool(b.status)
    };
    if (!category) errors.push('Choose a category.');
    if (!data.name) errors.push('Plan name is required.');
    if (!(parseFloat(b.price) >= 0)) errors.push('Price must be a number (0 or more).');
    if (data.color && !isHexColor(data.color)) errors.push('Accent color must be a hex value like #6366f1 (or empty).');
    if (str(b.order_url) && !data.order_url) errors.push('Order link must be an http(s) URL or a path like /account.');
    return { data, errors };
  },
  formData(b, data) {
    return { ...b, ...data, features: linesToArray(b.features, 20, 100) };
  },
  create(req, res) {
    const { data, errors } = plans.parse(req);
    if (errors.length) {
      return res.status(400).page('admin/plan-form', { title: 'New plan', adminSection: 'plans', item: plans.formData(req.body, data), categories: catalog.categories.listAll(), periods: BILLING_PERIODS, errors, isNew: true }, 'admin');
    }
    data.display_order = catalog.nextOrder('plans', 'category_id', data.category_id);
    const id = catalog.plans.insert(data);
    audit.log(req, 'Created plan', `plan:${id}`, data.name);
    req.flash('success', 'Plan created.');
    return res.redirect('/admin/plans');
  },
  update(req, res, next) {
    const id = int(req.params.id);
    const existing = catalog.plans.byId(id);
    if (!existing) return next();
    const { data, errors } = plans.parse(req);
    if (errors.length) {
      return res.status(400).page('admin/plan-form', { title: `Edit ${existing.name}`, adminSection: 'plans', item: { ...plans.formData(req.body, data), id }, categories: catalog.categories.listAll(), periods: BILLING_PERIODS, errors, isNew: false }, 'admin');
    }
    if (data.category_id !== existing.category_id) {
      getDb().prepare('UPDATE plans SET display_order = ? WHERE id = ?').run(catalog.nextOrder('plans', 'category_id', data.category_id), id);
    }
    catalog.plans.update(id, data);
    audit.log(req, 'Updated plan', `plan:${id}`, data.name);
    req.flash('success', 'Plan saved.');
    return res.redirect('/admin/plans');
  },
  toggle(req, res, next) {
    const id = int(req.params.id);
    const existing = catalog.plans.byId(id);
    if (!existing) return next();
    catalog.plans.toggle(id);
    audit.log(req, existing.status ? 'Disabled plan' : 'Enabled plan', `plan:${id}`, existing.name);
    return res.redirect(req.get('referer') && req.get('referer').includes('/admin/plans') ? '/admin/plans' : '/admin/plans');
  },
  remove(req, res, next) {
    const id = int(req.params.id);
    const existing = catalog.plans.byId(id);
    if (!existing) return next();
    catalog.plans.remove(id);
    audit.log(req, 'Deleted plan', `plan:${id}`, existing.name);
    req.flash('success', 'Plan deleted.');
    return res.redirect('/admin/plans');
  },
  move: moveRoute('plans', '/admin/plans', 'category_id')
};

/* --------------------------------- socials ------------------------------- */
const socials = {
  list(req, res) {
    res.page('admin/socials', { title: 'Social links', adminSection: 'socials', items: catalog.socials.listAll(), icons: SOCIAL_ICONS, edit: null, errors: [] }, 'admin');
  },
  edit(req, res, next) {
    const edit = catalog.socials.byId(int(req.params.id));
    if (!edit) return next();
    return res.page('admin/socials', { title: 'Social links', adminSection: 'socials', items: catalog.socials.listAll(), icons: SOCIAL_ICONS, edit, errors: [] }, 'admin');
  },
  parse(req) {
    const b = req.body;
    const data = {
      platform: str(b.platform, 40),
      display_name: str(b.display_name, 60),
      url: safeUrl(b.url, { allowRelative: false }),
      icon: SOCIAL_ICONS.includes(b.icon) ? b.icon : 'link',
      status: bool(b.status)
    };
    const errors = [];
    if (!data.platform) errors.push('Platform is required.');
    if (!data.display_name) data.display_name = data.platform;
    if (!data.url) errors.push('A valid http(s) URL is required.');
    return { data, errors };
  },
  create(req, res) {
    const { data, errors } = socials.parse(req);
    if (errors.length) {
      return res.status(400).page('admin/socials', { title: 'Social links', adminSection: 'socials', items: catalog.socials.listAll(), icons: SOCIAL_ICONS, edit: null, errors, draft: req.body }, 'admin');
    }
    data.display_order = catalog.nextOrder('social_links');
    const id = catalog.socials.insert(data);
    audit.log(req, 'Created social link', `social:${id}`, data.platform);
    req.flash('success', 'Social link added.');
    return res.redirect('/admin/socials');
  },
  update(req, res, next) {
    const id = int(req.params.id);
    const existing = catalog.socials.byId(id);
    if (!existing) return next();
    const { data, errors } = socials.parse(req);
    if (errors.length) {
      return res.status(400).page('admin/socials', { title: 'Social links', adminSection: 'socials', items: catalog.socials.listAll(), icons: SOCIAL_ICONS, edit: { ...existing, ...data }, errors }, 'admin');
    }
    catalog.socials.update(id, data);
    audit.log(req, 'Updated social link', `social:${id}`, data.platform);
    req.flash('success', 'Social link saved.');
    return res.redirect('/admin/socials');
  },
  remove(req, res, next) {
    const id = int(req.params.id);
    const existing = catalog.socials.byId(id);
    if (!existing) return next();
    catalog.socials.remove(id);
    audit.log(req, 'Deleted social link', `social:${id}`, existing.platform);
    req.flash('success', 'Social link deleted.');
    return res.redirect('/admin/socials');
  },
  move: moveRoute('social_links', '/admin/socials')
};

/* ----------------------------------- team -------------------------------- */
function parseSocialLines(text) {
  // One link per line: "Label | https://url"
  return linesToArray(text, 8, 300)
    .map((line) => {
      const [label, url] = line.includes('|') ? line.split('|').map((s) => s.trim()) : [null, line];
      const safe = safeUrl(url, { allowRelative: false });
      return safe ? { label: (label || new URL(safe).hostname).slice(0, 30), url: safe } : null;
    })
    .filter(Boolean);
}

const team = {
  list(req, res) {
    res.page('admin/team', { title: 'Team', adminSection: 'team', items: catalog.team.listAll() }, 'admin');
  },
  newForm(req, res) {
    res.page('admin/team-form', { title: 'Add team member', adminSection: 'team', item: { status: 1, role: 'Staff', social_links: [] }, errors: [], isNew: true }, 'admin');
  },
  editForm(req, res, next) {
    const item = catalog.team.byId(int(req.params.id));
    if (!item) return next();
    return res.page('admin/team-form', { title: `Edit ${item.name}`, adminSection: 'team', item, errors: [], isNew: false }, 'admin');
  },
  parse(req) {
    const b = req.body;
    const data = {
      name: str(b.name, 80),
      username: str(b.username, 60),
      avatar: safeUrl(b.avatar),
      role: str(b.role, 60) || 'Staff',
      bio: str(b.bio, 500),
      social_links: JSON.stringify(parseSocialLines(b.social_links)),
      status: bool(b.status)
    };
    const errors = [];
    if (!data.name) errors.push('Name is required.');
    if (str(b.avatar) && !data.avatar) errors.push('Avatar must be an http(s) link or an uploaded file.');
    return { data, errors };
  },
  formItem(b, data) {
    return { ...b, ...data, social_links: parseSocialLines(b.social_links) };
  },
  create(req, res) {
    const { data, errors } = team.parse(req);
    if (errors.length) return res.status(400).page('admin/team-form', { title: 'Add team member', adminSection: 'team', item: team.formItem(req.body, data), errors, isNew: true }, 'admin');
    const id = catalog.team.insert({ ...data, user_id: null, application_id: null, display_order: catalog.nextOrder('team_members') });
    audit.log(req, 'Added team member', `team:${id}`, data.name);
    req.flash('success', 'Team member added.');
    return res.redirect('/admin/team');
  },
  update(req, res, next) {
    const id = int(req.params.id);
    const existing = catalog.team.byId(id);
    if (!existing) return next();
    const { data, errors } = team.parse(req);
    if (errors.length) return res.status(400).page('admin/team-form', { title: `Edit ${existing.name}`, adminSection: 'team', item: { ...team.formItem(req.body, data), id }, errors, isNew: false }, 'admin');
    catalog.team.update(id, data);
    audit.log(req, 'Updated team member', `team:${id}`, data.name);
    req.flash('success', 'Team member saved.');
    return res.redirect('/admin/team');
  },
  remove(req, res, next) {
    const id = int(req.params.id);
    const existing = catalog.team.byId(id);
    if (!existing) return next();
    catalog.team.remove(id);
    audit.log(req, 'Removed team member', `team:${id}`, existing.name);
    req.flash('success', 'Team member removed.');
    return res.redirect('/admin/team');
  },
  move: moveRoute('team_members', '/admin/team')
};

/* ---------------------------------- status ------------------------------- */
const status = {
  page(req, res) {
    res.page('admin/status', { title: 'Status & statistics', adminSection: 'status', services: statusService.listServices({ onlyVisible: false }), statuses: SERVICE_STATUSES, errors: [] }, 'admin');
  },
  updateServices(req, res) {
    const db = getDb();
    const services = statusService.listServices({ onlyVisible: false });
    const update = db.prepare("UPDATE status_services SET status = ?, description = ?, visible = ?, source = ?, api_url = ?, updated_at = datetime('now') WHERE id = ?");
    const tx = db.transaction(() => {
      for (const s of services) {
        const next = str(req.body[`status_${s.id}`], 30);
        const source = req.body[`source_${s.id}`] === 'api' ? 'api' : 'manual';
        const apiUrl = source === 'api' ? safeUrl(req.body[`api_url_${s.id}`], { allowRelative: false }) : '';
        update.run(SERVICE_STATUSES[next] ? next : s.status, str(req.body[`description_${s.id}`], 150), bool(req.body[`visible_${s.id}`]), source === 'api' && !apiUrl ? 'manual' : source, apiUrl, s.id);
      }
    });
    tx();
    audit.log(req, 'Updated service statuses', 'status');
    statusService.publishUpdate();
    req.flash('success', 'Statuses updated.');
    res.redirect('/admin/status');
  },
  addService(req, res) {
    const name = str(req.body.name, 60);
    if (!name) {
      req.flash('error', 'Service name is required.');
      return res.redirect('/admin/status');
    }
    const slug = uniqueSlug(getDb(), 'status_services', 'slug', name);
    const id = getDb()
      .prepare('INSERT INTO status_services (name, slug, description, display_order) VALUES (?, ?, ?, ?)')
      .run(name, slug, str(req.body.description, 150), catalog.nextOrder('status_services')).lastInsertRowid;
    audit.log(req, 'Added status service', `service:${id}`, name);
    statusService.publishUpdate();
    req.flash('success', 'Service added.');
    return res.redirect('/admin/status');
  },
  removeService(req, res) {
    const id = int(req.params.id);
    const row = getDb().prepare('SELECT * FROM status_services WHERE id = ?').get(id);
    if (row) {
      getDb().prepare('DELETE FROM status_services WHERE id = ?').run(id);
      audit.log(req, 'Deleted status service', `service:${id}`, row.name);
      statusService.publishUpdate();
    }
    req.flash('success', 'Service deleted.');
    res.redirect('/admin/status');
  },
  move: moveRoute('status_services', '/admin/status'),
  saveStats(req, res) {
    const b = req.body;
    const out = {};
    for (const key of ['stat_uptime', 'stat_locations', 'stat_servers', 'stat_customers', 'stat_network']) out[key] = str(b[key], 24);
    settings.setMany(out);
    audit.log(req, 'Updated site statistics', 'settings:stats');
    statusService.publishUpdate();
    req.flash('success', 'Statistics saved.');
    res.redirect('/admin/status');
  }
};

module.exports = { categories, plans, socials, team, status, slugify };
