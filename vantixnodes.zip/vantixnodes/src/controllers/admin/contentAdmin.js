'use strict';

const { getDb } = require('../../database/connection');
const content = require('../../models/content');
const catalog = require('../../models/catalog');
const audit = require('../../services/auditService');
const settings = require('../../services/settingsService');
const { str, int, bool, safeUrl, uniqueSlug, paginate, discordAvatarUrl, linesToArray } = require('../../utils/helpers');
const { POST_CATEGORIES, APPLICATION_STATUSES, TICKET_STATUSES, QUESTION_TYPES } = require('../../config/constants');

/* ---------------------------------- posts -------------------------------- */
const posts = {
  list(req, res) {
    const pg = paginate(content.posts.countAll(), int(req.query.page, 1, 1, 100000), 15);
    res.page('admin/posts', { title: 'Posts', adminSection: 'posts', items: content.posts.listAll({ limit: pg.perPage, offset: pg.offset }), pg }, 'admin');
  },
  newForm(req, res) {
    res.page('admin/post-form', { title: 'New post', adminSection: 'posts', item: { category: 'news', published: 0 }, errors: [], isNew: true }, 'admin');
  },
  editForm(req, res, next) {
    const item = content.posts.byId(int(req.params.id));
    if (!item) return next();
    return res.page('admin/post-form', { title: `Edit ${item.title}`, adminSection: 'posts', item, errors: [], isNew: false }, 'admin');
  },
  parse(req, id = 0) {
    const b = req.body;
    const data = {
      title: str(b.title, 160),
      description: str(b.description, 300),
      content: str(b.content, 50000),
      thumbnail: safeUrl(b.thumbnail),
      category: Object.prototype.hasOwnProperty.call(POST_CATEGORIES, b.category) ? b.category : 'news',
      published: bool(b.published)
    };
    const errors = [];
    if (!data.title) errors.push('Title is required.');
    if (!data.content) errors.push('Content is required.');
    if (str(b.thumbnail) && !data.thumbnail) errors.push('Thumbnail must be an http(s) link or an uploaded file.');
    data.slug = uniqueSlug(getDb(), 'posts', 'slug', str(b.slug, 80) || data.title, id);
    return { data, errors };
  },
  create(req, res) {
    const { data, errors } = posts.parse(req);
    if (errors.length) return res.status(400).page('admin/post-form', { title: 'New post', adminSection: 'posts', item: { ...req.body, ...data }, errors, isNew: true }, 'admin');
    const id = content.posts.insert({ ...data, author_id: req.user.id });
    audit.log(req, data.published ? 'Published post' : 'Created post (draft)', `post:${id}`, data.title);
    req.flash('success', data.published ? 'Post published.' : 'Draft saved.');
    return res.redirect('/admin/posts');
  },
  update(req, res, next) {
    const id = int(req.params.id);
    const existing = content.posts.byId(id);
    if (!existing) return next();
    const { data, errors } = posts.parse(req, id);
    if (errors.length) return res.status(400).page('admin/post-form', { title: `Edit ${existing.title}`, adminSection: 'posts', item: { ...existing, ...req.body, ...data, id }, errors, isNew: false }, 'admin');
    content.posts.update(id, data);
    audit.log(req, 'Updated post', `post:${id}`, data.title);
    req.flash('success', 'Post saved.');
    return res.redirect('/admin/posts');
  },
  publish(req, res, next) {
    const id = int(req.params.id);
    const existing = content.posts.byId(id);
    if (!existing) return next();
    const value = req.body.publish === '1';
    content.posts.setPublished(id, value);
    audit.log(req, value ? 'Published post' : 'Unpublished post', `post:${id}`, existing.title);
    req.flash('success', value ? 'Post published.' : 'Post unpublished.');
    return res.redirect('/admin/posts');
  },
  remove(req, res, next) {
    const id = int(req.params.id);
    const existing = content.posts.byId(id);
    if (!existing) return next();
    content.posts.remove(id);
    audit.log(req, 'Deleted post', `post:${id}`, existing.title);
    req.flash('success', 'Post deleted.');
    return res.redirect('/admin/posts');
  }
};

/* ------------------------------- applications ----------------------------- */
const applications = {
  list(req, res) {
    const status = Object.prototype.hasOwnProperty.call(APPLICATION_STATUSES, req.query.status) ? req.query.status : '';
    const pg = paginate(content.applications.countAdmin(status), int(req.query.page, 1, 1, 100000), 15);
    res.page(
      'admin/applications',
      { title: 'Staff applications', adminSection: 'applications', items: content.applications.listAdmin({ status, limit: pg.perPage, offset: pg.offset }), pg, statusFilter: status, statuses: APPLICATION_STATUSES },
      'admin'
    );
  },
  detail(req, res, next) {
    const app = content.applications.byId(int(req.params.id));
    if (!app) return next();
    const team = getDb().prepare('SELECT * FROM team_members WHERE application_id = ?').get(app.id);
    return res.page(
      'admin/application',
      { title: `Application #${app.id}`, adminSection: 'applications', application: app, answers: content.applications.answers(app.id), statuses: APPLICATION_STATUSES, teamMember: team, applicantAvatar: discordAvatarUrl({ avatar: app.avatar, discord_id: app.discord_id }) },
      'admin'
    );
  },
  review(req, res, next) {
    const id = int(req.params.id);
    const app = content.applications.byId(id);
    if (!app) return next();
    const status = Object.prototype.hasOwnProperty.call(APPLICATION_STATUSES, req.body.status) ? req.body.status : app.status;
    const note = str(req.body.internal_note, 3000);
    content.applications.review({ id, status, note, reviewerId: req.user.id });

    if (status !== app.status) {
      audit.log(req, `Changed application status to ${APPLICATION_STATUSES[status]}`, `application:${id}`, `${app.applicant_name} - ${app.position}`);
      audit.notify(app.applicant_id, `Application ${APPLICATION_STATUSES[status].toLowerCase()}`, `Your application for ${app.position} is now: ${APPLICATION_STATUSES[status]}.`, '/account/applications');
    } else if (note !== app.internal_note) {
      audit.log(req, 'Updated application note', `application:${id}`);
    }

    const db = getDb();
    const member = db.prepare('SELECT * FROM team_members WHERE application_id = ?').get(id);
    if (status === 'approved') {
      const atRaw = req.body.add_to_team;
      const wantsTeam = atRaw === undefined ? settings.get('auto_create_team') === '1' : [].concat(atRaw).includes('1');
      if (wantsTeam && !member) {
        const nameAnswer = db.prepare("SELECT answer FROM application_answers WHERE application_id = ? AND lower(question_label) IN ('full name','name') LIMIT 1").get(id);
        const teamId = catalog.team.insert({
          user_id: app.applicant_id,
          application_id: id,
          name: (nameAnswer && nameAnswer.answer) || app.applicant_name,
          username: app.applicant_username,
          avatar: discordAvatarUrl({ avatar: app.avatar, discord_id: app.discord_id }),
          role: app.position || 'Staff',
          bio: '',
          social_links: '[]',
          status: 1,
          display_order: catalog.nextOrder('team_members')
        });
        audit.log(req, 'Created team profile from application', `team:${teamId}`, app.applicant_name);
      } else if (member && !member.status) {
        db.prepare('UPDATE team_members SET status = 1 WHERE id = ?').run(member.id);
      }
    } else if (member && member.status) {
      db.prepare('UPDATE team_members SET status = 0 WHERE id = ?').run(member.id);
      audit.log(req, 'Hid team profile (application no longer approved)', `team:${member.id}`);
    }

    req.flash('success', 'Application updated.');
    return res.redirect(`/admin/applications/${id}`);
  },
  remove(req, res, next) {
    const id = int(req.params.id);
    const app = content.applications.byId(id);
    if (!app) return next();
    content.applications.remove(id);
    audit.log(req, 'Deleted application', `application:${id}`, app.applicant_name);
    req.flash('success', 'Application deleted.');
    return res.redirect('/admin/applications');
  },
  saveSettings(req, res) {
    settings.setMany({
      applications_open: bool(req.body.applications_open) ? '1' : '0',
      applications_intro: str(req.body.applications_intro, 600),
      applications_positions: linesToArray(req.body.applications_positions, 20, 80).join('\n'),
      auto_create_team: bool(req.body.auto_create_team) ? '1' : '0'
    });
    audit.log(req, bool(req.body.applications_open) ? 'Opened staff applications' : 'Closed staff applications', 'settings:applications');
    req.flash('success', 'Application settings saved.');
    res.redirect('/admin/applications');
  }
};

/* --------------------------- application questions ------------------------ */
const questions = {
  page(req, res, next) {
    let edit = null;
    if (req.params.id) {
      edit = content.applications.questionById(int(req.params.id));
      if (!edit) return next();
    }
    return res.page('admin/questions', { title: 'Application questions', adminSection: 'applications', items: content.applications.questions(false), types: QUESTION_TYPES, edit, errors: [] }, 'admin');
  },
  parse(req) {
    const b = req.body;
    const type = Object.prototype.hasOwnProperty.call(QUESTION_TYPES, b.type) ? b.type : 'text';
    const data = {
      label: str(b.label, 160),
      help_text: str(b.help_text, 250),
      type,
      options: type === 'select' ? linesToArray(b.options, 30, 100).join('\n') : '',
      required: bool(b.required),
      status: bool(b.status)
    };
    const errors = [];
    if (!data.label) errors.push('Question text is required.');
    if (type === 'select' && !data.options) errors.push('Dropdown questions need at least one option (one per line).');
    return { data, errors };
  },
  create(req, res) {
    const { data, errors } = questions.parse(req);
    if (errors.length) {
      return res.status(400).page('admin/questions', { title: 'Application questions', adminSection: 'applications', items: content.applications.questions(false), types: QUESTION_TYPES, edit: null, errors, draft: req.body }, 'admin');
    }
    const id = getDb()
      .prepare('INSERT INTO application_questions (label, help_text, type, options, required, status, display_order) VALUES (@label, @help_text, @type, @options, @required, @status, @display_order)')
      .run({ ...data, display_order: catalog.nextOrder('application_questions') }).lastInsertRowid;
    audit.log(req, 'Created application question', `question:${id}`, data.label);
    req.flash('success', 'Question added.');
    return res.redirect('/admin/applications/questions');
  },
  update(req, res, next) {
    const id = int(req.params.id);
    const existing = content.applications.questionById(id);
    if (!existing) return next();
    const { data, errors } = questions.parse(req);
    if (errors.length) {
      return res.status(400).page('admin/questions', { title: 'Application questions', adminSection: 'applications', items: content.applications.questions(false), types: QUESTION_TYPES, edit: { ...existing, ...data }, errors }, 'admin');
    }
    getDb()
      .prepare('UPDATE application_questions SET label=@label, help_text=@help_text, type=@type, options=@options, required=@required, status=@status WHERE id=@id')
      .run({ ...data, id });
    audit.log(req, 'Updated application question', `question:${id}`, data.label);
    req.flash('success', 'Question saved.');
    return res.redirect('/admin/applications/questions');
  },
  remove(req, res, next) {
    const id = int(req.params.id);
    const existing = content.applications.questionById(id);
    if (!existing) return next();
    getDb().prepare('DELETE FROM application_questions WHERE id = ?').run(id);
    audit.log(req, 'Deleted application question', `question:${id}`, existing.label);
    req.flash('success', 'Question deleted. Past answers are preserved on submitted applications.');
    return res.redirect('/admin/applications/questions');
  },
  move(req, res) {
    catalog.move('application_questions', int(req.params.id), req.body.dir === 'up' ? 'up' : 'down');
    res.redirect('/admin/applications/questions');
  }
};

/* ---------------------------------- tickets ------------------------------ */
const tickets = {
  list(req, res) {
    const status = Object.prototype.hasOwnProperty.call(TICKET_STATUSES, req.query.status) ? req.query.status : '';
    const pg = paginate(content.tickets.countAdmin(status), int(req.query.page, 1, 1, 100000), 20);
    res.page('admin/tickets', { title: 'Support tickets', adminSection: 'tickets', items: content.tickets.listAdmin({ status, limit: pg.perPage, offset: pg.offset }), pg, statusFilter: status, statuses: TICKET_STATUSES }, 'admin');
  },
  detail(req, res, next) {
    const ticket = content.tickets.byId(int(req.params.id));
    if (!ticket) return next();
    return res.page('admin/ticket', { title: `Ticket #${ticket.id}`, adminSection: 'tickets', ticket, messages: content.tickets.messages(ticket.id), statuses: TICKET_STATUSES }, 'admin');
  },
  reply(req, res, next) {
    const id = int(req.params.id);
    const ticket = content.tickets.byId(id);
    if (!ticket) return next();
    const message = str(req.body.message, 8000);
    const status = Object.prototype.hasOwnProperty.call(TICKET_STATUSES, req.body.status) ? req.body.status : 'pending';
    if (message.length < 2) {
      req.flash('error', 'Please write a reply.');
      return res.redirect(`/admin/tickets/${id}`);
    }
    content.tickets.addMessage({ ticketId: id, userId: req.user.id, isStaff: true, message, status });
    audit.log(req, 'Replied to ticket', `ticket:${id}`, `status -> ${status}`);
    audit.notify(ticket.user_id, `New reply on ticket #${id}`, ticket.subject, `/account/tickets/${id}`);
    req.flash('success', 'Reply sent.');
    return res.redirect(`/admin/tickets/${id}`);
  },
  setStatus(req, res, next) {
    const id = int(req.params.id);
    const ticket = content.tickets.byId(id);
    if (!ticket) return next();
    const status = Object.prototype.hasOwnProperty.call(TICKET_STATUSES, req.body.status) ? req.body.status : ticket.status;
    content.tickets.setStatus(id, status);
    audit.log(req, 'Changed ticket status', `ticket:${id}`, `${ticket.status} -> ${status}`);
    req.flash('success', 'Ticket status updated.');
    return res.redirect(`/admin/tickets/${id}`);
  },
  categories(req, res) {
    res.page('admin/ticket-categories', { title: 'Ticket categories', adminSection: 'tickets', items: content.tickets.categories(false) }, 'admin');
  },
  addCategory(req, res) {
    const name = str(req.body.name, 60);
    if (!name) {
      req.flash('error', 'Name is required.');
      return res.redirect('/admin/tickets/categories');
    }
    try {
      getDb().prepare('INSERT INTO ticket_categories (name, display_order) VALUES (?, ?)').run(name, catalog.nextOrder('ticket_categories'));
      audit.log(req, 'Created ticket category', name);
      req.flash('success', 'Category added.');
    } catch (e) {
      req.flash('error', 'A category with that name already exists.');
    }
    return res.redirect('/admin/tickets/categories');
  },
  toggleCategory(req, res) {
    getDb().prepare('UPDATE ticket_categories SET status = 1 - status WHERE id = ?').run(int(req.params.id));
    audit.log(req, 'Toggled ticket category', `ticket_category:${req.params.id}`);
    res.redirect('/admin/tickets/categories');
  },
  removeCategory(req, res) {
    getDb().prepare('DELETE FROM ticket_categories WHERE id = ?').run(int(req.params.id));
    audit.log(req, 'Deleted ticket category', `ticket_category:${req.params.id}`);
    req.flash('success', 'Category deleted.');
    res.redirect('/admin/tickets/categories');
  },
  moveCategory(req, res) {
    catalog.move('ticket_categories', int(req.params.id), req.body.dir === 'up' ? 'up' : 'down');
    res.redirect('/admin/tickets/categories');
  }
};

/* --------------------------------- contact ------------------------------- */
const contact = {
  list(req, res) {
    const db = getDb();
    const total = db.prepare('SELECT COUNT(*) AS n FROM contact_messages').get().n;
    const pg = paginate(total, int(req.query.page, 1, 1, 100000), 15);
    const items = db.prepare('SELECT * FROM contact_messages ORDER BY is_read, created_at DESC, id DESC LIMIT ? OFFSET ?').all(pg.perPage, pg.offset);
    res.page('admin/contact', { title: 'Contact messages', adminSection: 'contact', items, pg }, 'admin');
  },
  toggleRead(req, res) {
    getDb().prepare('UPDATE contact_messages SET is_read = 1 - is_read WHERE id = ?').run(int(req.params.id));
    res.redirect('/admin/contact');
  },
  remove(req, res) {
    getDb().prepare('DELETE FROM contact_messages WHERE id = ?').run(int(req.params.id));
    audit.log(req, 'Deleted contact message', `contact:${req.params.id}`);
    req.flash('success', 'Message deleted.');
    res.redirect('/admin/contact');
  }
};

module.exports = { posts, applications, questions, tickets, contact };
