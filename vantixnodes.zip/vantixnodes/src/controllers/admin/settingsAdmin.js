'use strict';

const settings = require('../../services/settingsService');
const audit = require('../../services/auditService');
const { str, int, bool, isHexColor, safeUrl, isEmail } = require('../../utils/helpers');
const { FONTS, BUTTON_STYLES, BG_TYPES } = require('../../config/constants');

const TABS = ['general', 'hero', 'seo'];

function settingsPage(req, res) {
  const tab = TABS.includes(req.query.tab) ? req.query.tab : 'general';
  res.page('admin/settings', { title: 'Website settings', adminSection: 'settings', tab, tabs: TABS, errors: [] }, 'admin');
}

function saveSettings(req, res) {
  const section = req.params.section;
  if (!TABS.includes(section)) return res.redirect('/admin/settings');
  const b = req.body;
  const errors = [];
  const out = {};

  if (section === 'general') {
    out.site_name = str(b.site_name, 60);
    if (!out.site_name) errors.push('Website name is required.');
    out.site_tagline = str(b.site_tagline, 200);
    out.site_description = str(b.site_description, 500);
    out.logo_url = safeUrl(b.logo_url);
    out.favicon_url = safeUrl(b.favicon_url);
    if (str(b.logo_url) && !out.logo_url) errors.push('Logo URL must be an http(s) link or an uploaded file.');
    if (str(b.favicon_url) && !out.favicon_url) errors.push('Favicon URL must be an http(s) link or an uploaded file.');
    out.footer_text = str(b.footer_text, 300);
    out.contact_email = str(b.contact_email, 254);
    if (out.contact_email && !isEmail(out.contact_email)) errors.push('Contact email is not valid.');
    out.maintenance_mode = bool(b.maintenance_mode) ? '1' : '0';
  }

  if (section === 'hero') {
    out.hero_badge = str(b.hero_badge, 60);
    out.hero_title = str(b.hero_title, 120);
    out.hero_subtitle = str(b.hero_subtitle, 300);
    if (!out.hero_title) errors.push('Hero title is required.');
    for (const n of [1, 2, 3]) {
      out[`hero_btn${n}_text`] = str(b[`hero_btn${n}_text`], 40);
      out[`hero_btn${n}_url`] = safeUrl(b[`hero_btn${n}_url`]);
      if (out[`hero_btn${n}_text`] && !out[`hero_btn${n}_url`]) errors.push(`Button ${n} needs a valid link (http(s) URL or a path like /plans).`);
    }
  }

  if (section === 'seo') {
    out.seo_title = str(b.seo_title, 70);
    out.seo_description = str(b.seo_description, 300);
    out.seo_keywords = str(b.seo_keywords, 300);
    out.seo_og_image = safeUrl(b.seo_og_image);
    if (str(b.seo_og_image) && !out.seo_og_image) errors.push('OG image must be an http(s) link or an uploaded file.');
  }

  if (errors.length) {
    // Re-render with the submitted values so nothing is lost.
    const merged = { ...settings.all(), ...out };
    return res.status(400).page('admin/settings', { title: 'Website settings', adminSection: 'settings', tab: section, tabs: TABS, errors, settings: merged }, 'admin');
  }
  settings.setMany(out);
  audit.log(req, 'Changed website settings', `settings:${section}`);
  req.flash('success', 'Settings saved.');
  return res.redirect(`/admin/settings?tab=${section}`);
}

/* --------------------------------- theme --------------------------------- */
const COLOR_FIELDS = {
  color_primary: 'Primary color',
  color_secondary: 'Secondary color',
  color_accent: 'Accent color',
  color_background: 'Background color',
  color_surface: 'Card background',
  color_text: 'Text color',
  color_muted: 'Muted text',
  color_border: 'Border color'
};

const DEFAULT_THEME = {
  color_primary: '#6366f1',
  color_secondary: '#22d3ee',
  color_accent: '#a855f7',
  color_background: '#07090f',
  color_surface: '#0e1220',
  color_text: '#e8ecf6',
  color_muted: '#8b94ad',
  color_border: '#1f2740',
  button_style: 'gradient',
  border_radius: '16',
  font: 'Inter',
  animations_enabled: '1'
};

function themePage(req, res) {
  res.page('admin/theme', { title: 'Theme editor', adminSection: 'theme', colorFields: COLOR_FIELDS, fonts: Object.keys(FONTS), errors: [] }, 'admin');
}

function saveTheme(req, res) {
  if (req.body.reset === '1') {
    settings.setMany(DEFAULT_THEME);
    audit.log(req, 'Reset theme to defaults', 'settings:theme');
    req.flash('success', 'Theme reset to defaults.');
    return res.redirect('/admin/theme');
  }
  const b = req.body;
  const errors = [];
  const out = {};
  for (const [key, label] of Object.entries(COLOR_FIELDS)) {
    if (!isHexColor(b[key])) errors.push(`${label} must be a hex color like #6366f1.`);
    else out[key] = b[key].toLowerCase();
  }
  out.button_style = BUTTON_STYLES.includes(b.button_style) ? b.button_style : 'gradient';
  out.border_radius = String(int(b.border_radius, 16, 0, 32));
  out.font = Object.prototype.hasOwnProperty.call(FONTS, b.font) ? b.font : 'Inter';
  out.animations_enabled = bool(b.animations_enabled) ? '1' : '0';
  if (errors.length) {
    return res.status(400).page('admin/theme', { title: 'Theme editor', adminSection: 'theme', colorFields: COLOR_FIELDS, fonts: Object.keys(FONTS), errors, settings: { ...settings.all(), ...b } }, 'admin');
  }
  settings.setMany(out);
  audit.log(req, 'Changed theme', 'settings:theme');
  req.flash('success', 'Theme updated.');
  return res.redirect('/admin/theme');
}

/* ------------------------------- background ------------------------------ */
function backgroundPage(req, res) {
  res.page('admin/background', { title: 'Background', adminSection: 'background', bgTypes: BG_TYPES, errors: [] }, 'admin');
}

function saveBackground(req, res) {
  const b = req.body;
  const errors = [];
  const out = {};
  out.bg_type = BG_TYPES.includes(b.bg_type) ? b.bg_type : 'none';
  out.bg_color = isHexColor(b.bg_color) ? b.bg_color.toLowerCase() : '#07090f';
  out.bg_gradient_from = isHexColor(b.bg_gradient_from) ? b.bg_gradient_from.toLowerCase() : '#07090f';
  out.bg_gradient_to = isHexColor(b.bg_gradient_to) ? b.bg_gradient_to.toLowerCase() : '#141a33';
  out.bg_gradient_angle = String(int(b.bg_gradient_angle, 160, 0, 360));
  out.bg_overlay = String(int(b.bg_overlay, 60, 0, 100));
  out.bg_video_opacity = String(int(b.bg_video_opacity, 60, 0, 100));
  out.bg_image_url = safeUrl(b.bg_image_url);
  out.bg_video_url = safeUrl(b.bg_video_url);
  if (str(b.bg_image_url) && !out.bg_image_url) errors.push('Image URL must be an http(s) link or an uploaded file.');
  if (str(b.bg_video_url) && !out.bg_video_url) errors.push('Video URL must be an http(s) link or an uploaded file.');
  if (out.bg_type === 'image' && !out.bg_image_url) errors.push('Provide an image URL or upload an image for the image background.');
  if (out.bg_type === 'video' && !out.bg_video_url) errors.push('Provide a video URL or upload a video for the video background.');
  if (errors.length) {
    return res.status(400).page('admin/background', { title: 'Background', adminSection: 'background', bgTypes: BG_TYPES, errors, settings: { ...settings.all(), ...out } }, 'admin');
  }
  settings.setMany(out);
  audit.log(req, 'Changed website background', `type:${out.bg_type}`);
  req.flash('success', 'Background updated.');
  return res.redirect('/admin/background');
}

module.exports = { settingsPage, saveSettings, themePage, saveTheme, backgroundPage, saveBackground };
