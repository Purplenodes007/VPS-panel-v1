'use strict';

const bcrypt = require('bcryptjs');
const { getDb } = require('../../database/connection');
const content = require('../../models/content');
const audit = require('../../services/auditService');
const roleService = require('../../services/roleService');
const backups = require('../../services/backupService');
const { str, int, paginate, bool } = require('../../utils/helpers');
const { PERMISSIONS, ROLES_ORDER, APPLICATION_STATUSES } = require('../../config/constants');

const rank = (role) => Math.max(0, ROLES_ORDER.indexOf(role));

/* -------------------------------- dashboard ------------------------------- */
function dashboard(req, res) {
  const db = getDb();
  const one = (sql, ...p) => db.prepare(sql).get(...p).n;

  const stats = [
    { label: 'Total users', value: one('SELECT COUNT(*) AS n FROM users'), icon: 'users', href: '/admin/users', perm: 'users' },
    { label: 'Pending applications', value: one("SELECT COUNT(*) AS n FROM applications WHERE status IN ('pending','under_review')"), icon: 'clipboard', href: '/admin/applications', perm: 'applications' },
    { label: 'Published posts', value: one('SELECT COUNT(*) AS n FROM posts WHERE published = 1'), icon: 'news', href: '/admin/posts', perm: 'posts' },
    { label: 'Active plans', value: one('SELECT COUNT(*) AS n FROM plans WHERE status = 1'), icon: 'tag', href: '/admin/plans', perm: 'plans' },
    { label: 'Open tickets', value: one("SELECT COUNT(*) AS n FROM tickets WHERE status = 'open'"), icon: 'ticket', href: '/admin/tickets', perm: 'tickets' },
    { label: 'Unread messages', value: one('SELECT COUNT(*) AS n FROM contact_messages WHERE is_read = 0'), icon: 'mail', href: '/admin/contact', perm: 'contact' }
  ].filter((s) => roleService.can(req.user.role, s.perm));

  // Sign-ups per day for the last 14 days
  const rows = db
    .prepare("SELECT date(created_at) AS d, COUNT(*) AS n FROM users WHERE created_at >= date('now', '-13 days') GROUP BY date(created_at)")
    .all();
  const byDay = Object.fromEntries(rows.map((r) => [r.d, r.n]));
  const signups = [];
  for (let i = 13; i >= 0; i -= 1) {
    const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
    signups.push({ day: d, label: d.slice(5), count: byDay[d] || 0 });
  }

  const appCounts = Object.keys(APPLICATION_STATUSES).map((k) => ({ key: k, label: APPLICATION_STATUSES[k], count: one('SELECT COUNT(*) AS n FROM applications WHERE status = ?', k) }));
  const ticketCounts = ['open', 'pending', 'closed'].map((k) => ({ key: k, label: k[0].toUpperCase() + k.slice(1), count: one('SELECT COUNT(*) AS n FROM tickets WHERE status = ?', k) }));

  const can = (p) => roleService.can(req.user.role, p);
  res.page(
    'admin/dashboard',
    {
      title: 'Overview',
      adminSection: 'overview',
      stats,
      signups,
      maxSignups: Math.max(1, ...signups.map((s) => s.count)),
      appCounts,
      ticketCounts,
      recentActivity: can('audit') ? db.prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 8').all() : [],
      recentApplications: can('applications') ? content.applications.listAdmin({ limit: 5, offset: 0 }) : [],
      recentTickets: can('tickets') ? content.tickets.listAdmin({ limit: 5, offset: 0 }) : []
    },
    'admin'
  );
}

/* ----------------------------------- users -------------------------------- */
function usersList(req, res) {
  const q = str(req.query.q, 60);
  const role = ROLES_ORDER.includes(req.query.role) ? req.query.role : '';
  const pg = paginate(content.users.count({ q, role }), int(req.query.page, 1, 1, 100000), 20);
  res.page('admin/users', { title: 'Users', adminSection: 'users', items: content.users.list({ q, role, limit: pg.perPage, offset: pg.offset }), pg, q, roleFilter: role, roles: roleService.roles() }, 'admin');
}

function userDetail(req, res, next) {
  const target = content.users.byId(int(req.params.id));
  if (!target) return next();
  const db = getDb();
  return res.page(
    'admin/user',
    {
      title: target.global_name || target.username,
      adminSection: 'users',
      target,
      roles: roleService.roles(),
      assignable: assignableRoles(req.user, target),
      manageable: canManage(req.user, target),
      applications: content.applications.listForUser(target.id),
      tickets: content.tickets.listForUser(target.id),
      activity: db.prepare('SELECT * FROM user_activity WHERE user_id = ? ORDER BY id DESC LIMIT 10').all(target.id)
    },
    'admin'
  );
}

function canManage(actor, target) {
  if (actor.id === target.id) return false;
  if (actor.role === 'superadmin') return true;
  return rank(actor.role) > rank(target.role);
}

function assignableRoles(actor, target) {
  if (!canManage(actor, target)) return [];
  return ROLES_ORDER.filter((r) => (actor.role === 'superadmin' ? true : rank(r) < rank(actor.role)));
}

function setUserRole(req, res, next) {
  const target = content.users.byId(int(req.params.id));
  if (!target) return next();
  const role = str(req.body.role, 30);
  if (!assignableRoles(req.user, target).includes(role)) {
    req.flash('error', 'You are not allowed to assign that role to this user.');
    return res.redirect(`/admin/users/${target.id}`);
  }
  content.users.setRole(target.id, role);
  audit.log(req, 'Changed user role', `user:${target.id}`, `${target.role} -> ${role}`);
  req.flash('success', 'Role updated.');
  return res.redirect(`/admin/users/${target.id}`);
}

function setUserBan(req, res, next) {
  const target = content.users.byId(int(req.params.id));
  if (!target) return next();
  if (!canManage(req.user, target)) {
    req.flash('error', 'You are not allowed to change this account.');
    return res.redirect(`/admin/users/${target.id}`);
  }
  const ban = req.body.ban === '1';
  content.users.setBanned(target.id, ban);
  audit.log(req, ban ? 'Suspended user' : 'Unsuspended user', `user:${target.id}`, target.username);
  req.flash('success', ban ? 'User suspended and signed out.' : 'User restored.');
  return res.redirect(`/admin/users/${target.id}`);
}

/* ----------------------------------- audit -------------------------------- */
function auditPage(req, res) {
  const db = getDb();
  const q = str(req.query.q, 60);
  const where = q ? 'WHERE action LIKE @q OR admin_name LIKE @q OR target LIKE @q OR details LIKE @q' : '';
  const params = q ? { q: `%${q.replace(/[%_]/g, '')}%` } : {};
  const total = db.prepare(`SELECT COUNT(*) AS n FROM audit_logs ${where}`).get(params).n;
  const pg = paginate(total, int(req.query.page, 1, 1, 100000), 30);
  const items = db.prepare(`SELECT * FROM audit_logs ${where} ORDER BY id DESC LIMIT @limit OFFSET @offset`).all({ ...params, limit: pg.perPage, offset: pg.offset });
  res.page('admin/audit', { title: 'Audit logs', adminSection: 'audit', items, pg, q }, 'admin');
}

/* --------------------------------- security -------------------------------- */
function securityPage(req, res) {
  res.page(
    'admin/security',
    {
      title: 'Security',
      adminSection: 'security',
      permissions: PERMISSIONS,
      roles: roleService.roles(),
      backups: backups.listBackups(),
      errors: [],
      sessionCount: getDb().prepare('SELECT COUNT(*) AS n FROM sessions WHERE expires_at > ?').get(Date.now()).n
    },
    'admin'
  );
}

function saveRolePermissions(req, res) {
  const roleName = str(req.params.role, 30);
  const selected = [].concat(req.body.permissions || []).map((p) => str(p, 30));
  if (!roleService.setPermissions(roleName, selected)) {
    req.flash('error', 'That role cannot be edited.');
    return res.redirect('/admin/security');
  }
  audit.log(req, 'Changed role permissions', `role:${roleName}`, selected.join(', ') || '(none)');
  req.flash('success', `Permissions for ${roleName} updated.`);
  return res.redirect('/admin/security');
}

function changePassword(req, res) {
  const current = typeof req.body.current_password === 'string' ? req.body.current_password : '';
  const next = typeof req.body.new_password === 'string' ? req.body.new_password : '';
  const confirm = typeof req.body.confirm_password === 'string' ? req.body.confirm_password : '';
  const username = str(req.body.local_username, 32);
  const user = req.user;
  const errors = [];

  if (user.password_hash && !bcrypt.compareSync(current, user.password_hash)) errors.push('Current password is incorrect.');
  if (!user.local_username && !/^[A-Za-z0-9_.-]{3,32}$/.test(username)) errors.push('Choose a username (3-32 characters: letters, numbers, dot, dash, underscore).');
  if (next.length < 12 || next.length > 200) errors.push('New password must be 12-200 characters.');
  if (!/[a-z]/.test(next) || !/[A-Z]/.test(next) || !/[0-9]/.test(next)) errors.push('New password must include upper-case, lower-case letters and a number.');
  if (next !== confirm) errors.push('Passwords do not match.');

  const db = getDb();
  if (!user.local_username && username && db.prepare('SELECT 1 FROM users WHERE local_username = ?').get(username.toLowerCase())) errors.push('That username is already taken.');

  if (errors.length) {
    return res.status(400).page(
      'admin/security',
      { title: 'Security', adminSection: 'security', permissions: PERMISSIONS, roles: roleService.roles(), backups: backups.listBackups(), errors, sessionCount: db.prepare('SELECT COUNT(*) AS n FROM sessions WHERE expires_at > ?').get(Date.now()).n },
      'admin'
    );
  }
  const hash = bcrypt.hashSync(next, 12);
  if (!user.local_username) db.prepare('UPDATE users SET password_hash = ?, local_username = ? WHERE id = ?').run(hash, username.toLowerCase(), user.id);
  else db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, user.id);
  // Sign out every other session of this account.
  db.prepare("DELETE FROM sessions WHERE json_extract(data, '$.userId') = ? AND sid != ?").run(user.id, req.sessionID);
  audit.log(req, 'Changed own password', `user:${user.id}`);
  req.flash('success', 'Password updated. Other sessions were signed out.');
  return res.redirect('/admin/security');
}

function purgeSessions(req, res) {
  const info = getDb().prepare('DELETE FROM sessions WHERE sid != ?').run(req.sessionID);
  audit.log(req, 'Signed out all other sessions', 'sessions', `${info.changes} sessions`);
  req.flash('success', `Signed out ${info.changes} other session(s).`);
  res.redirect('/admin/security');
}

/* ---------------------------------- backups -------------------------------- */
async function createBackup(req, res, next) {
  try {
    const b = await backups.createBackup();
    audit.log(req, 'Created database backup', b.name);
    req.flash('success', `Backup created: ${b.name}`);
    res.redirect('/admin/security#backups');
  } catch (e) {
    next(e);
  }
}

function downloadBackup(req, res, next) {
  const file = backups.backupPath(req.params.name);
  if (!file) return next();
  audit.log(req, 'Downloaded database backup', req.params.name);
  res.set('Cache-Control', 'no-store');
  return res.download(file, req.params.name);
}

function deleteBackup(req, res, next) {
  if (!backups.deleteBackup(req.params.name)) return next();
  audit.log(req, 'Deleted database backup', req.params.name);
  req.flash('success', 'Backup deleted.');
  return res.redirect('/admin/security#backups');
}

module.exports = { dashboard, usersList, userDetail, setUserRole, setUserBan, auditPage, securityPage, saveRolePermissions, changePassword, purgeSessions, createBackup, downloadBackup, deleteBackup, bool };
