'use strict';

const catalog = require('../models/catalog');
const content = require('../models/content');
const status = require('../services/statusService');
const settings = require('../services/settingsService');
const { getDb } = require('../database/connection');
const { int, paginate, str } = require('../utils/helpers');
const { POST_CATEGORIES } = require('../config/constants');

const cache = (res, seconds = 30) => res.set('Cache-Control', `public, max-age=${seconds}`);

const pubCategory = (c) => ({
  id: c.id,
  name: c.name,
  slug: c.slug,
  description: c.description,
  icon: c.icon,
  image: c.image,
  starting_price: c.starting_price === undefined ? undefined : c.starting_price,
  currency: c.currency,
  plan_count: c.plan_count
});

const pubPlan = (p) => ({
  id: p.id,
  name: p.name,
  category: p.category_slug,
  category_name: p.category_name,
  description: p.description,
  price: p.price,
  currency: p.currency,
  billing_period: p.billing_period,
  cpu: p.cpu,
  ram: p.ram,
  storage: p.storage,
  bandwidth: p.bandwidth,
  network_speed: p.network_speed,
  locations: p.locations,
  features: p.features,
  badge: p.badge,
  color: p.color,
  order_url: p.order_url
});

function categories(req, res) {
  cache(res);
  res.json({ data: catalog.categories.listActive().map(pubCategory) });
}

function categoryBySlug(req, res) {
  const c = catalog.categories.bySlug(req.params.slug);
  if (!c) return res.status(404).json({ error: 'Category not found.' });
  cache(res);
  return res.json({ data: { ...pubCategory(c), plans: catalog.plans.listActive({ categorySlug: c.slug }).map(pubPlan) } });
}

function plans(req, res) {
  cache(res);
  const slug = str(req.query.category, 80);
  res.json({ data: catalog.plans.listActive({ categorySlug: slug || undefined }).map(pubPlan) });
}

function planById(req, res) {
  const p = catalog.plans.byId(int(req.params.id), true);
  if (!p) return res.status(404).json({ error: 'Plan not found.' });
  cache(res);
  return res.json({ data: pubPlan(p) });
}

function posts(req, res) {
  const category = Object.keys(POST_CATEGORIES).includes(req.query.category) ? req.query.category : '';
  const perPage = Math.min(50, int(req.query.limit, 10, 1, 50));
  const pg = paginate(content.posts.countPublished(category), int(req.query.page, 1, 1, 100000), perPage);
  cache(res);
  res.json({ data: content.posts.listPublished({ category, limit: perPage, offset: pg.offset }), meta: { page: pg.page, pages: pg.pages, total: pg.total, per_page: perPage } });
}

function postBySlug(req, res) {
  const p = content.posts.bySlug(req.params.slug);
  if (!p) return res.status(404).json({ error: 'Post not found.' });
  cache(res);
  return res.json({
    data: {
      id: p.id,
      title: p.title,
      slug: p.slug,
      description: p.description,
      content: p.content,
      thumbnail: p.thumbnail,
      category: p.category,
      author: p.author_name,
      created_at: p.created_at,
      updated_at: p.updated_at
    }
  });
}

function team(req, res) {
  cache(res);
  res.json({
    data: catalog.team.listActive().map((m) => ({
      id: m.id,
      name: m.name,
      username: m.username,
      avatar: m.avatar,
      role: m.role,
      bio: m.bio,
      social_links: m.social_links
    }))
  });
}

function statusApi(req, res) {
  res.set('Cache-Control', 'public, max-age=10');
  res.json({ data: status.snapshot() });
}

function socials(req, res) {
  cache(res);
  res.json({ data: catalog.socials.listActive().map((s) => ({ id: s.id, platform: s.platform, display_name: s.display_name, url: s.url, icon: s.icon })) });
}

/* ------------------------------ admin API ------------------------------ */
function adminStats(req, res) {
  const db = getDb();
  const one = (sql) => db.prepare(sql).get().n;
  res.json({
    data: {
      total_users: one('SELECT COUNT(*) AS n FROM users'),
      pending_applications: one("SELECT COUNT(*) AS n FROM applications WHERE status IN ('pending','under_review')"),
      published_posts: one('SELECT COUNT(*) AS n FROM posts WHERE published = 1'),
      active_plans: one('SELECT COUNT(*) AS n FROM plans WHERE status = 1'),
      open_tickets: one("SELECT COUNT(*) AS n FROM tickets WHERE status = 'open'"),
      unread_messages: one('SELECT COUNT(*) AS n FROM contact_messages WHERE is_read = 0')
    }
  });
}

function adminAudit(req, res) {
  const limit = int(req.query.limit, 50, 1, 200);
  const rows = getDb().prepare('SELECT id, admin_id, admin_name, action, target, ip, created_at FROM audit_logs ORDER BY id DESC LIMIT ?').all(limit);
  res.json({ data: rows });
}

function adminSetStatus(req, res) {
  const { SERVICE_STATUSES } = require('../config/constants');
  const next = str(req.body && req.body.status, 30);
  if (!SERVICE_STATUSES[next]) return res.status(400).json({ error: 'Invalid status.' });
  const svc = getDb().prepare('SELECT * FROM status_services WHERE slug = ?').get(str(req.params.slug, 60));
  if (!svc) return res.status(404).json({ error: 'Service not found.' });
  getDb().prepare("UPDATE status_services SET status = ?, source = 'manual', updated_at = datetime('now') WHERE id = ?").run(next, svc.id);
  require('../services/auditService').log(req, 'Changed service status via API', `service:${svc.slug}`, `${svc.status} -> ${next}`);
  status.publishUpdate();
  return res.json({ data: { slug: svc.slug, status: next } });
}

module.exports = { categories, categoryBySlug, plans, planById, posts, postBySlug, team, statusApi, socials, adminStats, adminAudit, adminSetStatus, settingsPublic: () => settings.publicSettings() };
