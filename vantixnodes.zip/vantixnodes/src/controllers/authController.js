'use strict';

const bcrypt = require('bcryptjs');
const config = require('../config');
const { getDb } = require('../database/connection');
const discord = require('../services/discordService');
const setup = require('../services/setupService');
const audit = require('../services/auditService');
const roleService = require('../services/roleService');
const { randomToken, getIp, str } = require('../utils/helpers');

const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 12);
const MAX_FAILED = 5;
const LOCK_MINUTES = 15;

function safeReturn(value, fallback) {
  if (typeof value === 'string' && value.startsWith('/') && !value.startsWith('//') && !value.startsWith('/auth')) return value;
  return fallback;
}

function startSession(req, res, user, next) {
  const returnTo = req.session.returnTo;
  req.session.regenerate((err) => {
    if (err) return next(err);
    req.session.userId = user.id;
    req.session.adminLast = Date.now();
    getDb().prepare("UPDATE users SET last_login = datetime('now'), failed_logins = 0, locked_until = NULL WHERE id = ?").run(user.id);
    audit.userActivity(user.id, 'Signed in', getIp(req));
    const target = safeReturn(returnTo, roleService.isStaff(user.role) && req.__adminLogin ? '/admin' : '/account');
    return req.session.save((saveErr) => (saveErr ? next(saveErr) : res.redirect(target)));
  });
}

/* ------------------------------- Discord ------------------------------- */
function loginPage(req, res) {
  if (req.user) return res.redirect('/account');
  return res.page('auth/login', { title: 'Sign in', discordReady: discord.isConfigured(), noindex: true });
}

function discordStart(req, res, next) {
  if (!discord.isConfigured()) {
    req.flash('error', 'Discord login is not configured yet. The administrator needs to set the Discord OAuth credentials.');
    return res.redirect('/auth/login');
  }
  const state = randomToken(24);
  req.session.oauthState = state;
  return req.session.save((err) => (err ? next(err) : res.redirect(discord.buildAuthorizeUrl(state))));
}

async function discordCallback(req, res, next) {
  try {
    const { code, state, error } = req.query;
    const expected = req.session.oauthState;
    delete req.session.oauthState;

    if (error) {
      req.flash('error', 'Discord sign-in was cancelled.');
      return res.redirect('/auth/login');
    }
    if (!discord.isConfigured() || typeof code !== 'string' || typeof state !== 'string' || !expected || state !== expected) {
      req.flash('error', 'Sign-in session expired or was invalid. Please try again.');
      return res.redirect('/auth/login');
    }

    let profile;
    try {
      profile = await discord.fetchProfile(code);
    } catch (e) {
      console.error('Discord OAuth error:', e.message);
      req.flash('error', 'Could not complete Discord sign-in. Please try again.');
      return res.redirect('/auth/login');
    }

    let user = discord.upsertUser(profile);

    // Optional bootstrap: promote a configured Discord ID while no admin exists.
    if (config.discord.initialAdminId && profile.id === config.discord.initialAdminId && !setup.adminExists()) {
      getDb().prepare("UPDATE users SET role = 'superadmin' WHERE id = ?").run(user.id);
      user = getDb().prepare('SELECT * FROM users WHERE id = ?').get(user.id);
      audit.log({ user, ip: getIp(req) }, 'Initial superadmin promoted via INITIAL_ADMIN_DISCORD_ID', `user:${user.id}`);
    }

    if (user.is_banned) {
      req.flash('error', 'This account has been suspended.');
      return res.redirect('/auth/login');
    }
    return startSession(req, res, user, next);
  } catch (err) {
    return next(err);
  }
}

function logout(req, res) {
  const userId = req.user && req.user.id;
  if (userId) audit.userActivity(userId, 'Signed out', getIp(req));
  req.session.destroy(() => {
    res.clearCookie(config.session.cookieName);
    res.redirect('/');
  });
}

/* ----------------------------- Local admin ----------------------------- */
function adminLoginPage(req, res) {
  if (req.user && roleService.isStaff(req.user.role)) return res.redirect('/admin');
  return res.page('auth/admin-login', { title: 'Staff sign in', noindex: true, form: {} });
}

function adminLogin(req, res, next) {
  const username = str(req.body.username, 64).toLowerCase();
  const password = typeof req.body.password === 'string' ? req.body.password.slice(0, 200) : '';
  const fail = (message) => res.status(401).page('auth/admin-login', { title: 'Staff sign in', noindex: true, error: message, form: { username } });

  const user = username ? getDb().prepare('SELECT * FROM users WHERE local_username = ?').get(username) : null;

  if (user && user.locked_until && new Date(user.locked_until.replace(' ', 'T') + 'Z') > new Date()) {
    bcrypt.compareSync(password, DUMMY_HASH);
    return fail('This account is temporarily locked after too many failed attempts. Try again later.');
  }

  const hash = user && user.password_hash ? user.password_hash : DUMMY_HASH;
  const ok = bcrypt.compareSync(password, hash) && !!user && !!user.password_hash;

  if (!ok) {
    if (user) {
      const failed = user.failed_logins + 1;
      if (failed >= MAX_FAILED) {
        getDb()
          .prepare(`UPDATE users SET failed_logins = 0, locked_until = datetime('now', '+${LOCK_MINUTES} minutes') WHERE id = ?`)
          .run(user.id);
      } else {
        getDb().prepare('UPDATE users SET failed_logins = ? WHERE id = ?').run(failed, user.id);
      }
    }
    return fail('Invalid username or password.');
  }

  if (user.is_banned || !roleService.isStaff(user.role)) return fail('This account does not have staff access.');

  req.__adminLogin = true;
  audit.log({ user, ip: getIp(req) }, 'Staff signed in with password', `user:${user.id}`);
  return startSession(req, res, user, next);
}

/* ------------------------------ First-run setup ------------------------------ */
function setupPage(req, res) {
  const token = str(req.query.token, 100);
  if (!setup.verifySetupToken(token)) {
    return res.status(403).page('errors/403', {
      title: 'Setup unavailable',
      message: setup.adminExists()
        ? 'Setup has already been completed.'
        : 'This setup link is invalid or has expired. Run "npm run setup" on the server to generate a new one.'
    });
  }
  return res.page('auth/setup', { title: 'Create administrator', noindex: true, token, form: {}, errors: [] });
}

function setupSubmit(req, res) {
  const token = str(req.body.token, 100);
  if (!setup.verifySetupToken(token)) {
    return res.status(403).page('errors/403', { title: 'Setup unavailable', message: 'This setup link is invalid or has expired.' });
  }
  const username = str(req.body.username, 32);
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  const confirm = typeof req.body.confirm === 'string' ? req.body.confirm : '';
  const errors = [];
  if (!/^[A-Za-z0-9_.-]{3,32}$/.test(username)) errors.push('Username must be 3-32 characters (letters, numbers, dot, dash, underscore).');
  if (password.length < 12) errors.push('Password must be at least 12 characters.');
  if (password.length > 200) errors.push('Password is too long.');
  if (!/[a-z]/.test(password) || !/[A-Z]/.test(password) || !/[0-9]/.test(password)) errors.push('Password must include upper-case, lower-case letters and a number.');
  if (password !== confirm) errors.push('Passwords do not match.');
  if (errors.length) {
    return res.status(400).page('auth/setup', { title: 'Create administrator', noindex: true, token, form: { username }, errors });
  }
  try {
    const id = setup.createInitialAdmin({ username, password });
    const user = getDb().prepare('SELECT * FROM users WHERE id = ?').get(id);
    audit.log({ user, ip: getIp(req) }, 'Initial superadmin account created', `user:${id}`);
    req.session.regenerate((err) => {
      if (err) return res.redirect('/auth/admin');
      req.session.userId = id;
      req.session.adminLast = Date.now();
      return req.session.save(() => res.redirect('/admin'));
    });
  } catch (e) {
    return res.status(400).page('auth/setup', { title: 'Create administrator', noindex: true, token, form: { username }, errors: [e.message] });
  }
  return undefined;
}

module.exports = { loginPage, discordStart, discordCallback, logout, adminLoginPage, adminLogin, setupPage, setupSubmit };
