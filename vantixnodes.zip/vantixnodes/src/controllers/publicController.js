'use strict';

const config = require('../config');
const { getDb } = require('../database/connection');
const catalog = require('../models/catalog');
const content = require('../models/content');
const status = require('../services/statusService');
const settings = require('../services/settingsService');
const markdown = require('../utils/markdown');
const { str, int, isEmail, paginate, getIp } = require('../utils/helpers');
const { POST_CATEGORIES } = require('../config/constants');

function home(req, res) {
  const categories = catalog.categories.listActive();
  const plans = catalog.plans.listActive();
  const snapshot = status.snapshot();
  const latestPosts = content.posts.listPublished({ limit: 3 });
  const firstWithPlans = categories.find((c) => plans.some((p) => p.category_id === c.id));
  res.page('pages/home', {
    title: null,
    description: settings.get('seo_description'),
    categories,
    plans,
    activeCategoryId: firstWithPlans ? firstWithPlans.id : null,
    snapshot,
    stats: snapshot.stats,
    latestPosts
  });
}

function categoryPage(req, res, next) {
  const category = catalog.categories.bySlug(req.params.slug);
  if (!category) return next();
  const plans = catalog.plans.listActive({ categorySlug: category.slug });
  return res.page('pages/category', {
    title: category.name,
    description: category.description,
    ogImage: category.image || null,
    category,
    plans,
    categories: catalog.categories.listActive()
  });
}

function plansPage(req, res) {
  const categories = catalog.categories.listActive();
  const plans = catalog.plans.listActive();
  res.page('pages/plans', {
    title: 'Hosting plans',
    description: 'Compare every VantixNodes hosting plan: VPS, RDP, game, bot and web hosting.',
    categories,
    plans
  });
}

function postsList(req, res) {
  const category = Object.keys(POST_CATEGORIES).includes(req.query.category) ? req.query.category : '';
  const perPage = 9;
  const pg = paginate(content.posts.countPublished(category), int(req.query.page, 1, 1, 100000), perPage);
  const posts = content.posts.listPublished({ category, limit: perPage, offset: pg.offset });
  res.page('pages/posts', {
    title: 'News & updates',
    description: 'Announcements, product updates, maintenance notices and tutorials from VantixNodes.',
    posts,
    pg,
    category
  });
}

function postDetail(req, res, next) {
  const post = content.posts.bySlug(req.params.slug);
  if (!post) return next();
  return res.page('pages/post', {
    title: post.title,
    description: post.description || post.title,
    ogImage: post.thumbnail || null,
    ogType: 'article',
    post,
    html: markdown.render(post.content)
  });
}

function teamPage(req, res) {
  res.page('pages/team', {
    title: 'Our team',
    description: 'Meet the people behind VantixNodes.',
    members: catalog.team.listActive()
  });
}

function statusPage(req, res) {
  res.page('pages/status', {
    title: 'System status',
    description: 'Current status of VantixNodes infrastructure and services.',
    snapshot: status.snapshot()
  });
}

function contactPage(req, res) {
  res.page('pages/contact', { title: 'Contact us', description: 'Get in touch with the VantixNodes team.', form: {}, errors: [] });
}

function contactSubmit(req, res) {
  // Honeypot: bots fill the hidden field. Pretend success without storing.
  if (str(req.body.website, 200)) {
    req.flash('success', 'Thanks! Your message has been sent.');
    return res.redirect('/contact');
  }
  const form = {
    name: str(req.body.name, 100),
    email: str(req.body.email, 254),
    subject: str(req.body.subject, 150),
    message: str(req.body.message, 5000)
  };
  const errors = [];
  if (form.name.length < 2) errors.push('Please enter your name.');
  if (!isEmail(form.email)) errors.push('Please enter a valid email address.');
  if (form.subject.length < 3) errors.push('Please enter a subject.');
  if (form.message.length < 10) errors.push('Your message should be at least 10 characters.');
  if (errors.length) {
    return res.status(400).page('pages/contact', { title: 'Contact us', form, errors });
  }
  getDb()
    .prepare('INSERT INTO contact_messages (name, email, subject, message, ip) VALUES (?, ?, ?, ?, ?)')
    .run(form.name, form.email, form.subject, form.message, getIp(req));
  req.flash('success', 'Thanks! Your message has been sent. We will reply by email.');
  return res.redirect('/contact');
}

function robots(req, res) {
  res.type('text/plain').send(
    ['User-agent: *', 'Disallow: /admin', 'Disallow: /account', 'Disallow: /auth', 'Disallow: /api/admin', 'Disallow: /setup', 'Allow: /', `Sitemap: ${config.siteUrl}/sitemap.xml`, ''].join('\n')
  );
}

function sitemap(req, res) {
  const urls = ['/', '/plans', '/posts', '/team', '/status', '/contact'].map((p) => ({ loc: p }));
  for (const c of catalog.categories.listActive()) urls.push({ loc: `/category/${c.slug}` });
  const posts = getDb().prepare('SELECT slug, updated_at FROM posts WHERE published = 1 ORDER BY created_at DESC LIMIT 5000').all();
  for (const p of posts) urls.push({ loc: `/posts/${p.slug}`, lastmod: p.updated_at.slice(0, 10) });
  const xml =
    '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
    urls
      .map((u) => `  <url><loc>${config.siteUrl}${u.loc}</loc>${u.lastmod ? `<lastmod>${u.lastmod}</lastmod>` : ''}</url>`)
      .join('\n') +
    '\n</urlset>\n';
  res.type('application/xml').send(xml);
}

module.exports = { home, categoryPage, plansPage, postsList, postDetail, teamPage, statusPage, contactPage, contactSubmit, robots, sitemap };
