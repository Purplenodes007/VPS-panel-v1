'use strict';

const { getDb } = require('./connection');
const migrations = require('./migrations');
const seed = require('./seed');

/** Applies pending migrations. Never drops or rewrites existing data. */
function runMigrations() {
  const db = getDb();
  db.exec(`CREATE TABLE IF NOT EXISTS migrations (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    applied_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`);
  const applied = new Set(db.prepare('SELECT id FROM migrations').all().map((r) => r.id));
  const applyOne = db.transaction((m) => {
    db.exec(m.sql);
    db.prepare('INSERT INTO migrations (id, name) VALUES (?, ?)').run(m.id, m.name);
  });
  const ran = [];
  for (const m of migrations) {
    if (!applied.has(m.id)) {
      applyOne(m);
      ran.push(m.name);
    }
  }
  return ran;
}

/** Seeds defaults only once (tracked by the `seeded` setting). */
function seedIfNeeded() {
  const db = getDb();
  const row = db.prepare("SELECT value FROM settings WHERE key = 'seeded'").get();
  if (row) return false;
  seed(db);
  return true;
}

function initDatabase() {
  const migrationsRan = runMigrations();
  const seeded = seedIfNeeded();
  return { migrationsRan, seeded };
}

module.exports = { initDatabase, runMigrations, seedIfNeeded };
