'use strict';

/**
 * Ordered, append-only migrations. Each migration runs once and is recorded in
 * the `migrations` table, so restarting the server never touches existing data.
 * To change the schema later, add a NEW entry at the end - never edit old ones.
 */
const migrations = [
  {
    id: 1,
    name: 'initial_schema',
    sql: `
      CREATE TABLE roles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        label TEXT NOT NULL,
        permissions TEXT NOT NULL DEFAULT '[]',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        discord_id TEXT UNIQUE,
        username TEXT NOT NULL,
        global_name TEXT,
        avatar TEXT,
        email TEXT,
        role TEXT NOT NULL DEFAULT 'user' REFERENCES roles(name) ON UPDATE CASCADE,
        password_hash TEXT,
        local_username TEXT UNIQUE,
        is_banned INTEGER NOT NULL DEFAULT 0,
        failed_logins INTEGER NOT NULL DEFAULT 0,
        locked_until TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        last_login TEXT
      );
      CREATE INDEX idx_users_role ON users(role);
      CREATE INDEX idx_users_created ON users(created_at);

      CREATE TABLE sessions (
        sid TEXT PRIMARY KEY,
        data TEXT NOT NULL,
        expires_at INTEGER NOT NULL
      );
      CREATE INDEX idx_sessions_expires ON sessions(expires_at);

      CREATE TABLE settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        description TEXT NOT NULL DEFAULT '',
        icon TEXT NOT NULL DEFAULT 'server',
        image TEXT NOT NULL DEFAULT '',
        status INTEGER NOT NULL DEFAULT 1,
        display_order INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE INDEX idx_categories_order ON categories(status, display_order);

      CREATE TABLE plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
        name TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        price REAL NOT NULL DEFAULT 0,
        currency TEXT NOT NULL DEFAULT 'USD',
        billing_period TEXT NOT NULL DEFAULT 'month',
        cpu TEXT NOT NULL DEFAULT '',
        ram TEXT NOT NULL DEFAULT '',
        storage TEXT NOT NULL DEFAULT '',
        bandwidth TEXT NOT NULL DEFAULT '',
        network_speed TEXT NOT NULL DEFAULT '',
        locations TEXT NOT NULL DEFAULT '',
        features TEXT NOT NULL DEFAULT '[]',
        badge TEXT NOT NULL DEFAULT '',
        color TEXT NOT NULL DEFAULT '',
        order_url TEXT NOT NULL DEFAULT '',
        status INTEGER NOT NULL DEFAULT 1,
        display_order INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE INDEX idx_plans_category ON plans(category_id, status, display_order);

      CREATE TABLE application_questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        label TEXT NOT NULL,
        help_text TEXT NOT NULL DEFAULT '',
        type TEXT NOT NULL DEFAULT 'text',
        options TEXT NOT NULL DEFAULT '',
        required INTEGER NOT NULL DEFAULT 1,
        status INTEGER NOT NULL DEFAULT 1,
        display_order INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        position TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'pending',
        internal_note TEXT NOT NULL DEFAULT '',
        reviewed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE INDEX idx_applications_user ON applications(user_id);
      CREATE INDEX idx_applications_status ON applications(status, created_at);

      CREATE TABLE application_answers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        application_id INTEGER NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
        question_id INTEGER REFERENCES application_questions(id) ON DELETE SET NULL,
        question_label TEXT NOT NULL,
        answer TEXT NOT NULL DEFAULT ''
      );
      CREATE INDEX idx_answers_application ON application_answers(application_id);

      CREATE TABLE team_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        application_id INTEGER REFERENCES applications(id) ON DELETE SET NULL,
        name TEXT NOT NULL,
        username TEXT NOT NULL DEFAULT '',
        avatar TEXT NOT NULL DEFAULT '',
        role TEXT NOT NULL DEFAULT 'Staff',
        bio TEXT NOT NULL DEFAULT '',
        social_links TEXT NOT NULL DEFAULT '[]',
        status INTEGER NOT NULL DEFAULT 1,
        display_order INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE INDEX idx_team_order ON team_members(status, display_order);

      CREATE TABLE posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        description TEXT NOT NULL DEFAULT '',
        content TEXT NOT NULL DEFAULT '',
        thumbnail TEXT NOT NULL DEFAULT '',
        author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        category TEXT NOT NULL DEFAULT 'news',
        published INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE INDEX idx_posts_published ON posts(published, created_at);
      CREATE INDEX idx_posts_category ON posts(category);

      CREATE TABLE ticket_categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        status INTEGER NOT NULL DEFAULT 1,
        display_order INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        subject TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'General',
        priority TEXT NOT NULL DEFAULT 'normal',
        status TEXT NOT NULL DEFAULT 'open',
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE INDEX idx_tickets_user ON tickets(user_id, updated_at);
      CREATE INDEX idx_tickets_status ON tickets(status, updated_at);

      CREATE TABLE ticket_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
        user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        is_staff INTEGER NOT NULL DEFAULT 0,
        message TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE INDEX idx_ticket_messages_ticket ON ticket_messages(ticket_id, created_at);

      CREATE TABLE social_links (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        platform TEXT NOT NULL,
        display_name TEXT NOT NULL,
        url TEXT NOT NULL,
        icon TEXT NOT NULL DEFAULT 'link',
        status INTEGER NOT NULL DEFAULT 1,
        display_order INTEGER NOT NULL DEFAULT 0
      );
      CREATE INDEX idx_social_order ON social_links(status, display_order);

      CREATE TABLE status_services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        description TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'operational',
        source TEXT NOT NULL DEFAULT 'manual',
        api_url TEXT NOT NULL DEFAULT '',
        visible INTEGER NOT NULL DEFAULT 1,
        display_order INTEGER NOT NULL DEFAULT 0,
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE INDEX idx_status_order ON status_services(visible, display_order);

      CREATE TABLE audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admin_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        admin_name TEXT NOT NULL DEFAULT '',
        action TEXT NOT NULL,
        target TEXT NOT NULL DEFAULT '',
        details TEXT NOT NULL DEFAULT '',
        ip TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE INDEX idx_audit_created ON audit_logs(created_at);
      CREATE INDEX idx_audit_admin ON audit_logs(admin_id);

      CREATE TABLE contact_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        subject TEXT NOT NULL,
        message TEXT NOT NULL,
        ip TEXT NOT NULL DEFAULT '',
        is_read INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE INDEX idx_contact_created ON contact_messages(is_read, created_at);

      CREATE TABLE notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        title TEXT NOT NULL,
        body TEXT NOT NULL DEFAULT '',
        link TEXT NOT NULL DEFAULT '',
        is_read INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE INDEX idx_notifications_user ON notifications(user_id, is_read, created_at);

      CREATE TABLE user_activity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        action TEXT NOT NULL,
        ip TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE INDEX idx_activity_user ON user_activity(user_id, created_at);
    `
  }
];

module.exports = migrations;
