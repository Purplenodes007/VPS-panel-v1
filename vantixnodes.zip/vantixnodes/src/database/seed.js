'use strict';

const ROLES = [
  { name: 'user', label: 'User', permissions: [] },
  { name: 'moderator', label: 'Moderator', permissions: ['tickets', 'applications', 'contact', 'posts'] },
  {
    name: 'admin',
    label: 'Administrator',
    permissions: ['overview', 'settings', 'theme', 'background', 'categories', 'plans', 'applications', 'team', 'posts', 'socials', 'users', 'status', 'tickets', 'contact', 'audit']
  },
  {
    name: 'superadmin',
    label: 'Super Administrator',
    permissions: ['*']
  }
];

const SETTINGS = {
  // General
  site_name: 'VantixNodes',
  site_tagline: 'High-performance hosting built for reliability, speed, and scalability.',
  site_description:
    'VantixNodes provides VPS, RDP, game server, Discord bot and web hosting on modern NVMe infrastructure with responsive human support.',
  logo_url: '',
  favicon_url: '',
  footer_text: 'High-performance hosting built for reliability, speed, and scalability.',
  contact_email: 'support@vantixnodes.example',
  maintenance_mode: '0',

  // Theme
  color_primary: '#6366f1',
  color_secondary: '#22d3ee',
  color_accent: '#a855f7',
  color_background: '#07090f',
  color_surface: '#0e1220',
  color_text: '#e8ecf6',
  color_muted: '#8b94ad',
  color_border: '#1f2740',
  button_style: 'gradient',
  border_radius: '16',
  font: 'Inter',
  animations_enabled: '1',

  // Background
  bg_type: 'gradient',
  bg_color: '#07090f',
  bg_gradient_from: '#07090f',
  bg_gradient_to: '#141a33',
  bg_gradient_angle: '160',
  bg_image_url: '',
  bg_video_url: '',
  bg_overlay: '60',
  bg_video_opacity: '60',

  // Hero
  hero_badge: 'NVMe-powered infrastructure',
  hero_title: 'Power Your Projects With VantixNodes',
  hero_subtitle: 'Reliable VPS, RDP, game, bot and web hosting built for performance.',
  hero_btn1_text: 'View Plans',
  hero_btn1_url: '/#plans',
  hero_btn2_text: 'Get Started',
  hero_btn2_url: '/auth/login',
  hero_btn3_text: 'Join Discord',
  hero_btn3_url: 'https://discord.gg/',

  // SEO
  seo_title: 'VantixNodes | VPS, RDP, Game & Bot Hosting',
  seo_description:
    'High-performance VPS, RDP, Minecraft/game, Discord bot and web hosting. Transparent pricing, NVMe storage and friendly support.',
  seo_keywords: 'vps hosting, rdp hosting, minecraft hosting, discord bot hosting, web hosting, vantixnodes',
  seo_og_image: '',

  // Statistics (admin-configurable - not live measurements)
  stat_uptime: '99.9%',
  stat_locations: '6',
  stat_servers: '250+',
  stat_customers: '1,200+',
  stat_network: '10 Gbps',

  // Staff applications
  applications_open: '1',
  applications_intro:
    'Want to help build VantixNodes? Tell us about yourself and the role you are interested in. Applications are reviewed by our team.',
  applications_positions: 'Support Staff\nModerator\nSystem Administrator\nCommunity Manager\nDeveloper',
  auto_create_team: '1',

  // Misc
  setup_complete: '0',
  setup_token_hash: ''
};

const CATEGORIES = [
  { name: 'VPS Hosting', slug: 'vps', icon: 'server', description: 'Scalable KVM virtual servers with dedicated resources, full root access and NVMe storage.', display_order: 1 },
  { name: 'RDP Hosting', slug: 'rdp', icon: 'monitor', description: 'Windows remote desktops with dedicated cores for trading, automation and remote work.', display_order: 2 },
  { name: 'Game Hosting', slug: 'game-hosting', icon: 'gamepad', description: 'Minecraft and game servers with instant setup, DDoS mitigation and one-click modpacks.', display_order: 3 },
  { name: 'Discord Bot Hosting', slug: 'discord-bot-hosting', icon: 'bot', description: 'Keep your Discord bots online around the clock with Node.js and Python support.', display_order: 4 },
  { name: 'Web Hosting', slug: 'web-hosting', icon: 'globe', description: 'Fast, secure web hosting for websites, blogs and stores with free SSL.', display_order: 5 }
];

// category slug -> plans
const PLANS = {
  vps: [
    { name: 'VPS Starter', description: 'Great for small apps, APIs and dev environments.', price: 7.99, cpu: '2 vCPU', ram: '4 GB RAM', storage: '60 GB NVMe', bandwidth: '2 TB Traffic', network_speed: '1 Gbps', locations: 'Multiple Locations', features: ['Full root access', 'KVM virtualization', 'IPv4 + IPv6', 'Instant deployment'], badge: '' },
    { name: 'VPS Pro', description: 'Balanced power for production workloads.', price: 15.99, cpu: '4 vCPU', ram: '8 GB RAM', storage: '120 GB NVMe', bandwidth: '4 TB Traffic', network_speed: '1 Gbps', locations: 'Multiple Locations', features: ['Full root access', 'KVM virtualization', 'Free snapshots', 'DDoS protection'], badge: 'Popular' },
    { name: 'VPS Elite', description: 'High-memory servers for databases and heavy services.', price: 31.99, cpu: '8 vCPU', ram: '16 GB RAM', storage: '240 GB NVMe', bandwidth: '8 TB Traffic', network_speed: '2.5 Gbps', locations: 'Multiple Locations', features: ['Full root access', 'Dedicated resources', 'Priority support', 'DDoS protection'], badge: 'Best value' }
  ],
  rdp: [
    { name: 'RDP Basic', description: 'Windows desktop for everyday remote work.', price: 9.99, cpu: '2 vCPU', ram: '4 GB RAM', storage: '80 GB NVMe', bandwidth: '2 TB Traffic', network_speed: '1 Gbps', locations: 'Multiple Locations', features: ['Windows Server', 'Administrator access', 'Remote Desktop Protocol'], badge: '' },
    { name: 'RDP Business', description: 'More cores and memory for multitasking.', price: 19.99, cpu: '4 vCPU', ram: '8 GB RAM', storage: '160 GB NVMe', bandwidth: '4 TB Traffic', network_speed: '1 Gbps', locations: 'Multiple Locations', features: ['Windows Server', 'Administrator access', 'Free snapshots'], badge: 'Popular' }
  ],
  'game-hosting': [
    { name: 'Minecraft Starter', description: 'Vanilla, Paper or Fabric for you and your friends.', price: 4.99, cpu: '2 vCPU', ram: '4 GB RAM', storage: '20 GB NVMe', bandwidth: 'Unmetered', network_speed: '1 Gbps', locations: 'Multiple Locations', features: ['Instant setup', 'DDoS protection', 'Plugin and mod support', 'Automatic backups'], badge: '' },
    { name: 'Minecraft Plus', description: 'Run modpacks and busy communities.', price: 9.99, cpu: '3 vCPU', ram: '8 GB RAM', storage: '40 GB NVMe', bandwidth: 'Unmetered', network_speed: '1 Gbps', locations: 'Multiple Locations', features: ['One-click modpacks', 'DDoS protection', 'Custom subdomain', 'Automatic backups'], badge: 'Popular' },
    { name: 'Minecraft Ultimate', description: 'Maximum performance for large networks.', price: 19.99, cpu: '6 vCPU', ram: '16 GB RAM', storage: '80 GB NVMe', bandwidth: 'Unmetered', network_speed: '2.5 Gbps', locations: 'Multiple Locations', features: ['Dedicated cores', 'Priority support', 'DDoS protection', 'Automatic backups'], badge: '' }
  ],
  'discord-bot-hosting': [
    { name: 'Bot Lite', description: 'Perfect for a single small bot.', price: 1.99, cpu: '0.5 vCPU', ram: '512 MB RAM', storage: '5 GB NVMe', bandwidth: 'Unmetered', network_speed: '1 Gbps', locations: 'Multiple Locations', features: ['Node.js and Python', 'Always-on process', 'Live console'], badge: '' },
    { name: 'Bot Plus', description: 'More resources for growing bots.', price: 3.99, cpu: '1 vCPU', ram: '1 GB RAM', storage: '10 GB NVMe', bandwidth: 'Unmetered', network_speed: '1 Gbps', locations: 'Multiple Locations', features: ['Node.js and Python', 'Live console', 'File manager', 'Auto restart'], badge: 'Popular' },
    { name: 'Bot Max', description: 'Sharded bots and database-backed workloads.', price: 7.99, cpu: '2 vCPU', ram: '2 GB RAM', storage: '20 GB NVMe', bandwidth: 'Unmetered', network_speed: '1 Gbps', locations: 'Multiple Locations', features: ['Node.js and Python', 'Database access', 'Priority support', 'Auto restart'], badge: '' }
  ],
  'web-hosting': [
    { name: 'Web Starter', description: 'A single fast website with free SSL.', price: 2.99, cpu: 'Shared', ram: '1 GB RAM', storage: '10 GB NVMe', bandwidth: '100 GB', network_speed: '1 Gbps', locations: 'Multiple Locations', features: ['1 website', 'Free SSL', 'Daily backups', 'One-click installer'], badge: '' },
    { name: 'Web Business', description: 'Host multiple sites with more resources.', price: 5.99, cpu: 'Shared (priority)', ram: '2 GB RAM', storage: '50 GB NVMe', bandwidth: '1 TB', network_speed: '1 Gbps', locations: 'Multiple Locations', features: ['10 websites', 'Free SSL', 'Daily backups', 'Staging environment'], badge: 'Popular' }
  ]
};

const STATUS_SERVICES = [
  { name: 'VPS Hosting', slug: 'vps', description: 'KVM virtual servers' },
  { name: 'RDP Hosting', slug: 'rdp', description: 'Windows remote desktops' },
  { name: 'Game Hosting', slug: 'game', description: 'Minecraft and game servers' },
  { name: 'Bot Hosting', slug: 'bot', description: 'Discord bot hosting' },
  { name: 'Web Hosting', slug: 'web', description: 'Websites and control panel' },
  { name: 'Network', slug: 'network', description: 'Backbone and DDoS mitigation' }
];

const SOCIALS = [
  { platform: 'Discord', display_name: 'Join our Discord', url: 'https://discord.gg/', icon: 'discord' },
  { platform: 'YouTube', display_name: 'YouTube', url: 'https://youtube.com/', icon: 'youtube' },
  { platform: 'GitHub', display_name: 'GitHub', url: 'https://github.com/', icon: 'github' },
  { platform: 'X', display_name: 'X / Twitter', url: 'https://x.com/', icon: 'x' }
];

const APPLICATION_QUESTIONS = [
  { label: 'Full name', type: 'text', required: 1 },
  { label: 'Age', type: 'number', required: 1 },
  { label: 'Discord username', type: 'text', required: 1 },
  { label: 'Experience', type: 'textarea', required: 1, help_text: 'Tell us about previous hosting, support or community experience.' },
  { label: 'Why should we select you?', type: 'textarea', required: 1 },
  { label: 'Availability', type: 'text', required: 1, help_text: 'Hours per week and your timezone.' },
  { label: 'Portfolio or links', type: 'url', required: 0 }
];

const TICKET_CATEGORIES = ['General', 'Billing', 'Technical Support', 'Sales', 'Abuse Report'];

const POSTS = [
  {
    title: 'Welcome to VantixNodes',
    slug: 'welcome-to-vantixnodes',
    category: 'announcement',
    description: 'Introducing our new hosting platform for VPS, RDP, game, bot and web hosting.',
    content: 'We are excited to launch the new VantixNodes platform.\n\nOur goal is simple: provide fast, reliable hosting with honest specifications and responsive support.\n\nYou can browse every plan from the homepage, sign in with Discord to open support tickets, and follow this page for maintenance notices and product updates.\n\nThank you for being part of the community.'
  },
  {
    title: 'How we handle scheduled maintenance',
    slug: 'scheduled-maintenance-policy',
    category: 'update',
    description: 'What to expect when we need to perform maintenance on our infrastructure.',
    content: 'From time to time we need to update hardware or software across our nodes.\n\nWe announce planned work in advance on this page and in our Discord server, and the status page shows affected services while work is in progress.\n\nWe always aim to keep the impact as small as possible.'
  }
];

function seed(db) {
  const tx = db.transaction(() => {
    const insRole = db.prepare('INSERT OR IGNORE INTO roles (name, label, permissions) VALUES (?, ?, ?)');
    for (const r of ROLES) insRole.run(r.name, r.label, JSON.stringify(r.permissions));

    const insSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
    for (const [k, v] of Object.entries(SETTINGS)) insSetting.run(k, v);

    const insCat = db.prepare(
      'INSERT INTO categories (name, slug, description, icon, display_order) VALUES (@name, @slug, @description, @icon, @display_order)'
    );
    const catIds = {};
    for (const c of CATEGORIES) catIds[c.slug] = insCat.run(c).lastInsertRowid;

    const insPlan = db.prepare(`INSERT INTO plans
      (category_id, name, description, price, billing_period, cpu, ram, storage, bandwidth, network_speed, locations, features, badge, display_order)
      VALUES (@category_id, @name, @description, @price, 'month', @cpu, @ram, @storage, @bandwidth, @network_speed, @locations, @features, @badge, @display_order)`);
    for (const [slug, plans] of Object.entries(PLANS)) {
      plans.forEach((p, i) =>
        insPlan.run({ ...p, features: JSON.stringify(p.features), category_id: catIds[slug], display_order: i + 1 })
      );
    }

    const insStatus = db.prepare('INSERT INTO status_services (name, slug, description, display_order) VALUES (?, ?, ?, ?)');
    STATUS_SERVICES.forEach((s, i) => insStatus.run(s.name, s.slug, s.description, i + 1));

    const insSocial = db.prepare('INSERT INTO social_links (platform, display_name, url, icon, display_order) VALUES (?, ?, ?, ?, ?)');
    SOCIALS.forEach((s, i) => insSocial.run(s.platform, s.display_name, s.url, s.icon, i + 1));

    const insQ = db.prepare(
      'INSERT INTO application_questions (label, help_text, type, required, display_order) VALUES (?, ?, ?, ?, ?)'
    );
    APPLICATION_QUESTIONS.forEach((q, i) => insQ.run(q.label, q.help_text || '', q.type, q.required, i + 1));

    const insTc = db.prepare('INSERT INTO ticket_categories (name, display_order) VALUES (?, ?)');
    TICKET_CATEGORIES.forEach((n, i) => insTc.run(n, i + 1));

    const insPost = db.prepare(
      'INSERT INTO posts (title, slug, description, content, category, published) VALUES (?, ?, ?, ?, ?, 1)'
    );
    for (const p of POSTS) insPost.run(p.title, p.slug, p.description, p.content, p.category);

    db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('seeded', '1')").run();
  });
  tx();
}

module.exports = seed;
