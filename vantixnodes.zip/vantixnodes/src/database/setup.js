'use strict';
require('../utils/nodeCheck');

/**
 * `npm run setup`
 * - Creates the SQLite database if it does not exist
 * - Applies pending migrations (never destroys existing data)
 * - Seeds default settings/categories/plans on first run only
 * - Prepares the one-time admin setup flow
 */

const fs = require('fs');
const config = require('../config');
const { initDatabase } = require('./init');
const { getDb, closeDb } = require('./connection');
const { createSetupToken } = require('../services/setupService');

const existed = fs.existsSync(config.databasePath);
const result = initDatabase();
const db = getDb();

console.log(existed ? 'Existing database found - data preserved.' : 'New database created.');
console.log(`Database: ${config.databasePath}`);
console.log(result.migrationsRan.length ? `Migrations applied: ${result.migrationsRan.join(', ')}` : 'No pending migrations.');
console.log(result.seeded ? 'Default settings, categories, plans and content created.' : 'Defaults already present - nothing overwritten.');

const adminExists = db.prepare("SELECT 1 FROM users WHERE role IN ('admin','superadmin') LIMIT 1").get();
if (adminExists) {
  console.log('An administrator account already exists. Setup flow is closed.');
} else {
  const token = createSetupToken();
  console.log('\n=== INITIAL ADMIN SETUP ===');
  console.log('No administrator exists yet. Open this one-time URL to create the owner account:');
  console.log(`\n  ${config.siteUrl}/setup?token=${token}\n`);
  console.log('The token is shown only now. Re-run `npm run setup` to generate a new one.');
  console.log('Alternatively set INITIAL_ADMIN_DISCORD_ID in .env to promote a Discord account on first login.');
}

closeDb();
