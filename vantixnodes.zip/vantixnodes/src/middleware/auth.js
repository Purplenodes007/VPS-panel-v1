'use strict';

const config = require('../config');
const { getDb } = require('../database/connection');
const roleService = require('../services/roleService');
const { safeEqual } = require('../utils/helpers');

/** Loads the signed-in user from the database on every request. */
function loadUser(req, res, next) {
  const id = req.session && req.session.userId;
  if (!id) return next();
  const user = getDb().prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!user || user.is_banned) {
    return req.session.destroy(() => {
      res.clearCookie(config.session.cookieName);
      next();
    });
  }
  req.user = user;
  res.locals.setUser(user);
  return next();
}

function wantsJson(req) {
  return req.originalUrl.startsWith('/api') || req.path === '/upload' || (req.get('accept') || '').includes('application/json');
}

function requireAuth(req, res, next) {
  if (req.user) return next();
  if (wantsJson(req)) return res.status(401).json({ error: 'Authentication required.' });
  if (req.method === 'GET') req.session.returnTo = req.originalUrl;
  return res.redirect('/auth/login');
}

/** Staff areas: valid permission AND not idle for too long. */
function requirePermission(permission) {
  return (req, res, next) => {
    if (!req.user) {
      if (wantsJson(req)) return res.status(401).json({ error: 'Authentication required.' });
      if (req.method === 'GET') req.session.returnTo = req.originalUrl;
      return res.redirect('/auth/admin');
    }
    const last = req.session.adminLast || Date.now();
    if (Date.now() - last > config.session.adminIdleMs) {
      return req.session.destroy(() => {
        res.clearCookie(config.session.cookieName);
        if (wantsJson(req)) return res.status(401).json({ error: 'Session expired.' });
        return res.redirect('/auth/admin');
      });
    }
    if (!roleService.isStaff(req.user.role) || (permission && !roleService.can(req.user.role, permission))) {
      if (wantsJson(req)) return res.status(403).json({ error: 'Forbidden.' });
      return res.status(403).page('errors/403', { title: 'Access denied' });
    }
    req.session.adminLast = Date.now();
    return next();
  };
}

function requireSuperadmin(req, res, next) {
  if (!req.user || req.user.role !== 'superadmin') {
    if (wantsJson(req)) return res.status(403).json({ error: 'Forbidden.' });
    return res.status(403).page('errors/403', { title: 'Access denied' });
  }
  return next();
}

/** CSRF protection for every state-changing request. */
function csrfProtection(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();

  // Defense in depth: reject cross-origin browser requests outright.
  const origin = req.get('origin');
  if (origin) {
    try {
      if (new URL(origin).host !== req.get('host')) return csrfFail(req, res);
    } catch (e) {
      return csrfFail(req, res);
    }
  }

  const sent = (req.body && req.body._csrf) || req.query._csrf || req.get('x-csrf-token');
  const expected = req.session && req.session.csrf;
  if (!expected || !sent || !safeEqual(sent, expected)) return csrfFail(req, res);
  return next();
}

function csrfFail(req, res) {
  if (wantsJson(req)) return res.status(403).json({ error: 'Invalid or missing security token. Reload the page and try again.' });
  return res.status(403).page('errors/403', {
    title: 'Security check failed',
    message: 'Your security token was missing or expired. Please go back, reload the page and try again.'
  });
}

module.exports = { loadUser, requireAuth, requirePermission, requireSuperadmin, csrfProtection, wantsJson };
