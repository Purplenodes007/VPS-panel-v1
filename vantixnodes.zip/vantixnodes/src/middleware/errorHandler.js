'use strict';

const config = require('../config');
const { wantsJson } = require('./auth');

function notFound(req, res) {
  if (wantsJson(req)) return res.status(404).json({ error: 'Not found.' });
  return res.status(404).page('errors/404', { title: 'Page not found' });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  const status = err.status || err.statusCode || 500;
  if (status >= 500) console.error(`[error] ${req.method} ${req.originalUrl}:`, err);

  if (res.headersSent) return next(err);

  if (err.type === 'entity.too.large') {
    return wantsJson(req) ? res.status(413).json({ error: 'Request too large.' }) : res.status(413).send('Request too large.');
  }
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Malformed request body.' });
  }

  if (wantsJson(req)) {
    return res.status(status).json({ error: status >= 500 ? 'Internal server error.' : err.message });
  }

  const message = !config.isProd && status >= 500 ? err.message : undefined;
  if (typeof res.page !== 'function') return res.status(status).send('Something went wrong.');
  const view = status === 403 ? 'errors/403' : status === 404 ? 'errors/404' : 'errors/500';
  return res.status(status === 403 || status === 404 ? status : 500).page(view, { title: 'Error', message });
}

module.exports = { notFound, errorHandler };
