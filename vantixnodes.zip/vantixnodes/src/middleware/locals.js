'use strict';

const path = require('path');
const config = require('../config');
const settings = require('../services/settingsService');
const roleService = require('../services/roleService');
const statusService = require('../services/statusService');
const { getDb } = require('../database/connection');
const { icon, NAMES: ICON_NAMES } = require('../utils/icons');
const helpers = require('../utils/helpers');
const constants = require('../config/constants');
const { randomToken } = require('../utils/helpers');

/**
 * Adds `res.page(view, data, layout)` which renders a view inside a layout, plus
 * the template locals shared by every page (settings, user, csrf helper, ...).
 */
function locals(req, res, next) {
  const s = settings.all();

  res.locals.settings = s;
  res.locals.siteName = s.site_name || 'VantixNodes';
  res.locals.icon = icon;
  res.locals.iconNames = ICON_NAMES;
  res.locals.h = helpers;
  res.locals.C = constants;
  res.locals.currentPath = req.originalUrl.split('?')[0];
  res.locals.query = req.query || {};
  res.locals.assetVersion = req.app.locals.assetVersion;
  res.locals.canonical = `${config.siteUrl}${req.path === '/' ? '' : req.path}`;
  res.locals.siteUrl = config.siteUrl;
  res.locals.themeCss = settings.themeCss();
  res.locals.fontHref = settings.fontHref();
  res.locals.bg = settings.background();
  res.locals.user = null;
  res.locals.isStaff = false;
  res.locals.can = () => false;
  res.locals.csrf = () => {
    if (!req.session) return '';
    if (!req.session.csrf) req.session.csrf = randomToken(24);
    return req.session.csrf;
  };
  res.locals.pageTitle = null;
  res.locals.metaDescription = null;
  res.locals.ogImage = null;
  res.locals.noindex = false;
  res.locals.extraScripts = [];

  try {
    const db = getDb();
    res.locals.socials = db.prepare('SELECT * FROM social_links WHERE status = 1 ORDER BY display_order, id').all();
    res.locals.footerCategories = db.prepare('SELECT name, slug FROM categories WHERE status = 1 ORDER BY display_order, id').all();
    res.locals.overallStatus = statusService.overall(statusService.listServices());
  } catch (e) {
    res.locals.socials = [];
    res.locals.footerCategories = [];
    res.locals.overallStatus = { status: 'operational', label: 'System status' };
  }

  // Flash messages (one-shot, stored in the session)
  req.flash = (type, message) => {
    req.session.flash = { type, message };
  };
  if (req.session && req.session.flash) {
    res.locals.flash = req.session.flash;
    delete req.session.flash;
  } else {
    res.locals.flash = null;
  }

  res.page = function page(view, data = {}, layout = 'main') {
    const opts = { ...data };
    return req.app.render(view, { ...res.locals, ...opts }, (err, body) => {
      if (err) return next(err);
      return res.render(`layouts/${layout}`, { ...opts, body });
    });
  };

  res.locals.setUser = (user) => {
    res.locals.user = user;
    res.locals.isStaff = !!user && roleService.isStaff(user.role);
    res.locals.can = (perm) => !!user && roleService.can(user.role, perm);
    res.locals.avatarUrl = helpers.discordAvatarUrl(user);
  };

  next();
}

module.exports = locals;
module.exports.rootViews = path.join(config.root, 'views');
