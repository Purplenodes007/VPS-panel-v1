'use strict';

const crypto = require('crypto');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const config = require('../config');

/** Per-request CSP nonce for the few inline <style>/<script> blocks we emit. */
function nonce(req, res, next) {
  res.locals.nonce = crypto.randomBytes(16).toString('base64');
  next();
}

function helmetMiddleware() {
  const secure = config.secureCookies;
  return helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", (req, res) => `'nonce-${res.locals.nonce}'`],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
        imgSrc: ["'self'", 'data:', 'https:'],
        mediaSrc: ["'self'", 'https:'],
        connectSrc: ["'self'", 'ws:', 'wss:'],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'none'"],
        ...(secure ? { upgradeInsecureRequests: [] } : {})
      }
    },
    strictTransportSecurity: secure ? { maxAge: 31536000, includeSubDomains: true } : false,
    crossOriginEmbedderPolicy: false,
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' }
  });
}

function limiter({ windowMs, max, message, skipSuccessfulRequests = false }) {
  return rateLimit({
    windowMs,
    max,
    standardHeaders: true,
    legacyHeaders: false,
    skipSuccessfulRequests,
    handler: (req, res) => {
      const wantsJson = req.originalUrl.startsWith('/api') || req.path === '/upload' || (req.get('accept') || '').includes('application/json');
      if (wantsJson) return res.status(429).json({ error: message || 'Too many requests. Please slow down.' });
      return res.status(429).page('errors/429', { title: 'Too many requests', message: message || 'You are sending requests too quickly. Please wait a moment and try again.' });
    }
  });
}

const minute = 60 * 1000;
const hour = 60 * minute;

module.exports = {
  nonce,
  helmetMiddleware,
  limiters: {
    global: limiter({ windowMs: minute, max: 300 }),
    api: limiter({ windowMs: minute, max: 120 }),
    auth: limiter({ windowMs: 15 * minute, max: 30, message: 'Too many sign-in attempts. Try again in a few minutes.' }),
    adminLogin: limiter({ windowMs: 15 * minute, max: 10, skipSuccessfulRequests: true, message: 'Too many login attempts. Try again in 15 minutes.' }),
    contact: limiter({ windowMs: hour, max: 5, message: 'You have sent too many messages. Please try again later.' }),
    tickets: limiter({ windowMs: hour, max: 20, message: 'Too many ticket actions. Please try again later.' }),
    applications: limiter({ windowMs: 24 * hour, max: 5, message: 'Application limit reached. Please try again tomorrow.' }),
    upload: limiter({ windowMs: hour, max: 60, message: 'Upload limit reached. Please try again later.' })
  }
};
