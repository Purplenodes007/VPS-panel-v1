'use strict';

const { getDb } = require('../database/connection');
const { parseJson } = require('../utils/helpers');

function hydratePlan(p) {
  if (!p) return p;
  return { ...p, features: parseJson(p.features, []) };
}

/** Moves a row up/down within its ordering, swapping display_order with its neighbour. */
function move(table, id, dir, scopeColumn = null) {
  const allowed = {
    categories: null,
    plans: 'category_id',
    team_members: null,
    social_links: null,
    status_services: null,
    application_questions: null,
    ticket_categories: null
  };
  if (!(table in allowed) || allowed[table] !== scopeColumn) throw new Error('Invalid move target');
  const db = getDb();
  const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
  if (!row) return false;
  const scope = scopeColumn ? `AND ${scopeColumn} = @scope` : '';
  const cmp = dir === 'up' ? '<' : '>';
  const order = dir === 'up' ? 'DESC' : 'ASC';
  const neighbour = db
    .prepare(
      `SELECT * FROM ${table} WHERE (display_order ${cmp} @o OR (display_order = @o AND id ${cmp} @id)) ${scope} ORDER BY display_order ${order}, id ${order} LIMIT 1`
    )
    .get({ o: row.display_order, id: row.id, scope: scopeColumn ? row[scopeColumn] : undefined });
  if (!neighbour) return false;
  const tx = db.transaction(() => {
    // If both share the same order value, spread them so the swap is meaningful.
    let a = row.display_order;
    let b = neighbour.display_order;
    if (a === b) {
      if (dir === 'up') a += 1;
      else b += 1;
    }
    db.prepare(`UPDATE ${table} SET display_order = ? WHERE id = ?`).run(b, row.id);
    db.prepare(`UPDATE ${table} SET display_order = ? WHERE id = ?`).run(a, neighbour.id);
  });
  tx();
  return true;
}

function nextOrder(table, scopeColumn = null, scopeValue = null) {
  const db = getDb();
  const row = scopeColumn
    ? db.prepare(`SELECT COALESCE(MAX(display_order), 0) + 1 AS n FROM ${table} WHERE ${scopeColumn} = ?`).get(scopeValue)
    : db.prepare(`SELECT COALESCE(MAX(display_order), 0) + 1 AS n FROM ${table}`).get();
  return row.n;
}

/* ------------------------------ categories ------------------------------ */
const categories = {
  listActive() {
    return getDb()
      .prepare(
        `SELECT c.*, (SELECT MIN(p.price) FROM plans p WHERE p.category_id = c.id AND p.status = 1) AS starting_price,
                (SELECT p.currency FROM plans p WHERE p.category_id = c.id AND p.status = 1 ORDER BY p.price LIMIT 1) AS currency,
                (SELECT COUNT(*) FROM plans p WHERE p.category_id = c.id AND p.status = 1) AS plan_count
         FROM categories c WHERE c.status = 1 ORDER BY c.display_order, c.id`
      )
      .all();
  },
  listAll() {
    return getDb()
      .prepare('SELECT c.*, (SELECT COUNT(*) FROM plans p WHERE p.category_id = c.id) AS plan_count FROM categories c ORDER BY c.display_order, c.id')
      .all();
  },
  bySlug(slug, onlyActive = true) {
    return getDb().prepare(`SELECT * FROM categories WHERE slug = ? ${onlyActive ? 'AND status = 1' : ''}`).get(slug);
  },
  byId(id) {
    return getDb().prepare('SELECT * FROM categories WHERE id = ?').get(id);
  },
  insert(d) {
    return getDb()
      .prepare('INSERT INTO categories (name, slug, description, icon, image, status, display_order) VALUES (@name, @slug, @description, @icon, @image, @status, @display_order)')
      .run(d).lastInsertRowid;
  },
  update(id, d) {
    getDb()
      .prepare('UPDATE categories SET name=@name, slug=@slug, description=@description, icon=@icon, image=@image, status=@status WHERE id=@id')
      .run({ ...d, id });
  },
  remove(id) {
    getDb().prepare('DELETE FROM categories WHERE id = ?').run(id);
  }
};

/* --------------------------------- plans -------------------------------- */
const plans = {
  listActive({ categorySlug } = {}) {
    const rows = getDb()
      .prepare(
        `SELECT p.*, c.name AS category_name, c.slug AS category_slug FROM plans p JOIN categories c ON c.id = p.category_id
         WHERE p.status = 1 AND c.status = 1 ${categorySlug ? 'AND c.slug = @slug' : ''}
         ORDER BY c.display_order, c.id, p.display_order, p.id`
      )
      .all(categorySlug ? { slug: categorySlug } : {});
    return rows.map(hydratePlan);
  },
  listAll(categoryId = null) {
    const rows = getDb()
      .prepare(
        `SELECT p.*, c.name AS category_name FROM plans p JOIN categories c ON c.id = p.category_id
         ${categoryId ? 'WHERE p.category_id = @cid' : ''} ORDER BY c.display_order, c.id, p.display_order, p.id`
      )
      .all(categoryId ? { cid: categoryId } : {});
    return rows.map(hydratePlan);
  },
  byId(id, onlyActive = false) {
    const row = getDb()
      .prepare(
        `SELECT p.*, c.name AS category_name, c.slug AS category_slug FROM plans p JOIN categories c ON c.id = p.category_id
         WHERE p.id = ? ${onlyActive ? 'AND p.status = 1 AND c.status = 1' : ''}`
      )
      .get(id);
    return hydratePlan(row);
  },
  insert(d) {
    return getDb()
      .prepare(
        `INSERT INTO plans (category_id, name, description, price, currency, billing_period, cpu, ram, storage, bandwidth, network_speed, locations, features, badge, color, order_url, status, display_order)
         VALUES (@category_id, @name, @description, @price, @currency, @billing_period, @cpu, @ram, @storage, @bandwidth, @network_speed, @locations, @features, @badge, @color, @order_url, @status, @display_order)`
      )
      .run(d).lastInsertRowid;
  },
  update(id, d) {
    getDb()
      .prepare(
        `UPDATE plans SET category_id=@category_id, name=@name, description=@description, price=@price, currency=@currency, billing_period=@billing_period,
         cpu=@cpu, ram=@ram, storage=@storage, bandwidth=@bandwidth, network_speed=@network_speed, locations=@locations, features=@features,
         badge=@badge, color=@color, order_url=@order_url, status=@status, updated_at=datetime('now') WHERE id=@id`
      )
      .run({ ...d, id });
  },
  toggle(id) {
    getDb().prepare("UPDATE plans SET status = 1 - status, updated_at = datetime('now') WHERE id = ?").run(id);
  },
  remove(id) {
    getDb().prepare('DELETE FROM plans WHERE id = ?').run(id);
  }
};

/* --------------------------------- social ------------------------------- */
const socials = {
  listAll() {
    return getDb().prepare('SELECT * FROM social_links ORDER BY display_order, id').all();
  },
  listActive() {
    return getDb().prepare('SELECT * FROM social_links WHERE status = 1 ORDER BY display_order, id').all();
  },
  byId(id) {
    return getDb().prepare('SELECT * FROM social_links WHERE id = ?').get(id);
  },
  insert(d) {
    return getDb()
      .prepare('INSERT INTO social_links (platform, display_name, url, icon, status, display_order) VALUES (@platform, @display_name, @url, @icon, @status, @display_order)')
      .run(d).lastInsertRowid;
  },
  update(id, d) {
    getDb()
      .prepare('UPDATE social_links SET platform=@platform, display_name=@display_name, url=@url, icon=@icon, status=@status WHERE id=@id')
      .run({ ...d, id });
  },
  remove(id) {
    getDb().prepare('DELETE FROM social_links WHERE id = ?').run(id);
  }
};

/* ---------------------------------- team -------------------------------- */
function hydrateMember(m) {
  return m ? { ...m, social_links: parseJson(m.social_links, []) } : m;
}
const team = {
  listActive() {
    return getDb().prepare('SELECT * FROM team_members WHERE status = 1 ORDER BY display_order, id').all().map(hydrateMember);
  },
  listAll() {
    return getDb().prepare('SELECT * FROM team_members ORDER BY display_order, id').all().map(hydrateMember);
  },
  byId(id) {
    return hydrateMember(getDb().prepare('SELECT * FROM team_members WHERE id = ?').get(id));
  },
  insert(d) {
    return getDb()
      .prepare(
        'INSERT INTO team_members (user_id, application_id, name, username, avatar, role, bio, social_links, status, display_order) VALUES (@user_id, @application_id, @name, @username, @avatar, @role, @bio, @social_links, @status, @display_order)'
      )
      .run(d).lastInsertRowid;
  },
  update(id, d) {
    getDb()
      .prepare('UPDATE team_members SET name=@name, username=@username, avatar=@avatar, role=@role, bio=@bio, social_links=@social_links, status=@status WHERE id=@id')
      .run({ ...d, id });
  },
  remove(id) {
    getDb().prepare('DELETE FROM team_members WHERE id = ?').run(id);
  }
};

module.exports = { categories, plans, socials, team, move, nextOrder, hydratePlan };
