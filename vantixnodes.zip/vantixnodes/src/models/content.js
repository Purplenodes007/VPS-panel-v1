'use strict';

const { getDb } = require('../database/connection');

/* ---------------------------------- posts ------------------------------- */
const posts = {
  listPublished({ category, limit = 9, offset = 0 } = {}) {
    const where = ['p.published = 1'];
    const params = { limit, offset };
    if (category) {
      where.push('p.category = @category');
      params.category = category;
    }
    return getDb()
      .prepare(
        `SELECT p.id, p.title, p.slug, p.description, p.thumbnail, p.category, p.created_at, p.updated_at,
                COALESCE(u.global_name, u.username) AS author_name
         FROM posts p LEFT JOIN users u ON u.id = p.author_id
         WHERE ${where.join(' AND ')} ORDER BY p.created_at DESC, p.id DESC LIMIT @limit OFFSET @offset`
      )
      .all(params);
  },
  countPublished(category) {
    if (category) return getDb().prepare('SELECT COUNT(*) AS n FROM posts WHERE published = 1 AND category = ?').get(category).n;
    return getDb().prepare('SELECT COUNT(*) AS n FROM posts WHERE published = 1').get().n;
  },
  bySlug(slug, onlyPublished = true) {
    return getDb()
      .prepare(
        `SELECT p.*, COALESCE(u.global_name, u.username) AS author_name FROM posts p LEFT JOIN users u ON u.id = p.author_id
         WHERE p.slug = ? ${onlyPublished ? 'AND p.published = 1' : ''}`
      )
      .get(slug);
  },
  byId(id) {
    return getDb().prepare('SELECT * FROM posts WHERE id = ?').get(id);
  },
  listAll({ limit = 20, offset = 0 } = {}) {
    return getDb()
      .prepare('SELECT p.*, COALESCE(u.global_name, u.username) AS author_name FROM posts p LEFT JOIN users u ON u.id = p.author_id ORDER BY p.created_at DESC, p.id DESC LIMIT ? OFFSET ?')
      .all(limit, offset);
  },
  countAll() {
    return getDb().prepare('SELECT COUNT(*) AS n FROM posts').get().n;
  },
  insert(d) {
    return getDb()
      .prepare('INSERT INTO posts (title, slug, description, content, thumbnail, author_id, category, published) VALUES (@title, @slug, @description, @content, @thumbnail, @author_id, @category, @published)')
      .run(d).lastInsertRowid;
  },
  update(id, d) {
    getDb()
      .prepare("UPDATE posts SET title=@title, slug=@slug, description=@description, content=@content, thumbnail=@thumbnail, category=@category, published=@published, updated_at=datetime('now') WHERE id=@id")
      .run({ ...d, id });
  },
  setPublished(id, value) {
    getDb().prepare("UPDATE posts SET published = ?, updated_at = datetime('now') WHERE id = ?").run(value ? 1 : 0, id);
  },
  remove(id) {
    getDb().prepare('DELETE FROM posts WHERE id = ?').run(id);
  }
};

/* -------------------------------- tickets ------------------------------- */
const tickets = {
  categories(onlyActive = true) {
    return getDb().prepare(`SELECT * FROM ticket_categories ${onlyActive ? 'WHERE status = 1' : ''} ORDER BY display_order, id`).all();
  },
  create({ userId, subject, category, priority, message }) {
    const db = getDb();
    const tx = db.transaction(() => {
      const id = db.prepare('INSERT INTO tickets (user_id, subject, category, priority) VALUES (?, ?, ?, ?)').run(userId, subject, category, priority).lastInsertRowid;
      db.prepare('INSERT INTO ticket_messages (ticket_id, user_id, is_staff, message) VALUES (?, ?, 0, ?)').run(id, userId, message);
      return id;
    });
    return tx();
  },
  listForUser(userId) {
    return getDb().prepare('SELECT * FROM tickets WHERE user_id = ? ORDER BY updated_at DESC, id DESC').all(userId);
  },
  byId(id) {
    return getDb()
      .prepare('SELECT t.*, COALESCE(u.global_name, u.username) AS user_name, u.discord_id, u.avatar FROM tickets t JOIN users u ON u.id = t.user_id WHERE t.id = ?')
      .get(id);
  },
  messages(ticketId) {
    return getDb()
      .prepare(
        `SELECT m.*, COALESCE(u.global_name, u.username, 'Deleted user') AS author_name FROM ticket_messages m
         LEFT JOIN users u ON u.id = m.user_id WHERE m.ticket_id = ? ORDER BY m.created_at, m.id`
      )
      .all(ticketId);
  },
  addMessage({ ticketId, userId, isStaff, message, status }) {
    const db = getDb();
    const tx = db.transaction(() => {
      db.prepare('INSERT INTO ticket_messages (ticket_id, user_id, is_staff, message) VALUES (?, ?, ?, ?)').run(ticketId, userId, isStaff ? 1 : 0, message);
      db.prepare("UPDATE tickets SET status = ?, updated_at = datetime('now') WHERE id = ?").run(status, ticketId);
    });
    tx();
  },
  setStatus(id, status) {
    getDb().prepare("UPDATE tickets SET status = ?, updated_at = datetime('now') WHERE id = ?").run(status, id);
  },
  listAdmin({ status, limit = 20, offset = 0 }) {
    const params = { limit, offset };
    let where = '';
    if (status) {
      where = 'WHERE t.status = @status';
      params.status = status;
    }
    return getDb()
      .prepare(
        `SELECT t.*, COALESCE(u.global_name, u.username) AS user_name FROM tickets t JOIN users u ON u.id = t.user_id
         ${where} ORDER BY CASE t.status WHEN 'open' THEN 0 WHEN 'pending' THEN 1 ELSE 2 END, t.updated_at DESC LIMIT @limit OFFSET @offset`
      )
      .all(params);
  },
  countAdmin(status) {
    if (status) return getDb().prepare('SELECT COUNT(*) AS n FROM tickets WHERE status = ?').get(status).n;
    return getDb().prepare('SELECT COUNT(*) AS n FROM tickets').get().n;
  }
};

/* ------------------------------ applications ---------------------------- */
const applications = {
  questions(onlyActive = true) {
    return getDb().prepare(`SELECT * FROM application_questions ${onlyActive ? 'WHERE status = 1' : ''} ORDER BY display_order, id`).all();
  },
  questionById(id) {
    return getDb().prepare('SELECT * FROM application_questions WHERE id = ?').get(id);
  },
  listForUser(userId) {
    return getDb().prepare('SELECT * FROM applications WHERE user_id = ? ORDER BY created_at DESC').all(userId);
  },
  hasActive(userId) {
    return !!getDb().prepare("SELECT 1 FROM applications WHERE user_id = ? AND status IN ('pending','under_review')").get(userId);
  },
  submit({ userId, position, answers }) {
    const db = getDb();
    const tx = db.transaction(() => {
      const id = db.prepare('INSERT INTO applications (user_id, position) VALUES (?, ?)').run(userId, position).lastInsertRowid;
      const ins = db.prepare('INSERT INTO application_answers (application_id, question_id, question_label, answer) VALUES (?, ?, ?, ?)');
      for (const a of answers) ins.run(id, a.question_id, a.label, a.answer);
      return id;
    });
    return tx();
  },
  listAdmin({ status, limit = 20, offset = 0 }) {
    const params = { limit, offset };
    let where = '';
    if (status) {
      where = 'WHERE a.status = @status';
      params.status = status;
    }
    return getDb()
      .prepare(
        `SELECT a.*, COALESCE(u.global_name, u.username) AS applicant_name, u.username AS applicant_username
         FROM applications a JOIN users u ON u.id = a.user_id ${where}
         ORDER BY a.created_at DESC, a.id DESC LIMIT @limit OFFSET @offset`
      )
      .all(params);
  },
  countAdmin(status) {
    if (status) return getDb().prepare('SELECT COUNT(*) AS n FROM applications WHERE status = ?').get(status).n;
    return getDb().prepare('SELECT COUNT(*) AS n FROM applications').get().n;
  },
  byId(id) {
    return getDb()
      .prepare(
        `SELECT a.*, u.id AS applicant_id, u.username AS applicant_username, COALESCE(u.global_name, u.username) AS applicant_name,
                u.discord_id, u.avatar, u.email
         FROM applications a JOIN users u ON u.id = a.user_id WHERE a.id = ?`
      )
      .get(id);
  },
  answers(applicationId) {
    return getDb().prepare('SELECT * FROM application_answers WHERE application_id = ? ORDER BY id').all(applicationId);
  },
  review({ id, status, note, reviewerId }) {
    getDb()
      .prepare("UPDATE applications SET status = ?, internal_note = ?, reviewed_by = ?, updated_at = datetime('now') WHERE id = ?")
      .run(status, note, reviewerId, id);
  },
  remove(id) {
    getDb().prepare('DELETE FROM applications WHERE id = ?').run(id);
  }
};

/* ---------------------------------- users ------------------------------- */
const users = {
  list({ q, role, limit = 25, offset = 0 }) {
    const where = [];
    const params = { limit, offset };
    if (q) {
      where.push('(username LIKE @q OR global_name LIKE @q OR discord_id LIKE @q OR email LIKE @q)');
      params.q = `%${q.replace(/[%_]/g, '')}%`;
    }
    if (role) {
      where.push('role = @role');
      params.role = role;
    }
    const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
    return getDb().prepare(`SELECT * FROM users ${w} ORDER BY created_at DESC, id DESC LIMIT @limit OFFSET @offset`).all(params);
  },
  count({ q, role }) {
    const where = [];
    const params = {};
    if (q) {
      where.push('(username LIKE @q OR global_name LIKE @q OR discord_id LIKE @q OR email LIKE @q)');
      params.q = `%${q.replace(/[%_]/g, '')}%`;
    }
    if (role) {
      where.push('role = @role');
      params.role = role;
    }
    const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
    return getDb().prepare(`SELECT COUNT(*) AS n FROM users ${w}`).get(params).n;
  },
  byId(id) {
    return getDb().prepare('SELECT * FROM users WHERE id = ?').get(id);
  },
  setRole(id, role) {
    getDb().prepare('UPDATE users SET role = ? WHERE id = ?').run(role, id);
  },
  setBanned(id, banned) {
    getDb().prepare('UPDATE users SET is_banned = ? WHERE id = ?').run(banned ? 1 : 0, id);
    if (banned) getDb().prepare("DELETE FROM sessions WHERE json_extract(data, '$.userId') = ?").run(id);
  }
};

module.exports = { posts, tickets, applications, users };
