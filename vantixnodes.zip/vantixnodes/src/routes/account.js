'use strict';

const router = require('express').Router();
const ctrl = require('../controllers/accountController');
const { requireAuth } = require('../middleware/auth');
const { limiters } = require('../middleware/security');

router.use(requireAuth);

router.get('/', ctrl.dashboard);
router.post('/notifications/read', ctrl.markNotificationsRead);

router.get('/applications', ctrl.myApplications);
router.get('/applications/:id(\\d+)', ctrl.myApplicationDetail);

router.get('/tickets', ctrl.ticketsList);
router.get('/tickets/new', ctrl.ticketNew);
router.post('/tickets', limiters.tickets, ctrl.ticketCreate);
router.get('/tickets/:id(\\d+)', ctrl.ticketView);
router.post('/tickets/:id(\\d+)/reply', limiters.tickets, ctrl.ticketReply);
router.post('/tickets/:id(\\d+)/close', ctrl.ticketClose);

module.exports = router;
