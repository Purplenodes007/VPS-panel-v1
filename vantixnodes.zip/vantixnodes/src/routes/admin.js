'use strict';

const router = require('express').Router();
const { requirePermission, requireSuperadmin } = require('../middleware/auth');
const { limiters } = require('../middleware/security');
const settingsAdmin = require('../controllers/admin/settingsAdmin');
const { categories, plans, socials, team, status } = require('../controllers/admin/catalogAdmin');
const { posts, applications, questions, tickets, contact } = require('../controllers/admin/contentAdmin');
const system = require('../controllers/admin/systemAdmin');
const { handleUpload } = require('../services/uploadService');

const p = requirePermission;

// Every admin route requires a signed-in staff user (checked again per section below).
router.use(p(null));

router.get('/', p('overview'), system.dashboard);

// Uploads (any staff member; files validated by content, size and type)
router.post('/upload', limiters.upload, handleUpload);

// Website settings / theme / background
router.get('/settings', p('settings'), settingsAdmin.settingsPage);
router.post('/settings/:section', p('settings'), settingsAdmin.saveSettings);
router.get('/theme', p('theme'), settingsAdmin.themePage);
router.post('/theme', p('theme'), settingsAdmin.saveTheme);
router.get('/background', p('background'), settingsAdmin.backgroundPage);
router.post('/background', p('background'), settingsAdmin.saveBackground);

// Categories
router.get('/categories', p('categories'), categories.list);
router.get('/categories/new', p('categories'), categories.newForm);
router.post('/categories', p('categories'), categories.create);
router.get('/categories/:id(\\d+)/edit', p('categories'), categories.editForm);
router.post('/categories/:id(\\d+)', p('categories'), categories.update);
router.post('/categories/:id(\\d+)/delete', p('categories'), categories.remove);
router.post('/categories/:id(\\d+)/move', p('categories'), categories.move);

// Plans
router.get('/plans', p('plans'), plans.list);
router.get('/plans/new', p('plans'), plans.newForm);
router.post('/plans', p('plans'), plans.create);
router.get('/plans/:id(\\d+)/edit', p('plans'), plans.editForm);
router.post('/plans/:id(\\d+)', p('plans'), plans.update);
router.post('/plans/:id(\\d+)/toggle', p('plans'), plans.toggle);
router.post('/plans/:id(\\d+)/delete', p('plans'), plans.remove);
router.post('/plans/:id(\\d+)/move', p('plans'), plans.move);

// Staff applications + questions
router.get('/applications', p('applications'), applications.list);
router.post('/applications/settings', p('applications'), applications.saveSettings);
router.get('/applications/questions', p('applications'), questions.page);
router.post('/applications/questions', p('applications'), questions.create);
router.get('/applications/questions/:id(\\d+)', p('applications'), questions.page);
router.post('/applications/questions/:id(\\d+)', p('applications'), questions.update);
router.post('/applications/questions/:id(\\d+)/delete', p('applications'), questions.remove);
router.post('/applications/questions/:id(\\d+)/move', p('applications'), questions.move);
router.get('/applications/:id(\\d+)', p('applications'), applications.detail);
router.post('/applications/:id(\\d+)/review', p('applications'), applications.review);
router.post('/applications/:id(\\d+)/delete', p('applications'), applications.remove);

// Team
router.get('/team', p('team'), team.list);
router.get('/team/new', p('team'), team.newForm);
router.post('/team', p('team'), team.create);
router.get('/team/:id(\\d+)/edit', p('team'), team.editForm);
router.post('/team/:id(\\d+)', p('team'), team.update);
router.post('/team/:id(\\d+)/delete', p('team'), team.remove);
router.post('/team/:id(\\d+)/move', p('team'), team.move);

// Posts
router.get('/posts', p('posts'), posts.list);
router.get('/posts/new', p('posts'), posts.newForm);
router.post('/posts', p('posts'), posts.create);
router.get('/posts/:id(\\d+)/edit', p('posts'), posts.editForm);
router.post('/posts/:id(\\d+)', p('posts'), posts.update);
router.post('/posts/:id(\\d+)/publish', p('posts'), posts.publish);
router.post('/posts/:id(\\d+)/delete', p('posts'), posts.remove);

// Social links
router.get('/socials', p('socials'), socials.list);
router.post('/socials', p('socials'), socials.create);
router.get('/socials/:id(\\d+)', p('socials'), socials.edit);
router.post('/socials/:id(\\d+)', p('socials'), socials.update);
router.post('/socials/:id(\\d+)/delete', p('socials'), socials.remove);
router.post('/socials/:id(\\d+)/move', p('socials'), socials.move);

// Status & statistics
router.get('/status', p('status'), status.page);
router.post('/status', p('status'), status.updateServices);
router.post('/status/services', p('status'), status.addService);
router.post('/status/stats', p('status'), status.saveStats);
router.post('/status/:id(\\d+)/delete', p('status'), status.removeService);
router.post('/status/:id(\\d+)/move', p('status'), status.move);

// Tickets
router.get('/tickets', p('tickets'), tickets.list);
router.get('/tickets/categories', p('tickets'), tickets.categories);
router.post('/tickets/categories', p('tickets'), tickets.addCategory);
router.post('/tickets/categories/:id(\\d+)/toggle', p('tickets'), tickets.toggleCategory);
router.post('/tickets/categories/:id(\\d+)/delete', p('tickets'), tickets.removeCategory);
router.post('/tickets/categories/:id(\\d+)/move', p('tickets'), tickets.moveCategory);
router.get('/tickets/:id(\\d+)', p('tickets'), tickets.detail);
router.post('/tickets/:id(\\d+)/reply', p('tickets'), limiters.tickets, tickets.reply);
router.post('/tickets/:id(\\d+)/status', p('tickets'), tickets.setStatus);

// Contact messages
router.get('/contact', p('contact'), contact.list);
router.post('/contact/:id(\\d+)/read', p('contact'), contact.toggleRead);
router.post('/contact/:id(\\d+)/delete', p('contact'), contact.remove);

// Users
router.get('/users', p('users'), system.usersList);
router.get('/users/:id(\\d+)', p('users'), system.userDetail);
router.post('/users/:id(\\d+)/role', p('users'), system.setUserRole);
router.post('/users/:id(\\d+)/ban', p('users'), system.setUserBan);

// Audit log
router.get('/audit', p('audit'), system.auditPage);

// Security, role permissions and backups: superadmin only
router.get('/security', requireSuperadmin, system.securityPage);
router.post('/security/roles/:role', requireSuperadmin, system.saveRolePermissions);
router.post('/security/password', requireSuperadmin, system.changePassword);
router.post('/security/sessions/purge', requireSuperadmin, system.purgeSessions);
router.post('/security/backups', requireSuperadmin, system.createBackup);
router.get('/security/backups/:name', requireSuperadmin, system.downloadBackup);
router.post('/security/backups/:name/delete', requireSuperadmin, system.deleteBackup);

module.exports = router;
