'use strict';

const router = require('express').Router();
const ctrl = require('../controllers/apiController');
const { requirePermission } = require('../middleware/auth');

// Public, read-only endpoints
router.get('/categories', ctrl.categories);
router.get('/categories/:slug', ctrl.categoryBySlug);
router.get('/plans', ctrl.plans);
router.get('/plans/:id(\\d+)', ctrl.planById);
router.get('/posts', ctrl.posts);
router.get('/posts/:slug', ctrl.postBySlug);
router.get('/team', ctrl.team);
router.get('/status', ctrl.statusApi);
router.get('/socials', ctrl.socials);

// Admin endpoints: authentication + role permission required (CSRF header for writes)
router.get('/admin/stats', requirePermission('overview'), ctrl.adminStats);
router.get('/admin/audit', requirePermission('audit'), ctrl.adminAudit);
router.patch('/admin/status/:slug', requirePermission('status'), ctrl.adminSetStatus);

module.exports = router;
