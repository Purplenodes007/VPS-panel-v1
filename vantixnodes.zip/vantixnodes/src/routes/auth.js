'use strict';

const router = require('express').Router();
const ctrl = require('../controllers/authController');
const { limiters } = require('../middleware/security');
const { requireAuth } = require('../middleware/auth');

router.get('/login', ctrl.loginPage);
router.get('/discord', limiters.auth, ctrl.discordStart);
router.get('/discord/callback', limiters.auth, ctrl.discordCallback);
router.post('/logout', requireAuth, ctrl.logout);

router.get('/admin', ctrl.adminLoginPage);
router.post('/admin', limiters.adminLogin, ctrl.adminLogin);

module.exports = router;
