'use strict';

const router = require('express').Router();
const ctrl = require('../controllers/publicController');
const authCtrl = require('../controllers/authController');
const account = require('../controllers/accountController');
const { limiters } = require('../middleware/security');
const { requireAuth } = require('../middleware/auth');

router.get('/', ctrl.home);
router.get('/plans', ctrl.plansPage);
router.get('/category/:slug', ctrl.categoryPage);
router.get('/posts', ctrl.postsList);
router.get('/posts/:slug', ctrl.postDetail);
router.get('/team', ctrl.teamPage);
router.get('/status', ctrl.statusPage);
router.get('/contact', ctrl.contactPage);
router.post('/contact', limiters.contact, ctrl.contactSubmit);

router.get('/apply', requireAuth, account.applyPage);
router.post('/apply', requireAuth, limiters.applications, account.applySubmit);

router.get('/setup', limiters.adminLogin, authCtrl.setupPage);
router.post('/setup', limiters.adminLogin, authCtrl.setupSubmit);

router.get('/robots.txt', ctrl.robots);
router.get('/sitemap.xml', ctrl.sitemap);

module.exports = router;
