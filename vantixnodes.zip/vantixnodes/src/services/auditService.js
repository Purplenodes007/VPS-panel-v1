'use strict';

const { getDb } = require('../database/connection');
const { getIp } = require('../utils/helpers');

/** Records an administrative action. Never throws. */
function log(req, action, target = '', details = '') {
  try {
    const user = req && req.user;
    getDb()
      .prepare('INSERT INTO audit_logs (admin_id, admin_name, action, target, details, ip) VALUES (?, ?, ?, ?, ?, ?)')
      .run(
        user ? user.id : null,
        user ? user.global_name || user.username : 'system',
        String(action).slice(0, 200),
        String(target).slice(0, 200),
        String(details).slice(0, 1000),
        req ? getIp(req) : ''
      );
  } catch (e) {
    console.error('audit log failed:', e.message);
  }
}

/** Records a user-visible account activity entry. */
function userActivity(userId, action, ip = '') {
  try {
    getDb().prepare('INSERT INTO user_activity (user_id, action, ip) VALUES (?, ?, ?)').run(userId, String(action).slice(0, 200), ip);
  } catch (e) {
    console.error('activity log failed:', e.message);
  }
}

function notify(userId, title, body = '', link = '') {
  try {
    getDb()
      .prepare('INSERT INTO notifications (user_id, title, body, link) VALUES (?, ?, ?, ?)')
      .run(userId, String(title).slice(0, 200), String(body).slice(0, 1000), String(link).slice(0, 300));
  } catch (e) {
    console.error('notification failed:', e.message);
  }
}

module.exports = { log, userActivity, notify };
