'use strict';

const fs = require('fs');
const path = require('path');
const config = require('../config');
const { getDb } = require('../database/connection');

fs.mkdirSync(config.backupDir, { recursive: true });

const NAME_RE = /^backup-\d{8}-\d{6}-[a-f0-9]{6}\.sqlite$/;

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getUTCFullYear()}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}-${p(d.getUTCHours())}${p(d.getUTCMinutes())}${p(d.getUTCSeconds())}`;
}

/** Creates a consistent online snapshot using SQLite's backup API. */
async function createBackup() {
  const name = `backup-${stamp()}-${require('crypto').randomBytes(3).toString('hex')}.sqlite`;
  const dest = path.join(config.backupDir, name);
  await getDb().backup(dest);
  const st = fs.statSync(dest);
  return { name, size: st.size, created: st.mtime };
}

function listBackups() {
  return fs
    .readdirSync(config.backupDir)
    .filter((n) => NAME_RE.test(n))
    .map((n) => {
      const st = fs.statSync(path.join(config.backupDir, n));
      return { name: n, size: st.size, created: st.mtime };
    })
    .sort((a, b) => b.created - a.created);
}

/** Resolves a backup filename to a path, only if it matches the strict pattern. */
function backupPath(name) {
  if (!NAME_RE.test(String(name || ''))) return null;
  const full = path.join(config.backupDir, name);
  return fs.existsSync(full) ? full : null;
}

function deleteBackup(name) {
  const full = backupPath(name);
  if (!full) return false;
  fs.unlinkSync(full);
  return true;
}

module.exports = { createBackup, listBackups, backupPath, deleteBackup };
