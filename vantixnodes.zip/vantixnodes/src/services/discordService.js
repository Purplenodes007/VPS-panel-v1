'use strict';

const config = require('../config');
const { getDb } = require('../database/connection');

const AUTHORIZE_URL = 'https://discord.com/oauth2/authorize';
const TOKEN_URL = 'https://discord.com/api/oauth2/token';
const USER_URL = 'https://discord.com/api/users/@me';

function isConfigured() {
  const d = config.discord;
  return !!(d.clientId && d.clientSecret && d.callbackUrl);
}

function buildAuthorizeUrl(state) {
  const params = new URLSearchParams({
    client_id: config.discord.clientId,
    redirect_uri: config.discord.callbackUrl,
    response_type: 'code',
    scope: 'identify email',
    state,
    prompt: 'none'
  });
  return `${AUTHORIZE_URL}?${params.toString()}`;
}

async function fetchJson(url, options) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);
  try {
    const res = await fetch(url, { ...options, signal: controller.signal });
    const text = await res.text();
    let data = null;
    try {
      data = JSON.parse(text);
    } catch (e) {
      /* non-json */
    }
    if (!res.ok) {
      const err = new Error(`Discord request failed (${res.status})`);
      err.status = res.status;
      throw err;
    }
    return data;
  } finally {
    clearTimeout(timer);
  }
}

/** Exchanges an OAuth code for the Discord user profile. */
async function fetchProfile(code) {
  const body = new URLSearchParams({
    client_id: config.discord.clientId,
    client_secret: config.discord.clientSecret,
    grant_type: 'authorization_code',
    code,
    redirect_uri: config.discord.callbackUrl
  });
  const token = await fetchJson(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
    body
  });
  if (!token || !token.access_token) throw new Error('No access token returned by Discord');
  const profile = await fetchJson(USER_URL, {
    headers: { Authorization: `Bearer ${token.access_token}`, Accept: 'application/json' }
  });
  if (!profile || !profile.id) throw new Error('Invalid Discord profile');
  // The access token is used once and deliberately never stored.
  return profile;
}

/** Creates or updates the local user for a Discord profile. */
function upsertUser(profile) {
  const db = getDb();
  const existing = db.prepare('SELECT * FROM users WHERE discord_id = ?').get(profile.id);
  const username = String(profile.username || 'user').slice(0, 64);
  const globalName = profile.global_name ? String(profile.global_name).slice(0, 64) : null;
  const email = profile.email ? String(profile.email).slice(0, 254) : null;
  const avatar = profile.avatar ? String(profile.avatar).slice(0, 64) : null;

  if (existing) {
    db.prepare("UPDATE users SET username = ?, global_name = ?, avatar = ?, email = COALESCE(?, email), last_login = datetime('now') WHERE id = ?").run(
      username,
      globalName,
      avatar,
      email,
      existing.id
    );
    return db.prepare('SELECT * FROM users WHERE id = ?').get(existing.id);
  }

  const info = db
    .prepare("INSERT INTO users (discord_id, username, global_name, avatar, email, last_login) VALUES (?, ?, ?, ?, ?, datetime('now'))")
    .run(profile.id, username, globalName, avatar, email);
  return db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
}

module.exports = { isConfigured, buildAuthorizeUrl, fetchProfile, upsertUser };
