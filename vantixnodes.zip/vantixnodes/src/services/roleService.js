'use strict';

const { getDb } = require('../database/connection');
const { parseJson } = require('../utils/helpers');
const { PERMISSIONS } = require('../config/constants');

let cache = null;

function load() {
  cache = {};
  for (const r of getDb().prepare('SELECT name, label, permissions FROM roles').all()) {
    cache[r.name] = { name: r.name, label: r.label, permissions: parseJson(r.permissions, []) };
  }
  return cache;
}

function roles() {
  return cache || load();
}

function permissionsFor(roleName) {
  const r = roles()[roleName];
  return r ? r.permissions : [];
}

function can(roleName, permission) {
  const perms = permissionsFor(roleName);
  return perms.includes('*') || perms.includes(permission);
}

function isStaff(roleName) {
  return permissionsFor(roleName).length > 0;
}

function setPermissions(roleName, permissions) {
  if (roleName === 'superadmin' || roleName === 'user') return false;
  const valid = new Set(PERMISSIONS.map((p) => p.key));
  const clean = permissions.filter((p) => valid.has(p));
  getDb().prepare('UPDATE roles SET permissions = ? WHERE name = ?').run(JSON.stringify(clean), roleName);
  load();
  return true;
}

module.exports = { roles, permissionsFor, can, isStaff, setPermissions, reload: load };
