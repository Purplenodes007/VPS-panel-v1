'use strict';

const session = require('express-session');
const { getDb } = require('../database/connection');

/** SQLite-backed express-session store (table: sessions). */
class SqliteStore extends session.Store {
  constructor(options = {}) {
    super();
    this.ttlMs = options.ttlMs || 1000 * 60 * 60 * 24 * 7;
    const db = getDb();
    this.getStmt = db.prepare('SELECT data, expires_at FROM sessions WHERE sid = ?');
    this.setStmt = db.prepare(
      'INSERT INTO sessions (sid, data, expires_at) VALUES (?, ?, ?) ON CONFLICT(sid) DO UPDATE SET data = excluded.data, expires_at = excluded.expires_at'
    );
    this.delStmt = db.prepare('DELETE FROM sessions WHERE sid = ?');
    this.touchStmt = db.prepare('UPDATE sessions SET expires_at = ? WHERE sid = ?');
    this.cleanStmt = db.prepare('DELETE FROM sessions WHERE expires_at < ?');
    this.cleanup();
    this.timer = setInterval(() => this.cleanup(), 1000 * 60 * 15);
    this.timer.unref();
  }

  cleanup() {
    try {
      this.cleanStmt.run(Date.now());
    } catch (e) {
      /* ignore */
    }
  }

  expiry(sess) {
    if (sess && sess.cookie && sess.cookie.expires) return new Date(sess.cookie.expires).getTime();
    return Date.now() + this.ttlMs;
  }

  get(sid, cb) {
    try {
      const row = this.getStmt.get(sid);
      if (!row) return cb(null, null);
      if (row.expires_at < Date.now()) {
        this.delStmt.run(sid);
        return cb(null, null);
      }
      return cb(null, JSON.parse(row.data));
    } catch (e) {
      return cb(e);
    }
  }

  set(sid, sess, cb) {
    try {
      this.setStmt.run(sid, JSON.stringify(sess), this.expiry(sess));
      cb && cb(null);
    } catch (e) {
      cb && cb(e);
    }
  }

  destroy(sid, cb) {
    try {
      this.delStmt.run(sid);
      cb && cb(null);
    } catch (e) {
      cb && cb(e);
    }
  }

  touch(sid, sess, cb) {
    try {
      this.touchStmt.run(this.expiry(sess), sid);
      cb && cb(null);
    } catch (e) {
      cb && cb(e);
    }
  }
}

module.exports = SqliteStore;
