'use strict';

const { getDb } = require('../database/connection');
const { FONTS } = require('../config/constants');

let cache = null;

function load() {
  const rows = getDb().prepare('SELECT key, value FROM settings').all();
  cache = {};
  for (const r of rows) cache[r.key] = r.value;
  return cache;
}

function all() {
  return cache || load();
}

function get(key, fallback = '') {
  const v = all()[key];
  return v === undefined ? fallback : v;
}

function setMany(obj) {
  const db = getDb();
  const stmt = db.prepare(
    "INSERT INTO settings (key, value, updated_at) VALUES (?, ?, datetime('now')) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at"
  );
  const tx = db.transaction((entries) => {
    for (const [k, v] of entries) stmt.run(k, String(v === undefined || v === null ? '' : v));
  });
  tx(Object.entries(obj));
  load();
}

/** Public subset of settings that is safe to expose to templates / API. */
function publicSettings() {
  const s = all();
  const hidden = new Set(['setup_token_hash']);
  const out = {};
  for (const [k, v] of Object.entries(s)) if (!hidden.has(k)) out[k] = v;
  return out;
}

function hex(v, fallback) {
  return /^#[0-9a-fA-F]{6}$/.test(v) ? v : fallback;
}

/** CSS custom properties generated from validated settings. */
function themeCss() {
  const s = all();
  const radius = Math.min(32, Math.max(0, parseInt(s.border_radius, 10) || 16));
  const font = FONTS[s.font] !== undefined ? s.font : 'Inter';
  const fontStack = font === 'System' ? 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' : `"${font}", system-ui, -apple-system, "Segoe UI", sans-serif`;
  return `:root{--primary:${hex(s.color_primary, '#6366f1')};--secondary:${hex(s.color_secondary, '#22d3ee')};--accent:${hex(s.color_accent, '#a855f7')};--background:${hex(s.color_background, '#07090f')};--surface:${hex(s.color_surface, '#0e1220')};--text:${hex(s.color_text, '#e8ecf6')};--muted:${hex(s.color_muted, '#8b94ad')};--border:${hex(s.color_border, '#1f2740')};--radius:${radius}px;--font:${fontStack};}`;
}

function fontHref() {
  const font = FONTS[get('font', 'Inter')];
  if (!font) return '';
  return `https://fonts.googleapis.com/css2?family=${font}&display=swap`;
}

/** Computed background configuration for the layout. */
function background() {
  const s = all();
  const type = ['none', 'color', 'gradient', 'image', 'video'].includes(s.bg_type) ? s.bg_type : 'none';
  const overlay = Math.min(100, Math.max(0, parseInt(s.bg_overlay, 10) || 0));
  const videoOpacity = Math.min(100, Math.max(0, parseInt(s.bg_video_opacity, 10) || 60));
  const angle = Math.min(360, Math.max(0, parseInt(s.bg_gradient_angle, 10) || 160));
  let style = '';
  if (type === 'color') style = `background:${hex(s.bg_color, '#07090f')};`;
  if (type === 'gradient') style = `background:linear-gradient(${angle}deg, ${hex(s.bg_gradient_from, '#07090f')}, ${hex(s.bg_gradient_to, '#141a33')});`;
  return {
    type,
    style,
    imageUrl: type === 'image' ? s.bg_image_url : '',
    videoUrl: type === 'video' ? s.bg_video_url : '',
    overlay: overlay / 100,
    videoOpacity: videoOpacity / 100
  };
}

module.exports = { all, get, setMany, publicSettings, themeCss, fontHref, background, reload: load };
