'use strict';

const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { getDb } = require('../database/connection');

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

/** Creates a fresh one-time setup token and stores only its hash. */
function createSetupToken() {
  const db = getDb();
  const token = crypto.randomBytes(24).toString('hex');
  db.prepare("INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES ('setup_token_hash', ?, datetime('now'))").run(
    sha256(token)
  );
  return token;
}

function adminExists() {
  return !!getDb().prepare("SELECT 1 FROM users WHERE role IN ('admin','superadmin') LIMIT 1").get();
}

function verifySetupToken(token) {
  if (!token || typeof token !== 'string') return false;
  if (adminExists()) return false;
  const row = getDb().prepare("SELECT value FROM settings WHERE key = 'setup_token_hash'").get();
  if (!row || !row.value) return false;
  const a = Buffer.from(sha256(token));
  const b = Buffer.from(row.value);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/** Creates the first superadmin with a local password login. */
function createInitialAdmin({ username, password }) {
  const db = getDb();
  const hash = bcrypt.hashSync(password, 12);
  const tx = db.transaction(() => {
    if (adminExists()) throw new Error('An administrator already exists.');
    const info = db
      .prepare(
        "INSERT INTO users (username, global_name, local_username, password_hash, role, last_login) VALUES (?, ?, ?, ?, 'superadmin', datetime('now'))"
      )
      .run(username, username, username.toLowerCase(), hash);
    db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('setup_complete', '1')").run();
    db.prepare("UPDATE settings SET value = '' WHERE key = 'setup_token_hash'").run();
    return info.lastInsertRowid;
  });
  return tx();
}

module.exports = { createSetupToken, verifySetupToken, createInitialAdmin, adminExists };
