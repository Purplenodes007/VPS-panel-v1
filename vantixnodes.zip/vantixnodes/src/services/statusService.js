'use strict';

const dns = require('dns').promises;
const net = require('net');
const { getDb } = require('../database/connection');
const { SERVICE_STATUSES } = require('../config/constants');
const settings = require('./settingsService');
const ws = require('./wsService');

function listServices({ onlyVisible = true } = {}) {
  const where = onlyVisible ? 'WHERE visible = 1' : '';
  return getDb().prepare(`SELECT * FROM status_services ${where} ORDER BY display_order, id`).all();
}

function overall(services) {
  let worst = 'operational';
  let sev = 0;
  for (const s of services) {
    const meta = SERVICE_STATUSES[s.status];
    if (meta && meta.severity > sev) {
      sev = meta.severity;
      worst = s.status;
    }
  }
  const labels = {
    operational: 'All systems operational',
    maintenance: 'Scheduled maintenance in progress',
    degraded: 'Some systems are degraded',
    partial_outage: 'Partial outage detected',
    major_outage: 'Major outage in progress'
  };
  return { status: worst, label: labels[worst] };
}

function stats() {
  const s = settings.all();
  return [
    { key: 'uptime', label: 'Uptime', value: s.stat_uptime },
    { key: 'locations', label: 'Locations', value: s.stat_locations },
    { key: 'servers', label: 'Servers', value: s.stat_servers },
    { key: 'customers', label: 'Customers', value: s.stat_customers },
    { key: 'network', label: 'Network speed', value: s.stat_network }
  ];
}

function snapshot() {
  const services = listServices();
  return {
    overall: overall(services),
    services: services.map((x) => ({
      slug: x.slug,
      name: x.name,
      description: x.description,
      status: x.status,
      label: SERVICE_STATUSES[x.status] ? SERVICE_STATUSES[x.status].label : x.status,
      updated_at: x.updated_at
    })),
    stats: stats()
  };
}

function publishUpdate() {
  ws.broadcast('status', snapshot());
}

/* ------------------------------------------------------------------ *
 * Monitoring provider hook.
 * A service with source = 'api' is polled at its api_url, which must
 * return JSON like {"status":"operational"} (any key in SERVICE_STATUSES).
 * Manual services are never touched by the poller. Nothing is simulated.
 * ------------------------------------------------------------------ */
async function isPublicHost(hostname) {
  if (net.isIP(hostname)) return !isPrivateIp(hostname);
  try {
    const addrs = await dns.lookup(hostname, { all: true });
    return addrs.length > 0 && addrs.every((a) => !isPrivateIp(a.address));
  } catch (e) {
    return false;
  }
}

function isPrivateIp(ip) {
  if (net.isIPv6(ip)) {
    const l = ip.toLowerCase();
    return l === '::1' || l.startsWith('fc') || l.startsWith('fd') || l.startsWith('fe80') || l.startsWith('::ffff:127.') || l === '::';
  }
  const p = ip.split('.').map(Number);
  return (
    p[0] === 10 ||
    p[0] === 127 ||
    p[0] === 0 ||
    (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
    (p[0] === 192 && p[1] === 168) ||
    (p[0] === 169 && p[1] === 254)
  );
}

async function pollApiServices() {
  const rows = getDb().prepare("SELECT * FROM status_services WHERE source = 'api' AND api_url != ''").all();
  let changed = false;
  for (const row of rows) {
    try {
      const url = new URL(row.api_url);
      if (!['http:', 'https:'].includes(url.protocol) || !(await isPublicHost(url.hostname))) continue;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      const res = await fetch(url, { signal: controller.signal, redirect: 'error', headers: { Accept: 'application/json' } });
      clearTimeout(timer);
      if (!res.ok) continue;
      const data = await res.json();
      if (data && SERVICE_STATUSES[data.status] && data.status !== row.status) {
        getDb().prepare("UPDATE status_services SET status = ?, updated_at = datetime('now') WHERE id = ?").run(data.status, row.id);
        changed = true;
      }
    } catch (e) {
      /* leave the last known status untouched on failure */
    }
  }
  if (changed) publishUpdate();
}

let pollTimer = null;
function startPolling(intervalMs = 60000) {
  if (pollTimer) return;
  pollTimer = setInterval(() => pollApiServices().catch(() => {}), intervalMs);
  pollTimer.unref();
}

module.exports = { listServices, overall, stats, snapshot, publishUpdate, startPolling, pollApiServices, isPublicHost };
