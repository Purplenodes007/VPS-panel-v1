'use strict';

const fs = require('fs');
const path = require('path');
const multer = require('multer');
const config = require('../config');
const { randomToken } = require('../utils/helpers');

fs.mkdirSync(config.uploadDir, { recursive: true });

// Extension is derived from the validated MIME type, never from the client filename.
const TYPES = {
  'image/png': { ext: '.png', kind: 'image' },
  'image/jpeg': { ext: '.jpg', kind: 'image' },
  'image/webp': { ext: '.webp', kind: 'image' },
  'image/svg+xml': { ext: '.svg', kind: 'image' },
  'video/mp4': { ext: '.mp4', kind: 'video' },
  'video/webm': { ext: '.webm', kind: 'video' }
};
const ALLOWED_EXT = new Set(['.png', '.jpg', '.jpeg', '.webp', '.svg', '.mp4', '.webm']);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, config.uploadDir),
  filename: (req, file, cb) => {
    const t = TYPES[file.mimetype];
    cb(null, `${Date.now().toString(36)}-${randomToken(12)}${t ? t.ext : '.bin'}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: config.upload.maxVideoBytes, files: 1, fields: 5 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    if (!TYPES[file.mimetype] || !ALLOWED_EXT.has(ext)) {
      const err = new Error('Unsupported file type. Allowed: PNG, JPG, WEBP, SVG, MP4, WEBM.');
      err.code = 'BAD_FILE_TYPE';
      return cb(err);
    }
    return cb(null, true);
  }
});

function readHead(file, len = 32) {
  const fd = fs.openSync(file, 'r');
  try {
    const buf = Buffer.alloc(len);
    const n = fs.readSync(fd, buf, 0, len, 0);
    return buf.subarray(0, n);
  } finally {
    fs.closeSync(fd);
  }
}

/** Validates the real file contents (magic bytes) against the declared MIME type. */
function validateContents(filePath, mime) {
  const head = readHead(filePath, 32);
  switch (mime) {
    case 'image/png':
      return head.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
    case 'image/jpeg':
      return head[0] === 0xff && head[1] === 0xd8 && head[2] === 0xff;
    case 'image/webp':
      return head.subarray(0, 4).toString() === 'RIFF' && head.subarray(8, 12).toString() === 'WEBP';
    case 'video/mp4':
      return head.subarray(4, 8).toString() === 'ftyp';
    case 'video/webm':
      return head[0] === 0x1a && head[1] === 0x45 && head[2] === 0xdf && head[3] === 0xa3;
    case 'image/svg+xml': {
      const text = fs.readFileSync(filePath, 'utf8');
      if (text.length > 512 * 1024) return false;
      if (!/<svg[\s>]/i.test(text)) return false;
      // Reject anything that could execute script or load active content.
      const forbidden = /<script|<foreignObject|<iframe|<embed|<object|<link|<meta|<style[^>]*@import|\son[a-z]+\s*=|javascript:|data:text\/html|<!ENTITY|<!DOCTYPE[^>]*\[/i;
      return !forbidden.test(text);
    }
    default:
      return false;
  }
}

/** Express handler: validates the uploaded file and responds with its public URL. */
function handleUpload(req, res) {
  upload.single('file')(req, res, (err) => {
    if (err) {
      const message =
        err.code === 'LIMIT_FILE_SIZE' ? 'File is too large.' : err.code === 'BAD_FILE_TYPE' ? err.message : 'Upload failed.';
      return res.status(400).json({ error: message });
    }
    const file = req.file;
    if (!file) return res.status(400).json({ error: 'No file received.' });

    const info = TYPES[file.mimetype];
    const remove = () => fs.unlink(file.path, () => {});

    if (!info || !validateContents(file.path, file.mimetype)) {
      remove();
      return res.status(400).json({ error: 'File contents do not match the declared type.' });
    }
    if (info.kind === 'image' && file.size > config.upload.maxImageBytes) {
      remove();
      return res.status(400).json({ error: `Images must be smaller than ${config.upload.maxImageBytes / 1024 / 1024} MB.` });
    }
    return res.json({ url: `/uploads/${file.filename}`, kind: info.kind, size: file.size });
  });
}

module.exports = { handleUpload };
