'use strict';

const { WebSocketServer } = require('ws');

let wss = null;

/**
 * Attaches a read-only WebSocket channel at /ws used to push live status
 * changes to open pages. Clients cannot send commands; messages are ignored.
 */
function attach(server) {
  wss = new WebSocketServer({ server, path: '/ws', maxPayload: 1024 });
  const alive = new WeakMap();

  wss.on('connection', (ws) => {
    alive.set(ws, true);
    ws.on('pong', () => alive.set(ws, true));
    ws.on('message', () => {});
    ws.on('error', () => {});
  });

  const interval = setInterval(() => {
    if (!wss) return;
    wss.clients.forEach((ws) => {
      if (!alive.get(ws)) return ws.terminate();
      alive.set(ws, false);
      return ws.ping();
    });
  }, 30000);
  interval.unref();
  wss.on('close', () => clearInterval(interval));
  return wss;
}

function broadcast(type, payload) {
  if (!wss) return;
  const message = JSON.stringify({ type, payload });
  wss.clients.forEach((ws) => {
    if (ws.readyState === 1) ws.send(message);
  });
}

module.exports = { attach, broadcast };
