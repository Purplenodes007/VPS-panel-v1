'use strict';

const crypto = require('crypto');

function slugify(input, fallback = 'item') {
  const slug = String(input || '')
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
  return slug || fallback;
}

/** Returns a slug that does not yet exist in `table.column` (excluding row `exceptId`). */
function uniqueSlug(db, table, column, base, exceptId = 0) {
  const allowed = new Set(['categories', 'posts', 'status_services']);
  if (!allowed.has(table) || !/^[a-z_]+$/.test(column)) throw new Error('Invalid slug target');
  let slug = slugify(base);
  let n = 1;
  const stmt = db.prepare(`SELECT id FROM ${table} WHERE ${column} = ? AND id != ?`);
  while (stmt.get(slug, exceptId)) {
    n += 1;
    slug = `${slugify(base)}-${n}`;
  }
  return slug;
}

function str(value, max = 255) {
  if (value === undefined || value === null) return '';
  return String(value).replace(/\u0000/g, '').trim().slice(0, max);
}

function int(value, def = 0, min = -2147483648, max = 2147483647) {
  const n = parseInt(value, 10);
  if (Number.isNaN(n)) return def;
  return Math.min(max, Math.max(min, n));
}

function num(value, def = 0, min = 0, max = 1e9) {
  const n = parseFloat(value);
  if (Number.isNaN(n)) return def;
  return Math.min(max, Math.max(min, n));
}

function bool(value) {
  return value === '1' || value === 1 || value === true || value === 'on' || value === 'true' ? 1 : 0;
}

function isHexColor(value) {
  return typeof value === 'string' && /^#[0-9a-fA-F]{6}$/.test(value);
}

/** Accepts http(s) URLs and site-relative paths. Returns '' when unsafe. */
function safeUrl(value, { allowRelative = true, max = 500 } = {}) {
  const v = str(value, max);
  if (!v) return '';
  if (allowRelative && /^\/(?!\/)[^\s]*$/.test(v)) return v;
  if (allowRelative && /^#[\w-]+$/.test(v)) return v;
  try {
    const u = new URL(v);
    if (u.protocol === 'http:' || u.protocol === 'https:') return u.toString();
  } catch (e) {
    /* invalid */
  }
  return '';
}

function isEmail(value) {
  return typeof value === 'string' && value.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);
}

function getIp(req) {
  return (req.ip || (req.socket && req.socket.remoteAddress) || '').replace(/^::ffff:/, '').slice(0, 64);
}

function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('hex');
}

function safeEqual(a, b) {
  const ba = Buffer.from(String(a || ''));
  const bb = Buffer.from(String(b || ''));
  return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
}

function parseJson(value, fallback) {
  try {
    const parsed = JSON.parse(value);
    return parsed === null || parsed === undefined ? fallback : parsed;
  } catch (e) {
    return fallback;
  }
}

function linesToArray(text, maxItems = 30, maxLen = 120) {
  return String(text || '')
    .split(/\r?\n/)
    .map((l) => l.replace(/\u0000/g, '').trim().slice(0, maxLen))
    .filter(Boolean)
    .slice(0, maxItems);
}

function formatDate(value) {
  if (!value) return '';
  const d = new Date(String(value).replace(' ', 'T') + (String(value).includes('Z') ? '' : 'Z'));
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatDateTime(value) {
  if (!value) return '';
  const d = new Date(String(value).replace(' ', 'T') + (String(value).includes('Z') ? '' : 'Z'));
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'UTC' }) + ' UTC';
}

function formatPrice(price, currency = 'USD') {
  const n = Number(price) || 0;
  try {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency, minimumFractionDigits: 2 }).format(n);
  } catch (e) {
    return `$${n.toFixed(2)}`;
  }
}

function formatBytes(bytes) {
  const units = ['B', 'KB', 'MB', 'GB'];
  let n = Number(bytes) || 0;
  let i = 0;
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024;
    i += 1;
  }
  return `${n.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

function paginate(total, page, perPage) {
  const pages = Math.max(1, Math.ceil(total / perPage));
  const current = Math.min(Math.max(1, page), pages);
  return { total, perPage, pages, page: current, offset: (current - 1) * perPage, hasPrev: current > 1, hasNext: current < pages };
}

function discordAvatarUrl(user, size = 128) {
  if (user && user.avatar && user.discord_id) {
    if (/^https?:\/\//.test(user.avatar)) return user.avatar;
    const ext = user.avatar.startsWith('a_') ? 'gif' : 'png';
    return `https://cdn.discordapp.com/avatars/${user.discord_id}/${user.avatar}.${ext}?size=${size}`;
  }
  return '';
}

module.exports = {
  slugify,
  uniqueSlug,
  str,
  int,
  num,
  bool,
  isHexColor,
  safeUrl,
  isEmail,
  getIp,
  randomToken,
  safeEqual,
  parseJson,
  linesToArray,
  formatDate,
  formatDateTime,
  formatPrice,
  formatBytes,
  paginate,
  discordAvatarUrl
};
