'use strict';
// Written in plain syntax so it also runs on very old Node versions and can print a helpful message.
var major = parseInt(process.versions.node.split('.')[0], 10);
if (major < 18) {
  console.error('\nVantixNodes requires Node.js 18.17 or newer. You are running ' + process.version + '.');
  console.error('Install Node 20 LTS on Ubuntu/Debian:');
  console.error('  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -');
  console.error('  sudo apt-get install -y nodejs');
  console.error('Then run:  rm -rf node_modules package-lock.json && npm install\n');
  process.exit(1);
}
